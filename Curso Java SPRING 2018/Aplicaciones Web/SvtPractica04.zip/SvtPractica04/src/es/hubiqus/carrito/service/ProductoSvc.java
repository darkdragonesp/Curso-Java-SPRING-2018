package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.Producto;

public interface ProductoSvc {
	
	/**
	 * Buscar por id
	 * @param id criterio de búsqueda
	 * @return elemento buscado, null si no lo encuentra
	 * @throws SvcException error al buscar
	 */
	public Producto buscar(int id) throws SvcException;

	/**
	 * Buscar todos 
	 * @return lista de coincidencias
	 * @throws SvcException error al buscar
	 */
	public Iterable<Producto> listar() throws SvcException;
}
