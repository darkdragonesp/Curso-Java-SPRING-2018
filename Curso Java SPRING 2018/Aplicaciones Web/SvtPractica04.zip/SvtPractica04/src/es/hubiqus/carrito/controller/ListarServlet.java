package es.hubiqus.carrito.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.service.ProductoSvc;

/**
 * Servlet implementation class ListarServlet
 */
@WebServlet("/ListarServlet")
public class ListarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "/productos.jsp"; 
	private static final String ERROR = "/error.jsp";
	
	private static final Log log = LogFactory.getLog(ListarServlet.class);
	
	private ProductoSvc svc;
	
    public ProductoSvc getSvc() {
		return svc;
	}
	public void setSvc(ProductoSvc svc) {
		this.svc = svc;
	}
	
	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getProductoSvc());
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			log.debug("Entrando en el Servlet");
			request.setAttribute("lista", svc.listar());
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			log.error(ex);
			request.setAttribute("error", "Error al listar");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
		
	}

}
