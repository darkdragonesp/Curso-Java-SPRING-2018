package es.hubiqus.carrito.service.impl;

import java.util.List;

import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.model.dao.DaoException;
import es.hubiqus.carrito.model.dao.ProductoDao;
import es.hubiqus.carrito.service.ProductoSvc;
import es.hubiqus.carrito.service.SvcException;

public class ProductoSvcImpl implements ProductoSvc{
	
	private ProductoDao dao;
	
	public ProductoDao getDao() {
		return dao;
	}
	public void setDao(ProductoDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Producto buscar(int id) throws SvcException {
		Producto res = null;
		
		try{
			res = dao.findById(id);
		}catch (DaoException ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Override
	public Iterable<Producto> listar() throws SvcException {
		List<Producto> res = null;
		
		try{
			res = dao.findByNombre("");
		}catch (DaoException ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
