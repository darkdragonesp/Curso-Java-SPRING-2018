package es.hubiqus.carrito.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.service.CarritoSvc;

/**
 * Servlet implementation class ConfirmarServlet
 */
@WebServlet("/ConfirmarServlet")
public class ConfirmarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "/resultado.jsp"; 
	private static final String ERROR = "/error.jsp";
	
	private static final Log log = LogFactory.getLog(ConfirmarServlet.class);
	
	private CarritoSvc svc;
	
	public CarritoSvc getSvc() {
		return svc;
	}
	public void setSvc(CarritoSvc svc) {
		this.svc = svc;
	}

	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getCarritoSvc());
	}
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			//Guardar el resultado
			Carrito carrito = (Carrito) request.getSession().getAttribute("carrito");
			if (carrito == null){
				request.setAttribute("resultado", 0.0);
			}else{
				request.setAttribute("resultado", svc.total(carrito));
//				throw new Exception("ERROR al calcular");
			}
			
//			//Vaciar carrito
//			request.getSession().removeAttribute(ATT_CARRITO);
			
			//Invalidar sesión completa
			request.getSession().invalidate();
			
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){	
			log.error(ex);
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
