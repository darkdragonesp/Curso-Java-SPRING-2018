package es.hubiqus.carrito.factory;

import es.hubiqus.carrito.model.dao.ProductoDao;
import es.hubiqus.carrito.model.dao.impl.JdbcDataSource;
import es.hubiqus.carrito.model.dao.impl.ProductoDaoImplPs;
import es.hubiqus.carrito.service.CarritoSvc;
import es.hubiqus.carrito.service.ProductoSvc;
import es.hubiqus.carrito.service.impl.CarritoSvcImpl;
import es.hubiqus.carrito.service.impl.ProductoSvcImpl;

/**
 * Generación de beans con patrón Singleton
 * @author ajurado
 *
 */
public class Factory {

	private static JdbcDataSource dataSource;
	private static ProductoDao productoDao;
	private static ProductoSvc productoSvc;
	private static CarritoSvc carritoSvc;
	
	/**
	 * Obtener dataSource
	 * @return
	 */
	public static JdbcDataSource getDataSource() {
		if (dataSource == null) {
			try {
				JdbcDataSource bean = new JdbcDataSource();
				//Asignar valores de conexión
				bean.setUrl("jdbc:mysql://localhost:3306/inventario");
				bean.setUsername("root");
				bean.setPassword("");
				
				dataSource = bean;
			} catch (Exception ex) {
				dataSource = null;
			}
		}
		
		return dataSource;
	}
	
	/**
	 * Obtener ProductoDao
	 * @return
	 */
	public static ProductoDao getProductoDao(){
		if (productoDao == null){
			ProductoDaoImplPs bean = new ProductoDaoImplPs();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			productoDao = bean;
		}
		
		return productoDao;
	}
	
	/**
	 * Obtener ProductoSvc
	 * @return
	 */
	public static ProductoSvc getProductoSvc(){
		if (productoSvc == null){
			ProductoSvcImpl bean = new ProductoSvcImpl();
			//Inyección de dependencias
			bean.setDao(getProductoDao());
			
			productoSvc = bean;
		}
		
		return productoSvc;
	}
	
	/**
	 * Obtener CarritoSvc
	 * @return
	 */
	public static CarritoSvc getCarritoSvc(){
		if (carritoSvc == null){
			CarritoSvcImpl bean = new CarritoSvcImpl();
			
			carritoSvc = bean;
		}
		
		return carritoSvc;
	}

}
