package es.hubiqus.carrito.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.service.CarritoSvc;
import es.hubiqus.carrito.service.ProductoSvc;

/**
 * Servlet implementation class ComprarServlet
 */
@WebServlet("/ComprarServlet")
public class ComprarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "/ListarServlet"; 
	private static final String ERROR = "/error.jsp";		
	
	private static final Log log = LogFactory.getLog(ComprarServlet.class);
	
	private ProductoSvc svc;
	
	private CarritoSvc cSvc;
	
	public ProductoSvc getSvc() {
		return svc;
	}
	public void setSvc(ProductoSvc svc) {
		this.svc = svc;
	}
	public CarritoSvc getcSvc() {
		return cSvc;
	}
	public void setcSvc(CarritoSvc cSvc) {
		this.cSvc = cSvc;
	}

	@Override
	public void init() throws ServletException {		
		this.setSvc(Factory.getProductoSvc());
		this.setcSvc(Factory.getCarritoSvc());
	}
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			int id = Integer.parseInt(request.getParameter("id"));
			Producto producto = svc.buscar(id);
			
			//Guardar en el session
			Carrito carrito = (Carrito) request.getSession().getAttribute("carrito");
			if (carrito == null){
				carrito = new Carrito();
			}
			//Agregar producto
			cSvc.agregar(carrito, producto);
			
			request.getSession().setAttribute("carrito", carrito);
			request.setAttribute("msg", producto.getNombre() + " añadido al carrito");
			
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){		
			log.error(ex);
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
