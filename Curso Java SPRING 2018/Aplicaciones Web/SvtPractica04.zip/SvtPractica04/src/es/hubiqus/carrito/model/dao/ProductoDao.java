package es.hubiqus.carrito.model.dao;

import java.util.List;

import es.hubiqus.carrito.model.Producto;

public interface ProductoDao {
	
	/**
	 * Guardar un registro
	 * @param producto elemento a guardar
	 * @throws DaoException error de bdd
	 */
	public void save(Producto producto) throws DaoException;

	/**
	 * Filtrar por nombre
	 * @param nombre criterio de filtrado
	 * @return lista de prodcutos
	 * @throws DaoException error de bdd
	 */
	public List<Producto> findByNombre(String nombre) throws DaoException;

	/**
	 * Buscar por id
	 * @param id criterio de búsqueda
	 * @return elemento buscado, null si no lo encuentra
	 * @throws DaoException error al buscar
	 */
	public Producto findById(int id) throws DaoException;
	
}
