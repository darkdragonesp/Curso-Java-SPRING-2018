package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.model.Producto;

public interface CarritoSvc {
	
	/**
	 * Agregar al carrito
	 * @throws SvcException error al guardar
	 */
	public void agregar(Carrito c, Producto p) throws SvcException;
	
	/**
	 * Calcular el precio total
	 * @param lista lista de productos
	 * @return precio total
	 */
	public double total(Carrito c);
}
