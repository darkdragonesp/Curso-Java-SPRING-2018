package es.hubiqus.svt.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.svt.model.Persona;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/GuardarServlet")
public class GuardarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private List<Persona> lista;
	
	@Override
	public void init() throws ServletException {
		lista = new ArrayList<Persona>();
	}
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			//Crear la instancia de la clase Persona
			Persona item = new Persona();
			item.setDni(request.getParameter("dni"));
			item.setNombre(request.getParameter("nombre"));
			item.setEdad(Integer.parseInt(request.getParameter("edad")));
			
			lista.add(item);
			
			//Guardar en el request
			request.setAttribute("lista", lista);
			request.getRequestDispatcher("/resultado.jsp").forward(request, response);
		} catch (Exception ex) {
			request.getRequestDispatcher("/error.jsp").forward(request, response);
		}
	}

}
