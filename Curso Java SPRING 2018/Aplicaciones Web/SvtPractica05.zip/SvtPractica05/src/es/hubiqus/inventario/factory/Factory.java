package es.hubiqus.inventario.factory;

import es.hubiqus.inventario.model.dao.ProductoDao;
import es.hubiqus.inventario.model.dao.TipoProductoDao;
import es.hubiqus.inventario.model.dao.impl.JdbcDataSource;
import es.hubiqus.inventario.model.dao.impl.ProductoDaoImplPs;
import es.hubiqus.inventario.model.dao.impl.TipoProductoDaoImpl;
import es.hubiqus.inventario.service.ProductoSvc;
import es.hubiqus.inventario.service.TipoProductoSvc;
import es.hubiqus.inventario.service.impl.ProductoSvcImpl;
import es.hubiqus.inventario.service.impl.TipoProductoSvcImpl;

/**
 * Generación de beans con patrón Singleton
 * @author ajurado
 *
 */
public class Factory {

	private static JdbcDataSource dataSource;
	private static ProductoDao productoDao;
	private static TipoProductoDao tipoProductoDao;
	private static ProductoSvc productoSvc;
	private static TipoProductoSvc tipoProductoSvc;
	
	/**
	 * Obtener dataSource
	 * @return
	 */
	public static JdbcDataSource getDataSource() {
		if (dataSource == null) {
			try {
				JdbcDataSource bean = new JdbcDataSource();
				//Asignar valores de conexión
				bean.setUrl("jdbc:mysql://localhost:3306/inventario");
				bean.setUsername("root");
				bean.setPassword("");
				
				dataSource = bean;
			} catch (Exception ex) {
				dataSource = null;
			}
		}
		
		return dataSource;
	}
	
	/**
	 * Obtener ProductoDao
	 * @return
	 */
	public static ProductoDao getProductoDao(){
		if (productoDao == null){
			ProductoDaoImplPs bean = new ProductoDaoImplPs();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			productoDao = bean;
		}
		
		return productoDao;
	}
	
	/**
	 * Obtener TipoProductoDao
	 * @return
	 */
	public static TipoProductoDao getTipoProductoDao(){
		if (tipoProductoDao == null){
			TipoProductoDaoImpl bean = new TipoProductoDaoImpl();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			tipoProductoDao = bean;
		}
		
		return tipoProductoDao;
	}
	
	/**
	 * Obtener ProductoSvc
	 * @return
	 */
	public static ProductoSvc getProductoSvc(){
		if (productoSvc == null){
			ProductoSvcImpl bean = new ProductoSvcImpl();
			//Inyección de dependencias
			bean.setDao(getProductoDao());
			
			productoSvc = bean;
		}
		
		return productoSvc;
	}
	
	/**
	 * Obtener TipoProductoSvc
	 * @return
	 */
	public static TipoProductoSvc getTipoProductoSvc(){
		if (tipoProductoSvc == null){
			TipoProductoSvcImpl bean = new TipoProductoSvcImpl();
			//Inyección de dependencias
			bean.setDao(getTipoProductoDao());
			
			tipoProductoSvc = bean;
		}
		
		return tipoProductoSvc;
	}

}
