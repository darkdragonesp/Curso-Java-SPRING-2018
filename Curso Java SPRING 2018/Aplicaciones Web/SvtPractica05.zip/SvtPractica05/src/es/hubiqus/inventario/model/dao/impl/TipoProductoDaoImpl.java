package es.hubiqus.inventario.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.TipoProductoDao;

public class TipoProductoDaoImpl implements TipoProductoDao{
	
	private JdbcDataSource dataSource;
	
	public JdbcDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(JdbcDataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public List<TipoProducto> findAll() throws DaoException {
		List<TipoProducto> res = new ArrayList<TipoProducto>();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		
		try{					
			String sql = "SELECT id, descripcion FROM tipoproducto";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			
			rs = statement.executeQuery();
		
			while (rs.next()){
				TipoProducto d = new TipoProducto();
				d.setId(rs.getInt("id"));
				d.setDescripcion(rs.getString("descripcion"));
				res.add(d);
			}
		}catch (Exception ex){
			throw new DaoException(ex);
		}finally{
			try {
				if (rs != null){				
					rs.close();				
				}
				if (statement != null){				
					statement.close();				
				}
				if (connection != null){				
					connection.close();				
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
		
		return res;
	}

}
