package es.hubiqus.spr.model.dao;

import es.hubiqus.spr.model.Departamento;

public interface DepartamentoDao {

	/**
	 * Listado completo
	 * @return lista de departamentos
	 * @throws DaoException error al buscar
	 */
	public Iterable<Departamento> findAll() throws DaoException;
	
	/**
	 * Buscar por número de departamento
	 * @param id
	 * @return departamento encontrado, null en otro caso
	 * @throws DaoException error al buscar
	 */
	public Departamento findById(int id) throws DaoException;
	
}
