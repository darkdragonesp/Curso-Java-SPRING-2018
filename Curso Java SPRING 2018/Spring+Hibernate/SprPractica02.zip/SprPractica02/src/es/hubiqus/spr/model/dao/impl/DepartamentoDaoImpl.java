package es.hubiqus.spr.model.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import es.hubiqus.spr.model.Departamento;
import es.hubiqus.spr.model.dao.DaoException;
import es.hubiqus.spr.model.dao.DepartamentoDao;

public class DepartamentoDaoImpl implements DepartamentoDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Departamento> findAll() throws DaoException {
		List<Departamento> res = null;

		try{					
			String hql = "FROM Departamento";
			res = sessionFactory.getCurrentSession().createQuery(hql).list();
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}

	@Override
	public Departamento findById(int id) throws DaoException {
		Departamento res = null;
		
		try{					
			res = (Departamento) sessionFactory.getCurrentSession().get(Departamento.class, id);
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}

}
