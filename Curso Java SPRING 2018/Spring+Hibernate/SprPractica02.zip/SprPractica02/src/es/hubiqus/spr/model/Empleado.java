package es.hubiqus.spr.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="empleados")
public class Empleado {
	
	private Integer numero;
	private String nombre;
	private String puesto;
	private Empleado jefe;
	private Date fechaAlta;
	private Integer salario;
	private Integer comision;
	
	private Departamento departamento;
	
	private Set<Empleado> empleados;
	
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getNumero() {
		return numero;
	}
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	
	@Column(name = "nombre", nullable = false, length = 100)	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@Column(name = "puesto", nullable = false, length = 50)	
	public String getPuesto() {
		return puesto;
	}
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}
	
	@ManyToOne
    @JoinColumn(name="jefe")
	public Empleado getJefe() {
		return jefe;
	}
	public void setJefe(Empleado jefe) {
		this.jefe = jefe;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name = "fechaAlta", nullable = false)	
	public Date getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	
	@Column(name = "salario", nullable = false)	
	public Integer getSalario() {
		return salario;
	}
	public void setSalario(Integer salario) {
		this.salario = salario;
	}
	
	@Column(name = "comision")	
	public Integer getComision() {
		return comision;
	}
	public void setComision(Integer comision) {
		this.comision = comision;
	}
	
	@ManyToOne
    @JoinColumn(name="dnumero")
	public Departamento getDepartamento() {
		return departamento;
	}
	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	
	@OneToMany(fetch=FetchType.EAGER, mappedBy="jefe")
	public Set<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(Set<Empleado> empleados) {
		this.empleados = empleados;
	}
	
	
}
