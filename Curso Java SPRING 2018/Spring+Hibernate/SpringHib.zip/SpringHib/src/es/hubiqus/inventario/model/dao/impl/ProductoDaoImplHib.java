package es.hubiqus.inventario.model.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

/**
 * Dao Hibernate empleando templates, no es necesario inyectar template ni sessionFactory (ver CustomHibernateDaoSupport)
 * Gestiona la apertura y cierre de sesiones y transacciones
 *
 */
//Marcamos la clase como transaccional
@Transactional
public class ProductoDaoImplHib extends HibernateDaoSupport implements ProductoDao{

	//Marcamos los métodos que queremos que se ejecuten en transacción
	//También se puede hacer a nivel de la capa de servicio!!
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void save(Producto producto) throws DaoException{
		try{
			this.getHibernateTemplate().save(producto);			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
	}
	
	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException{
		List<Producto> res = null;
		
		try{					
			String hql = "FROM Producto p WHERE p.nombre LIKE :nombre";
			res = (List<Producto>) this.getHibernateTemplate().findByNamedParam(hql, 
									new String[]{"nombre"}, new Object[]{"%" + nombre + "%"});		
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}
}
