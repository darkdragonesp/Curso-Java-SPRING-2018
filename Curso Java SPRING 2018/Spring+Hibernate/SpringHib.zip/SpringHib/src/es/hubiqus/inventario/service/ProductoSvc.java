package es.hubiqus.inventario.service;

import es.hubiqus.inventario.model.Producto;

public interface ProductoSvc {

	/**
	 * Guardar un elemento
	 * @param producto elemento a guardar
	 * @throws SvcException
	 */
	public void guardar(Producto producto) throws SvcException;
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<Producto> listar() throws SvcException;
	
}
