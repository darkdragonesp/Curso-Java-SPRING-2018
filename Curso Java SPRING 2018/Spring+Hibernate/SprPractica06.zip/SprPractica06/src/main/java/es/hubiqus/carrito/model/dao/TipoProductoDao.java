package es.hubiqus.carrito.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.carrito.model.TipoProducto;

public interface TipoProductoDao extends CrudRepository<TipoProducto, Integer>{

}
