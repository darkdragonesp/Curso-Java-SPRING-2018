package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.Usuario;
import es.hubiqus.carrito.service.SvcException;

public interface UsuarioSvc {

	/**
	 * Identificar un usuario
	 * @param usuario
	 * @return usuario si lo encuentra, null en caso contrario
	 * @throws SvcException
	 */
	public Usuario identificar(Usuario usuario) throws SvcException; 
}
