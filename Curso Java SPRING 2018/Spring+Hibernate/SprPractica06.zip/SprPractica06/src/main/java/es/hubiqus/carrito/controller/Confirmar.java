package es.hubiqus.carrito.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.service.CarritoSvc;

@Controller
@SessionAttributes("carrito")
public class Confirmar {
	
	private static final String ATT_CARRITO = "carrito";
	private static final String ATT_RESULTADO = "resultado"; 
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "resultado"; 
	private static final String ERROR = "error";
	
	@Autowired
	private CarritoSvc cSvc;
	
//	@Autowired
//	private HttpSession session;
	
	@RequestMapping(value="/confirmar", method=RequestMethod.GET)	
    public String view(@ModelAttribute("carrito") Carrito carrito, Model model){
		try{
//			Carrito carrito = (Carrito) session.getAttribute(ATT_CARRITO);
			if (carrito == null){
				model.addAttribute(ATT_RESULTADO, 0.0);
			}else{
				model.addAttribute(ATT_RESULTADO, cSvc.total(carrito));
			}
			
			//Resetear el carrito
			model.addAttribute(ATT_CARRITO, new Carrito());
			
			return SUCCESS;
		}catch (Exception ex){		
			model.addAttribute(ATT_ERROR, ex);
			return ERROR;
		}
	}

}
