package es.hubiqus.inventario;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

/**
 * Clase de testeo de repositorio con bdd en memoria (ver application.properties)
 * 
 * @author ajurado
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Transactional //Al emplear control transaccional a nivel de servicio los tests nunca podrán completarse a menos que se incluya
//@DataJpaTest //Testeo habitual de capa de DAO, no se puede emplear en este caso porque deshabilita la autoconfiguración de SpringBoot
public class ProductoDaoTest {
	
	@Autowired
	private ProductoDao dao;
	
	@Test
	public void save() throws DaoException {
		Producto producto = new Producto();
		producto.setId(1);
		producto.setCantidad(1);
		producto.setComentario("Producto de Test");
		producto.setFecha(new Date());
		producto.setNombre("Zapato");
		producto.setPrecio(15.0);
		TipoProducto tipo = new TipoProducto();
		tipo.setId(1);
		producto.setTipo(tipo);
		
		dao.save(producto);
	}

}
