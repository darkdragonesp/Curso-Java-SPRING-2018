package es.hubiqus.inventario.model.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.inventario.model.Producto;

public interface ProductoDao extends CrudRepository<Producto, Integer>{

	public List<Producto> findByNombreContaining(String nombre);
	
}
