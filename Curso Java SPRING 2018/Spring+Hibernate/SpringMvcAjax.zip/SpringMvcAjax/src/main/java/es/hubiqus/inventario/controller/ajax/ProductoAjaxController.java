package es.hubiqus.inventario.controller.ajax;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.service.ProductoSvc;
import es.hubiqus.inventario.service.TipoProductoSvc;

@Controller
@RequestMapping(value = "/ajax")
public class ProductoAjaxController {
	
	private static final String ATT_ITEM = "producto";
	private static final String ATT_LISTA = "lista";
	
	private static final String SUCCESS = "forward:/lista.jsp";
	private static final String FORM = "forward:/edit.jsp";

	@Autowired
	private ProductoSvc svc;
	
	@Autowired
	private TipoProductoSvc tSvc;
	
	@Autowired
	private MessageSource messages;
	
	@RequestMapping(value="/borrar", method=RequestMethod.GET)
    public String borrar(@RequestParam int id, Model model){
		try {
			Producto item = new Producto();
			item.setId(id);
			
			//Borrar actual
			svc.eliminar(item);
			
			//Refrescar la lista
			model.addAttribute(ATT_LISTA, svc.listar());
			
			//Devolver la lista actualizada (JSP)
			return SUCCESS;
		} catch (Exception e) {
			return null;
		}
    }
	
	@RequestMapping(value="/filtrar", method=RequestMethod.POST)
    public String filtrar(@RequestParam String filtro, Model model, Locale locale){
		try {
			//Refrescar
			model.addAttribute(ATT_LISTA, svc.listar(filtro));
			
			return SUCCESS;
		} catch (Exception e) {
			return null;
		}
    }
	
	@RequestMapping(value="/buscar", method=RequestMethod.GET)
    public String buscar(@RequestParam int id, Model model){
		try {
			//Buscar
			model.addAttribute(ATT_ITEM, svc.buscar(id));
			//Lista de tipos
			model.addAttribute(ATT_LISTA, tSvc.listar());
			
			//Devolver el formulario completo (JSP)
			return FORM;
		} catch (Exception e) {
			return null;
		}
    }
	
	//Recibe y devuelve entidades HTTP. RequestBody se procesa desde JSON
	@ResponseBody
	@RequestMapping(value="/editar", method=RequestMethod.POST)
	public ResponseEntity<Object> editar(@RequestBody Producto producto, Model model, Locale locale){
		try {
			//Guardar actual
			svc.modificar(producto);
			
			//Devolver el producto modificado
			//Buscar el producto para que no se pierda la descripción del tipo
			return new ResponseEntity<Object>(svc.buscar(producto.getId()), HttpStatus.OK);
		} catch (Exception ex) {
			//Caso error (no de validación)
			return new ResponseEntity<Object>(messages.getMessage("mensaje.error", null, locale), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
