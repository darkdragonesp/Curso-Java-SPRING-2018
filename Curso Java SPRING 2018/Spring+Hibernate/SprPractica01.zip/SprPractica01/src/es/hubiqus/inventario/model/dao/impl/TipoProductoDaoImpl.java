package es.hubiqus.inventario.model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.TipoProductoDao;

public class TipoProductoDaoImpl extends JdbcDaoSupport implements TipoProductoDao{

	@Override
	public List<TipoProducto> findAll() throws DaoException {
		List<TipoProducto> res = null;
		
		try{					
			String sql = "SELECT id, descripcion FROM tipoproducto";
			
			//Consultar y pasar un RowMapper para cada iteraci�n del ResultSet
			res = getJdbcTemplate().query(sql, 
	                new RowMapper<TipoProducto>() {
	                    public TipoProducto mapRow(ResultSet rs, int rowNum)
	                            throws SQLException{
	                    	TipoProducto d = new TipoProducto();
	        				d.setId(rs.getInt("id"));
	        				d.setDescripcion(rs.getString("descripcion"));
	        				
	        				return d;
	                    }  
	                }
	                );
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}

}
