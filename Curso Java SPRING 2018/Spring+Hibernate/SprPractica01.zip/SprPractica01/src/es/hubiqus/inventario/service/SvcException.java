package es.hubiqus.inventario.service;

public class SvcException extends Exception{

	private static final long serialVersionUID = -2494654029738739441L;

	public SvcException(Exception ex){
		super(ex);
	}

}
