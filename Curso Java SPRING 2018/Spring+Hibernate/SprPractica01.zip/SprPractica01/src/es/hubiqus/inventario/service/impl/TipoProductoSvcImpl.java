package es.hubiqus.inventario.service.impl;

import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.TipoProductoDao;
import es.hubiqus.inventario.service.SvcException;
import es.hubiqus.inventario.service.TipoProductoSvc;

public class TipoProductoSvcImpl implements TipoProductoSvc{
	
	private TipoProductoDao dao;
	
	public TipoProductoDao getDao() {
		return dao;
	}
	public void setDao(TipoProductoDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Iterable<TipoProducto> listar() throws SvcException {
		Iterable<TipoProducto> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
