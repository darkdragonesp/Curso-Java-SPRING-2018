package es.hubiqus.inventario.model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

public class ProductoDaoImpl extends JdbcDaoSupport implements ProductoDao{

	@Override
	public void save(Producto producto) throws DaoException{
		try{
			String sql = "INSERT INTO producto (nombre, cantidad, precio, comentario, fecha) VALUES(?,?,?,?,?)";

			//Establecer la sql y los parámetros para insertar
			getJdbcTemplate().update(sql, 
					producto.getNombre(), 
					producto.getCantidad(), 
					producto.getPrecio(),
					producto.getComentario(), 
					producto.getFecha());			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
	}
	
	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException{
		List<Producto> res = null;
		
		try{					
			String sql = "SELECT p.id as id, nombre, cantidad, precio, comentario, fecha, " +
					 	"tipoid, descripcion " +
					 	"FROM producto p LEFT JOIN tipoproducto t ON t.id = tipoid " +
						"WHERE nombre LIKE ?";
			
			//Consultar y pasar un RowMapper para cada iteración del ResultSet
			res = getJdbcTemplate().query(sql, 
	                new RowMapper<Producto>() {
	                    public Producto mapRow(ResultSet rs, int rowNum)
	                            throws SQLException{
	                    	return mapear(rs);
	                    }  
	                },
	                "%" + nombre + "%"
	                );
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}
	
	/**
	 * Obtener un producto desde el ResultSet
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Producto mapear(ResultSet rs) throws SQLException {
		Producto item = new Producto();
		item.setId(rs.getInt("id"));
		item.setNombre(rs.getString("nombre"));
		item.setCantidad(rs.getInt("cantidad"));
		item.setPrecio(rs.getDouble("precio"));
		item.setComentario(rs.getString("comentario"));
		item.setFecha(rs.getDate("fecha"));
		TipoProducto tipo = new TipoProducto();
		tipo.setId(rs.getInt("tipoid"));
		tipo.setDescripcion(rs.getString("descripcion"));
		item.setTipo(tipo);
		
		return item;
	}
	
	@Override
	public void update(Producto producto) throws DaoException {
		try{
			String sql = "UPDATE producto SET " +
							"nombre=?, cantidad=?, precio=?, comentario=?, fecha=?, tipoid=? " + 
							"WHERE id=?";

			getJdbcTemplate().update(sql, 
					producto.getNombre(), 
					producto.getCantidad(), 
					producto.getPrecio(),
					producto.getComentario(), 
					producto.getFecha(),
					producto.getTipo().getId(),
					producto.getId());			
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
	}

	@Override
	public void delete(Producto producto) throws DaoException {
		try{
			String sql = "DELETE FROM producto WHERE id=?";

			getJdbcTemplate().update(sql, 
					producto.getId());			
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
	}

	@Override
	public Producto findById(int id) throws DaoException {
		Producto res = null;
		
		try{					
			String sql = "SELECT p.id as id, nombre, cantidad, precio, comentario, fecha, " +
					 "tipoid, descripcion " +
					 "FROM producto p LEFT JOIN tipoproducto t ON t.id = tipoid " +
					 "WHERE p.id=?";
			
			//Consultar y pasar un RowMapper para cada iteración del ResultSet
			res = getJdbcTemplate().queryForObject(sql, 
	                new RowMapper<Producto>() {
	                    public Producto mapRow(ResultSet rs, int rowNum)
	                            throws SQLException{
	                    	return mapear(rs);
	                    }  
	                },
	                id
	                );
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}
}
