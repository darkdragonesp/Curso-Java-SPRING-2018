package es.hubiqus.hib.service.impl;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.model.dao.UsuarioDao;
import es.hubiqus.hib.service.SvcException;
import es.hubiqus.hib.service.UsuarioSvc;

/**
 * Implementación de UsuarioSvc
 * @author ajurado
 *
 */
@Transactional
public class UsuarioSvcImpl implements UsuarioSvc{
	
	private UsuarioDao dao;
	
	public UsuarioDao getDao() {
		return dao;
	}

	public void setDao(UsuarioDao dao) {
		this.dao = dao;
	}

	@Override
	public Usuario buscar(Usuario item) throws SvcException {
		Usuario res = null;
		try {
			res = dao.findByDniAndPin(item.getDni(), item.getPin());
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		return res;
	}

	@Override
	public Usuario buscar(Integer id) throws SvcException {
		Usuario res = null;
		try {
			res = dao.findById(id);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		return res;

	}

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void actualizar(Usuario item) throws SvcException {
		try {
			dao.update(item);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}

}
