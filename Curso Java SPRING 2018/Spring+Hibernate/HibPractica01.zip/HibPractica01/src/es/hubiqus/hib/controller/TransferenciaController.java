package es.hubiqus.hib.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.MovimientoSvc;

/**
 * Servlet implementation class SaldoController
 */
@WebServlet("/transferencia")
public class TransferenciaController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "transferencia.jsp";
	private static final String ERROR = "transferencia.jsp";
	
	private static final String FORM = "transferencia.jsp";
	
	private MovimientoSvc svc;
	
	public MovimientoSvc getSvc() {
		return svc;
	}

	public void setSvc(MovimientoSvc svc) {
		this.svc = svc;
	}
	
	@Override
    public void init() throws ServletException {
        super.init();
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(MovimientoSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferenciaController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.getRequestDispatcher(FORM).forward(request, response);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Usuario destino = new Usuario();
			destino.setDni(request.getParameter("dni"));
			
			Usuario usuario = (Usuario) request.getSession().getAttribute(LoginFilter.ATT_USER);
			Movimiento mov = svc.transferir(usuario, destino, Double.parseDouble(request.getParameter("cantidad")));
			
			request.setAttribute("msg", mov.getConcepto());
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			request.setAttribute("error", "Error al realizar la transferencia. Compruebe su saldo y el dni del destinatario");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
