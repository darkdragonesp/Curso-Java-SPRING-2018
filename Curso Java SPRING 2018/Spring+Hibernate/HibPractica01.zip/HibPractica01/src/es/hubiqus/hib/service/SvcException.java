package es.hubiqus.hib.service;

public class SvcException extends Exception{

	private static final long serialVersionUID = 6874754099030643336L;

	public SvcException(Exception ex){
		super(ex);
	}

}
