package es.hubiqus.hib.service;

import java.util.Date;
import java.util.List;

import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.model.dao.DaoException;

public interface MovimientoSvc {
	
	/**
	 * Realizar un ingreso
	 * @param user usuario que ingresa
	 * @param cantidad saldo a ingresar, busca y actualiza al usuario con el saldo
	 * @return movimiento generado
	 * @throws SvcException
	 */
	public Movimiento ingresar(Usuario user, double cantidad) throws SvcException;
	
	/**
	 * Realizar una transferencia
	 * @param origen usuario emisor
	 * @param destino usuario receptor
	 * @param cantidad saldo a transferir
	 * @return Movimiento de usuario origen efectuado
	 * @throws SvcException
	 */
	public Movimiento transferir(Usuario origen, Usuario destino, double cantidad) throws SvcException;

	/**
	 * Obtener listado de movimientos según filtro
	 * @param user usuario
	 * @param type tipo de movimiento
	 * @param date fecha mínima
	 * @param amount cantidad mínima
	 * @return lista de movimientos según criterio
	 * @throws DaoException
	 */
	public List<Movimiento> listar(Usuario user, Integer type, Date date, Double amount) throws SvcException;
	
}
