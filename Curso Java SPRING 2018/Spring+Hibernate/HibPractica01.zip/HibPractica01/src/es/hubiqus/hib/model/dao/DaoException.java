package es.hubiqus.hib.model.dao;

public class DaoException extends Exception{

	private static final long serialVersionUID = -7227887432777444621L;

	public DaoException(Exception ex){
		super(ex);
	}

}
