package es.hubiqus.hib.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.MovimientoSvc;

/**
 * Servlet implementation class SaldoController
 */
@WebServlet("/filtro")
public class FiltroController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "movimientos.jsp";
	private static final String ERROR = "movimientos.jsp";
	
	private static final String FILTRO_MENU = "filtro/menu.jsp";
	private static final String FILTRO_TIPO = "filtro/tipo.jsp";
	private static final String FILTRO_FECHA = "filtro/fecha.jsp";
	
	private MovimientoSvc svc;
	
	public MovimientoSvc getSvc() {
		return svc;
	}

	public void setSvc(MovimientoSvc svc) {
		this.svc = svc;
	}

	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(MovimientoSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FiltroController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String opcion = request.getParameter("opt");
    	if (opcion == null || opcion.isEmpty()) {
   			request.getRequestDispatcher(FILTRO_MENU).forward(request, response);
    	} else {
    		switch (opcion) {
   			case "mes": doPost(request, response); break;
    		case "tipo": request.getRequestDispatcher(FILTRO_TIPO).forward(request, response); break;
    		default: request.getRequestDispatcher(FILTRO_FECHA).forward(request, response); break;
   			}
   		}
    }
    
   /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Usuario usuario = (Usuario) request.getSession().getAttribute(LoginFilter.ATT_USER);
			
			//Obtener directamente del usuario
			List<Movimiento> lista = null;
			
			String opcion = request.getParameter("opt");
			switch (opcion) {
			case "mes": 
				Calendar cal = Calendar.getInstance();
				cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1, 0, 0, 0);
				lista = svc.listar(usuario, 
						null, 
						cal.getTime(), 
						null); 
				break;
			case "tipo": 
				lista = svc.listar(usuario, 
						Integer.valueOf(request.getParameter("tipo")), 
						null, 
						null); 
				break;
			default: 
				lista = svc.listar(usuario, 
						null, 
						new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("fecha")), 
						Double.valueOf(request.getParameter("cantidad"))); 
				break;
			}
			
			request.setAttribute("lista", lista);
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			request.setAttribute("error", "Error al listar");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
