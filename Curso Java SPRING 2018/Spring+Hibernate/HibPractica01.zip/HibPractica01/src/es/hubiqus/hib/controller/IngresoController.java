package es.hubiqus.hib.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.MovimientoSvc;

/**
 * Servlet implementation class SaldoController
 */
@WebServlet("/ingreso")
public class IngresoController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "ingreso.jsp";
	private static final String ERROR = "ingreso.jsp";
	
	private static final String FORM = "ingreso.jsp";	
	
	private MovimientoSvc svc;
	
	public MovimientoSvc getSvc() {
		return svc;
	}

	public void setSvc(MovimientoSvc svc) {
		this.svc = svc;
	}
	
	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(MovimientoSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IngresoController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		request.getRequestDispatcher(FORM).forward(request, response);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Usuario usuario = (Usuario) request.getSession().getAttribute(LoginFilter.ATT_USER);
			Movimiento mov = svc.ingresar(usuario, Double.parseDouble(request.getParameter("cantidad")));
			
			request.setAttribute("msg", mov.getConcepto());
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			request.setAttribute("error", "Error al realizar el ingreso");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
