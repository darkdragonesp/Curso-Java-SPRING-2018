package es.hubiqus.hib.model.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.model.dao.DaoException;
import es.hubiqus.hib.model.dao.MovimientoDao;

public class MovimientoDaoImpl implements MovimientoDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void save(Movimiento item) throws DaoException {
		try{
			sessionFactory.getCurrentSession().save(item);		
		}catch (Exception ex){
			throw new DaoException(ex);
		}	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Movimiento> findByFilter(Usuario user, Integer type, Date date, Double amount) throws DaoException {
		List<Movimiento> res = null;
		
		try{
		    Criteria cr = sessionFactory.getCurrentSession().createCriteria(Movimiento.class).
	        		add(Restrictions.eq("usuario.id", user.getId()));
	        //FROM Movimiento m WHERE m.usuario.id = :user
	        
	        if (type != null) {
	        		cr.add(Restrictions.eq("tipo.id", type));
	        		//AND m.tipo.id = :type
	        }
	        
	        if (date != null) {
        			cr.add(Restrictions.ge("fecha", date));
        			//AND m.fecha >= :date
	        }
	        
	        if (amount != null) {
	    			cr.add(Restrictions.ge("cantidad", amount));
	    			//AND m.cantidad >= :amount
	        }
	        
	        cr.addOrder(Order.desc("fecha"));
	        //ORDER BY m.fecha DESC
	        
	        //Obtener la lista
	        res = cr.list();
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return res;
	}

}
