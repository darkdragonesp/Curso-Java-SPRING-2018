package es.hubiqus.hib.model.dao;

import es.hubiqus.hib.model.Usuario;

/**
 * Dao de usuario
 * @author ajurado
 *
 */
public interface UsuarioDao {

	/**
	 * Identificar por dni y pin
	 * @param usuario
	 * @return null si no existe, usuario que corresponde con el dni-pin en otro caso
	 * @throws DaoException
	 */
	public Usuario findByDniAndPin(String dni, int pin) throws DaoException;
	
	/**
	 * Buscar por id
	 * @param id
	 * @return null si no existe, usuario que corresponde con el id en otro caso
	 * @throws DaoException
	 */
	public Usuario findById(Integer id) throws DaoException;
	
	/**
	 * Buscar por dni
	 * @param dni
	 * @return null si no existe, usuario que corresponde con el dni en otro caso
	 * @throws DaoException
	 */
	public Usuario findByDni(String dni) throws DaoException;
	
	/**
	 * Actualizar elemento
	 * @param item
	 * @throws DaoException
	 */
	public void update(Usuario item) throws DaoException;
	
}
