package es.hubiqus.hib.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.UsuarioSvc;

/**
 * Servlet implementation class SaldoController
 */
@WebServlet("/movimientos")
public class MovimientosController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "movimientos.jsp";
	private static final String ERROR = "movimientos.jsp";
	
	private UsuarioSvc svc;
	
	public UsuarioSvc getSvc() {
		return svc;
	}

	public void setSvc(UsuarioSvc svc) {
		this.svc = svc;
	}

	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(UsuarioSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MovimientosController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
   /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Usuario usuario = (Usuario) request.getSession().getAttribute(LoginFilter.ATT_USER);
			
			//Obtener directamente del usuario
			usuario = svc.buscar(usuario.getId());
			request.setAttribute("lista", usuario.getMovimientos());
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			request.setAttribute("error", "Error al listar");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
