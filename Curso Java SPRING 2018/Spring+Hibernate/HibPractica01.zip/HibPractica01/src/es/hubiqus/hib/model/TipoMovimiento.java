package es.hubiqus.hib.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tipomovimiento")
public class TipoMovimiento {
	
	private Integer id;
	private String nombre;
	
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Constructor sin argumentos
	 */
	public TipoMovimiento() {
	}
	
	/**
	 * Constructor con id
	 * @param id
	 */
	public TipoMovimiento(Integer id) {
		this.id = id;
	}

}
