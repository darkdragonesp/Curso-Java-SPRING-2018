package es.hubiqus.hib.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.UsuarioSvc;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/login")
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "home.jsp";
	private static final String ERROR = "index.jsp";	
	
	private UsuarioSvc svc;
	
	public UsuarioSvc getSvc() {
		return svc;
	}

	public void setSvc(UsuarioSvc svc) {
		this.svc = svc;
	}

	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(UsuarioSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

		/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//Datos del formulario
			Usuario usuario = new Usuario();
			usuario.setDni(request.getParameter("dni"));
			usuario.setPin(Integer.valueOf(request.getParameter("pin")));
			
			//Buscar
			usuario = svc.buscar(usuario);
					
			if (usuario == null) {
				request.setAttribute("error", "Usuario/pin incorrecto");
				request.getRequestDispatcher(ERROR).forward(request, response);
			} else {
				//Guardar en la sesión
				request.getSession().setAttribute(LoginFilter.ATT_USER, usuario);
				request.getRequestDispatcher(SUCCESS).forward(request, response);
			}
			
		} catch (Exception ex) {
			request.setAttribute("error", "Error al conectar");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
