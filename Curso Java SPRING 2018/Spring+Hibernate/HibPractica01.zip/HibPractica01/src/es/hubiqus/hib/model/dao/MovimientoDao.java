package es.hubiqus.hib.model.dao;

import java.util.Date;
import java.util.List;

import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.SvcException;

/**
 * Dao de movimientos
 * SI el servicio trata las transacciones directamente en cascada los métodos deposit y transfer no son necesarios
 * @author ajurado
 *
 */
public interface MovimientoDao {

	/**
	 * Realizar un ingreso
	 * @param mov ingreso a realizar
	 * @throws SvcException
	 */
	public void save(Movimiento item) throws DaoException;
	
	/**
	 * Obtener listado de movimientos según filtro
	 * @param user usuario
	 * @param type tipo de movimiento
	 * @param date fecha mínima
	 * @param amount cantidad mínima
	 * @return lista de movimientos según criterio
	 * @throws DaoException
	 */
	public List<Movimiento> findByFilter(Usuario user, Integer type, Date date, Double amount) throws DaoException;

}
