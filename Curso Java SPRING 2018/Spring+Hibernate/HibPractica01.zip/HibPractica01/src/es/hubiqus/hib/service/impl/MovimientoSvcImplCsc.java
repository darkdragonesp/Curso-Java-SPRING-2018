package es.hubiqus.hib.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.hib.model.Movimiento;
import es.hubiqus.hib.model.TipoMovimiento;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.model.dao.MovimientoDao;
import es.hubiqus.hib.model.dao.UsuarioDao;
import es.hubiqus.hib.service.MovimientoSvc;
import es.hubiqus.hib.service.SvcException;

/**
 * Implementación de MovimientoSvc
 * @author ajurado
 *
 */
@Transactional
public class MovimientoSvcImplCsc implements MovimientoSvc{
	
	private UsuarioDao dao;
	private MovimientoDao mDao;
	
	public UsuarioDao getDao() {
		return dao;
	}

	public void setDao(UsuarioDao dao) {
		this.dao = dao;
	}
	
	public MovimientoDao getmDao() {
		return mDao;
	}

	public void setmDao(MovimientoDao mDao) {
		this.mDao = mDao;
	}

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Movimiento ingresar(Usuario user, double cantidad) throws SvcException {
		Movimiento mov = null;
		try {
			mov = new Movimiento();
			mov.setFecha(new Date());
			mov.setCantidad(cantidad);
			mov.setTipo(new TipoMovimiento(1));
			mov.setUsuario(user);
			mov.setConcepto("Ingreso " + cantidad + "€");
			
			//Buscar en primer lugar el usuario, por si se hubiera actualizado
			user = dao.findById(user.getId());
			//Actualizar el ingreso en el usuario
			user.getMovimientos().add(mov);
			//Actualizar el usuario
			user.setSaldo(user.getSaldo() + cantidad);
//			No necesario, una entidad persistente se actualiza con la transacción
//			dao.update(user);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		
		return mov;
	}
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Movimiento transferir(Usuario origen, Usuario destino, double cantidad) throws SvcException {
		Movimiento mov = null;
		try {
			//MOVIMIENTO DE INGRESO
			//Buscar en primer lugar el usuario
			destino = dao.findByDni(destino.getDni());
			
			mov = new Movimiento();
			mov.setFecha(new Date());
			mov.setCantidad(cantidad);
			mov.setTipo(new TipoMovimiento(1));
			mov.setUsuario(destino);
			mov.setConcepto("Transferencia recibida " + cantidad + "€ de " + origen.getDni());
			
			//Actualizar el ingreso en el usuario
			destino.getMovimientos().add(mov);
			//Actualizar el usuario
			destino.setSaldo(destino.getSaldo() + cantidad);
//			No necesario, una entidad persistente se actualiza con la transacción
//			dao.update(destino);
			
			//MOVIMIENTO DE SALIDA
			mov = new Movimiento();
			mov.setFecha(new Date());
			mov.setCantidad(cantidad);
			mov.setTipo(new TipoMovimiento(2));
			mov.setUsuario(origen);
			mov.setConcepto("Transferencia " + cantidad + "€ a " + destino.getDni());
			
			//Buscar en primer lugar el usuario, por si se hubiera actualizado
			origen = dao.findById(origen.getId());
			
			//Comprobación de saldo
			if (origen.getSaldo() - cantidad >= 0) {
				//Actualizar el ingreso en el usuario
				origen.getMovimientos().add(mov);
				//Actualizar el usuario
				origen.setSaldo(origen.getSaldo() - cantidad);
//				No necesario, una entidad persistente se actualiza con la transacción
//				dao.update(origen);
			} else {
				//Lanzar excepción para activar rollback
				throw new Exception("Saldo insuficiente");
			}
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		
		return mov;
	}
	
	@Override
	public List<Movimiento> listar(Usuario user, Integer type, Date date, Double amount) throws SvcException {
		List<Movimiento> res = null;
		
		try {
			res = mDao.findByFilter(user, type, date, amount);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		
		return res;
	}

}
