package es.hubiqus.hib.service;

import es.hubiqus.hib.model.Usuario;

/**
 * Dao de usuario
 * @author ajurado
 *
 */
public interface UsuarioSvc {

	/**
	 * Identificar por dni y pin
	 * @param usuario
	 * @return null si no existe, usuario que corresponde con el dni-pin en otro caso
	 * @throws DaoException
	 */
	public Usuario buscar(Usuario item) throws SvcException;
	
	/**
	 * Buscar por id
	 * @param id
	 * @return null si no existe, usuario que corresponde con el id en otro caso
	 * @throws DaoException
	 */
	public Usuario buscar(Integer id) throws SvcException;
	
	/**
	 * Actualizar elemento
	 * @param item
	 * @throws DaoException
	 */
	public void actualizar(Usuario item) throws SvcException;
}
