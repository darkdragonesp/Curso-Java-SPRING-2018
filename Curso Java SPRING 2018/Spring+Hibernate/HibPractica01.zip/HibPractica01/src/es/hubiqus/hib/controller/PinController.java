package es.hubiqus.hib.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.hib.filter.LoginFilter;
import es.hubiqus.hib.model.Usuario;
import es.hubiqus.hib.service.UsuarioSvc;

/**
 * Servlet implementation class SaldoController
 */
@WebServlet("/pin")
public class PinController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String SUCCESS = "home.jsp";
	private static final String ERROR = "home.jsp";
	
	private static final String FORM = "pin.jsp";
	
	private UsuarioSvc svc;
	
	public UsuarioSvc getSvc() {
		return svc;
	}

	public void setSvc(UsuarioSvc svc) {
		this.svc = svc;
	}
	
	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
   
        this.setSvc(context.getBean(UsuarioSvc.class));
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PinController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    		request.getRequestDispatcher(FORM).forward(request, response);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Usuario usuario = (Usuario) request.getSession().getAttribute(LoginFilter.ATT_USER);
			//Buscar para comparar con la base de datos
			usuario = svc.buscar(usuario.getId());
			
			int anterior = Integer.parseInt(request.getParameter("anterior"));
			int actual = Integer.parseInt(request.getParameter("actual"));
					
			if (usuario.getPin().equals(anterior)) {
				usuario.setPin(actual);
				//Actualizar
				svc.actualizar(usuario);
				
				request.getRequestDispatcher(SUCCESS).forward(request, response);
			} else {
				request.setAttribute("error", "Los pins no coinciden");
				request.getRequestDispatcher(FORM).forward(request, response);
			}
		} catch (Exception ex) {
			request.setAttribute("error", "Error al conectar");
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
