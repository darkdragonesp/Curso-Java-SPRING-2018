package es.hubiqus.inventario.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.service.ProductoSvc;
import es.hubiqus.inventario.service.TipoProductoSvc;

@Controller
//En este caso se usuará para dos acciones, la de nuevo al cargar (view) y la de guardar desde el form (guardar)
@RequestMapping(value = "/guardar")
public class Guardar {
	
	private static final String ATT_ITEM = "producto";
	private static final String ATT_LISTA = "lista";
	private static final String ATT_EXITO = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "form";
	private static final String ERROR = "error";
	
	@Autowired
	private ProductoSvc svc;
	
	@Autowired
	private TipoProductoSvc pSvc;
	
	@Autowired
	private MessageSource messages;
			
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		//Se encarga de parsear las fechas correctamente cuando vienen de formulario
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
	
	//nuevo: simplemente guardar la lista para el select y pasar al form
	@RequestMapping(method=RequestMethod.GET)
    public String view(@ModelAttribute Producto producto, Model model) {
		try {
			//Incluir elementos para la selección
			model.addAttribute(ATT_LISTA, pSvc.listar());
			
			return SUCCESS;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
	}

	//guardar: almacenar el producto, también se vuelve a cargar la lista para el select ya que se vuelve al formulario
    @RequestMapping(method=RequestMethod.POST)
    public String execute(@ModelAttribute Producto producto, Model model, Locale locale) {
		try {
			//Incluir elementos para la selección de nuevo porque vamos hacia el formulario
			model.addAttribute(ATT_LISTA, pSvc.listar());
			
			if (producto.getId() == null){
				svc.guardar(producto);
			}else{
				svc.modificar(producto);
			}
			
			model.addAttribute(ATT_EXITO, messages.getMessage("mensaje.exito", null, locale));
			
			//Limpiar formulario
			model.addAttribute(ATT_ITEM, new Producto());
			
			return SUCCESS;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }
    

}
