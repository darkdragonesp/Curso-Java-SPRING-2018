package es.hubiqus.boot.controller.disco;

import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import es.hubiqus.boot.service.DiscoSvc;
import es.hubiqus.boot.service.GeneroSvc;

@Controller
@RequestMapping(value = "/disco")
public class Buscar {
	
	private static final Log log = LogFactory.getLog(Buscar.class);
	
	private static final String ATT_ITEM = "disco";
	private static final String ATT_LISTA = "lista";
	private static final String ATT_MSG = "msg";
	
	private static final String MSG_ERROR = "error.general";

	private static final String SUCCESS = "disco";
	private static final String ERROR = "forward:/disco/listar";
	
	@Autowired
	private DiscoSvc svc;
	
	@Autowired
	private GeneroSvc gSvc;
	
	@Autowired  
    private MessageSource messageSource;

	@RequestMapping(value="/buscar", method=RequestMethod.GET)
    public String execute(@RequestParam int id, Model model, Locale locale){
    	try {
			model.addAttribute(ATT_ITEM, svc.buscar(id));
			
			//Incluir elementos para la selección
			model.addAttribute(ATT_LISTA, gSvc.listar());
			
			return SUCCESS;
		} catch (Exception ex) {
			log.error(ex);
			model.addAttribute(ATT_MSG,
					messageSource.getMessage(MSG_ERROR, null, locale));
			return ERROR;
		}
    }

}
