package es.hubiqus.boot.service;

import es.hubiqus.boot.model.Carrito;
import es.hubiqus.boot.model.Disco;
import es.hubiqus.boot.model.Usuario;

/**
 * Funcionalidad de carrito
 * @author ajurado
 *
 */
public interface CarritoSvc {
	
	/**
	 * Agregar al carrito
	 * @param carrito
	 * @param disco
	 * @throws SvcException error al guardar
	 */
	public void agregar(Carrito carrito, Disco disco) throws SvcException;
	
	/**
	 * Eliminar un disco del carrito
	 * @param carrito
	 * @param disco
	 * @throws SvcException error al eliminar
	 */
	public void eliminar(Carrito carrito, Disco disco) throws SvcException;
	
	/**
	 * Calcular el precio total
	 * @param lista lista de productos
	 * @return precio total
	 */
	public double total(Carrito carrito);
	
	/**
	 * Confirmar la compra
	 * @param carrito carrito actual
	 * @param usuario usuario que compra
	 * @throws SvcException error al actualizar
	 */
	public void comprar(Carrito carrito, Usuario usuario) throws SvcException;
}
