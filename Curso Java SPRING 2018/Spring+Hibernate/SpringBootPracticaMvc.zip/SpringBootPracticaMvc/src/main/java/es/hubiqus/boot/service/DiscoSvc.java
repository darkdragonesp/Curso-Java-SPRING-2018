package es.hubiqus.boot.service;

import es.hubiqus.boot.model.Disco;

/**
 * Funcionalidad de discos
 * @author ajurado
 *
 */
public interface DiscoSvc {

	/**
	 * Guardar un elemento
	 * @param Disco elemento a guardar
	 * @throws SvcException
	 */
	public void guardar(Disco disco) throws SvcException;
	
	/**
	 * Actualizar un elemento
	 * @param Disco elemento a actualizar
	 * @throws SvcException
	 */
	public void modificar(Disco disco) throws SvcException;
	
	/**
	 * Eliminar un elemento
	 * @param Disco elemento a eliminar
	 * @throws SvcException
	 */
	public void eliminar(Disco disco) throws SvcException;
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<Disco> listar() throws SvcException;
	
	/**
	 * Filtrar por id
	 * @param id clave a buscar
	 * @return Disco encontrado, null si no lo encuentra
	 * @throws SvcException
	 */
	public Disco buscar(int id) throws SvcException;
}
