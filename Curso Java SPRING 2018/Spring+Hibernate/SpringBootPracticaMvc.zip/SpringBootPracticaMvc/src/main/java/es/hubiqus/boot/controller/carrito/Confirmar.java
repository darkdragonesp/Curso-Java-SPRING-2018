package es.hubiqus.boot.controller.carrito;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import es.hubiqus.boot.model.Carrito;
import es.hubiqus.boot.model.Usuario;
import es.hubiqus.boot.service.CarritoSvc;

@Controller
@SessionAttributes({"carrito", "sessionUser"})
@RequestMapping(value="/carrito")
public class Confirmar {
	
	private static final Log log = LogFactory.getLog(Confirmar.class);
	
	private static final String ATT_CARRITO = "carrito";
	private static final String ATT_RESULTADO = "resultado"; 
	
	private static final String MSG_ERROR = "disco.comprar.error";
	
	private static final String SUCCESS = "resultado"; 
	private static final String ERROR = "forward:/carrito/listar";
	
	@Autowired
	private CarritoSvc cSvc;

	
	@RequestMapping(value="/confirmar", method=RequestMethod.GET)	
    public String view(@ModelAttribute("sessionUser") Usuario usuario, @ModelAttribute("carrito") Carrito carrito, BindingResult result, Model model) {
		try{
			if (carrito == null){
				model.addAttribute(ATT_RESULTADO, 0.0);
			}else{				
				model.addAttribute(ATT_RESULTADO, cSvc.total(carrito));
			}
			
			//Anotar la compra
			cSvc.comprar(carrito, usuario);
			
			//Resetear el carrito
			model.addAttribute(ATT_CARRITO, new Carrito());
			
			return SUCCESS;
		}catch (Exception ex){		
			log.error(ex);
			result.reject(MSG_ERROR);
			return ERROR;
		}
	}

}
