package es.hubiqus.boot.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.hubiqus.boot.model.Genero;
import es.hubiqus.boot.model.dao.GeneroDao;
import es.hubiqus.boot.service.GeneroSvc;
import es.hubiqus.boot.service.SvcException;

/**
 * Implementación del servicio de géneros
 * @author ajurado
 *
 */
@Service
public class GeneroSvcImpl implements GeneroSvc{
	
	@Autowired
	private GeneroDao dao;
	
	@Override
	public Iterable<Genero> listar() throws SvcException {
		Iterable<Genero> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
