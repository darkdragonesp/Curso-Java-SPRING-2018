package es.hubiqus.boot.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.boot.model.Disco;

/**
 * Crud básico: no necesita operaciones adicionales
 * En caso de implementación marcar con @Repository
 * @author ajurado
 *
 */
public interface DiscoDao extends CrudRepository<Disco, Integer> {
		
}
