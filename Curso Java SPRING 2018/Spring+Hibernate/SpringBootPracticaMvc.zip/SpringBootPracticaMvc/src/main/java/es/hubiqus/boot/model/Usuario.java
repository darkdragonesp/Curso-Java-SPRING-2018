package es.hubiqus.boot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;


/**
 * Información del usuario
 * @author ajurado
 *
 */
@Entity
@Table(name="usuario")
public class Usuario {

	private Integer id;
	private String nombre;
	private String apellidos;
	private String user;
	private String clave;
	private String claveRepetida;
	private TipoUsuario tipo;
	private String foto;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Email
	@NotEmpty
	@Column(name="usuario", unique=true)
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	@NotEmpty
	public String getClave() {
		return clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	@NotEmpty
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@NotEmpty
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	@ManyToOne
	@JoinColumn(name="tipoid")
	public TipoUsuario getTipo() {
		return tipo;
	}
	public void setTipo(TipoUsuario tipo) {
		this.tipo = tipo;
	}
	@NotEmpty
	@Transient
	public String getClaveRepetida() {
		return claveRepetida;
	}
	public void setClaveRepetida(String claveRepetida) {
		this.claveRepetida = claveRepetida;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
}
