package es.hubiqus.carrito.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Carrito que contendrá los productos seleccionados
 * @author ajurado
 *
 */
public class Carrito {

	private List<Producto> lista;
	
	public Carrito(){
		this.lista = new ArrayList<Producto>();
	}

	/**
	 * Obtener los productos que contiene el carrito
	 * @return lista de productos del carrito
	 */
	public List<Producto> getProductos() {
		return lista;
	}
	
}
