package es.hubiqus.carrito.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.service.CarritoSvc;
import es.hubiqus.carrito.service.ProductoSvc;

@Controller
@SessionAttributes("carrito")
public class Comprar {
	
	private static final String MSG_EXITO = "producto.comprar.exito";
	
	private static final String ATT_MSG = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "forward:/listar"; 
	private static final String ERROR = "error";
	
	@Autowired
	private ProductoSvc svc;
	
	@Autowired
	private CarritoSvc cSvc;
	
	@Autowired  
    private MessageSource messageSource;
	
//	@Autowired
//	private HttpSession session;
	
	@RequestMapping(value="/comprar", method=RequestMethod.GET)	
    public String view(@RequestParam int id, @ModelAttribute("carrito") Carrito carrito, Model model, Locale locale) {
		try{
			Producto producto = svc.buscar(id);
			
//			Carrito carrito = (Carrito) session.getAttribute(ATT_CARRITO);
//			if (carrito == null){
//				carrito = new Carrito();
//			}
			//Agregar producto
			cSvc.agregar(carrito, producto);
			
			model.addAttribute(ATT_MSG,
					messageSource.getMessage(MSG_EXITO, new Object[]{producto.getNombre()}, locale));
//			session.setAttribute(ATT_CARRITO, carrito);
			
			return SUCCESS;
			
		}catch (Exception ex){		
			model.addAttribute(ATT_ERROR, ex);
			return ERROR;
		}
	}

}
