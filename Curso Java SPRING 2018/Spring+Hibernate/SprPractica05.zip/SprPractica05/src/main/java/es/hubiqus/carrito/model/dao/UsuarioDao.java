package es.hubiqus.carrito.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.carrito.model.Usuario;

public interface UsuarioDao extends CrudRepository<Usuario, Integer>{

	/**
	 * Buscar por usuario y clave
	 * @param usuario
	 * @param clave
	 * @return
	 */
	public Usuario findByUsernameAndPassword(String username, String password);
}
