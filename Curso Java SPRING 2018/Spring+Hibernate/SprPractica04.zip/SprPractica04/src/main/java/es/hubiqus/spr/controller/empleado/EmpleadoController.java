package es.hubiqus.spr.controller.empleado;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import es.hubiqus.spr.model.Empleado;
import es.hubiqus.spr.service.DepartamentoSvc;
import es.hubiqus.spr.service.EmpleadoSvc;
import es.hubiqus.spr.service.SvcException;

/**
 * Control de las acciones de empleados
 * @author ajurado
 *
 */
@Controller
public class EmpleadoController {
	
	private static final String MSG_EXITO = "mensaje.exito";
	private static final String MSG_ERROR = "mensaje.error";
	
	private static final String ATT_ITEM = "empleado";
	private static final String ATT_EDIT = "editar";
	private static final String ATT_LISTA = "lista";
	private static final String ATT_EXITO = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String FORM = "form";
	private static final String LISTA = "resultado";
	private static final String ERROR = "error";
	
	@Autowired
	private EmpleadoSvc svc;
	
	@Autowired
	private DepartamentoSvc dSvc;
	
	@Autowired  
    private MessageSource messageSource;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		//Se encarga de parsear las fechas correctamente cuando vienen de formulario
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
	
	@RequestMapping(value="/listar", method=RequestMethod.GET)
    public String listar(Model model){
    	try {
			//Listado
			model.addAttribute(ATT_LISTA, svc.listar());
			
			return LISTA;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }
	
	/**
	 * Incluir los departamentos en el modelo
	 * @param model
	 * @throws SvcException 
	 */
	private void departamentos(Model model) throws SvcException{
		//Incluir elementos para la selección
		model.addAttribute(ATT_LISTA, dSvc.listar());
	}
	
	@RequestMapping(value="/guardar", method=RequestMethod.GET)
    public String view(@ModelAttribute Empleado empleado, Model model) {
		try {
			//Listado de departamentos
			departamentos(model);
			
			//Agregar como atributo el elemento recibido por parámetro
			model.addAttribute(ATT_ITEM, empleado);
			
			return FORM;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
	}
	
	@RequestMapping(value = "/guardar", method=RequestMethod.POST)
    public String guardar(@Valid Empleado empleado, BindingResult result, String editar, Model model, Locale locale) {
		try {
			//Comprobar si hay errores de entrada
			if (result.hasErrors()){
				//Mostrar sobre el propio formulario relleno
				return view(empleado, model);
			}else{
				//Guardar
				if (editar == null || editar.isEmpty()){
					svc.guardar(empleado);
				}else{
					svc.modificar(empleado);
				}
				
				//Mensaje de éxito
				model.addAttribute(ATT_EXITO, messageSource.getMessage(MSG_EXITO, null, locale));
				
				//Volver a empezar limpiando el formulario
				return view(new Empleado(), model);
			}
		} catch (Exception ex) {
			result.reject(MSG_ERROR);
			return FORM;
		}
    }
	
	@RequestMapping(value="/buscar", method=RequestMethod.GET)
    public String buscar(@RequestParam int id, Model model){
    	try {
//			model.addAttribute(ATT_ITEM, svc.buscar(id));
			model.addAttribute(ATT_EDIT, "true");

			//Listado de departamentos
//			departamentos(model);
			
			return view(svc.buscar(id), model);
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }
	
	@RequestMapping(value="/borrar", method=RequestMethod.GET)
    public String borrar(@RequestParam int id, Model model){
		try {
			Empleado empleado = new Empleado();
			empleado.setNumero(id);
			
			svc.eliminar(empleado);
			return listar(model);
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }
}
