package es.hubiqus.spr.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.spr.model.Departamento;

public interface DepartamentoDao extends CrudRepository<Departamento, Integer>{
	
}
