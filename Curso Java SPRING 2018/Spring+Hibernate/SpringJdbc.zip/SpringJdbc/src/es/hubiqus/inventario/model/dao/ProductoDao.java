package es.hubiqus.inventario.model.dao;

import java.util.List;

import es.hubiqus.inventario.model.Producto;

public interface ProductoDao {

	/**
	 * Guardar un registro
	 * @param producto elemento a guardar
	 * @throws DaoException error de bdd
	 */
	public void save(Producto producto) throws DaoException;
	
	/**
	 * Filtrar por nombre
	 * @param nombre criterio de filtrado
	 * @return lista de prodcutos
	 * @throws DaoException error de bdd
	 */
	public List<Producto> findByNombre(String nombre) throws DaoException;
	
}
