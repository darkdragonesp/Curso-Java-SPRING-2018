package es.hubiqus.inventario.model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

/**
 * Dao Jdbc empleando templates, no es necesario inyectar template ni datasource al heredar de JdbcDaoSupport
 *
 */
public class ProductoDaoImplJdbc extends JdbcDaoSupport implements ProductoDao{

	@Override
	public void save(Producto producto) throws DaoException{
		try{
			String sql = "INSERT INTO producto (nombre, cantidad, precio, comentario, fecha) VALUES(?,?,?,?,?)";

			//Establecer la sql y los parámetros para insertar
			getJdbcTemplate().update(sql, 
					producto.getNombre(), 
					producto.getCantidad(), 
					producto.getPrecio(),
					producto.getComentario(), 
					producto.getFecha());
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
	}
	
	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException{
		List<Producto> res = null;
		
		try{					
			String sql = "SELECT id, nombre, cantidad, precio, comentario, fecha FROM producto " +
						"WHERE nombre LIKE ?";
			
			//Consultar y pasar un RowMapper para cada iteración del ResultSet
			res = getJdbcTemplate().query(sql, 
	                new RowMapper<Producto>() {
	                    public Producto mapRow(ResultSet rs, int rowNum)
	                            throws SQLException{
	                    	return mapear(rs);
	                    }  
	                },
	                "%" + nombre + "%"
	                );
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}
	
	/**
	 * Obtener un producto desde el ResultSet
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Producto mapear(ResultSet rs) throws SQLException {
		Producto item = new Producto();
		item.setId(rs.getInt("id"));
		item.setNombre(rs.getString("nombre"));
		item.setCantidad(rs.getInt("cantidad"));
		item.setPrecio(rs.getDouble("precio"));
		item.setComentario(rs.getString("comentario"));
		item.setFecha(rs.getDate("fecha"));
		
		return item;
	}
}
