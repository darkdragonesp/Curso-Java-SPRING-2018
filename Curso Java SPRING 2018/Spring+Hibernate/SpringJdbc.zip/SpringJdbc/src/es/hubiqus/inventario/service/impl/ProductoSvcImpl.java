package es.hubiqus.inventario.service.impl;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.ProductoDao;
import es.hubiqus.inventario.service.ProductoSvc;
import es.hubiqus.inventario.service.SvcException;

public class ProductoSvcImpl implements ProductoSvc{
	
	private ProductoDao dao;
	
	public ProductoDao getDao() {
		return dao;
	}
	public void setDao(ProductoDao dao) {
		this.dao = dao;
	}
	
	@Override
	public void guardar(Producto producto) throws SvcException {
		try{
			dao.save(producto);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Override
	public Iterable<Producto> listar() throws SvcException {
		Iterable<Producto> res = null;
		
		try{
			res = dao.findByNombre("");
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
