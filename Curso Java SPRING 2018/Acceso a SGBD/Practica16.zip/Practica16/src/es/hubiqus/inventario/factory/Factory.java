package es.hubiqus.inventario.factory;

import es.hubiqus.inventario.model.dao.ProductoDao;
import es.hubiqus.inventario.model.dao.impl.JdbcDataSource;
import es.hubiqus.inventario.model.dao.impl.ProductoDaoImplPs;

/**
 * Generación de beans con patrón Singleton
 * @author ajurado
 *
 */
public class Factory {

	private static JdbcDataSource dataSource;
	private static ProductoDao productoDao;
	
	/**
	 * Obtener dataSource
	 * @return
	 */
	public static JdbcDataSource getDataSource() {
		if (dataSource == null) {
			try {
				JdbcDataSource bean = new JdbcDataSource();
				//Asignar valores de conexión
				bean.setUrl("jdbc:mysql://localhost:3306/inventario");
				bean.setUsername("root");
				bean.setPassword("");
				
				dataSource = bean;
			} catch (Exception ex) {
				dataSource = null;
			}
		}
		
		return dataSource;
	}
	
	/**
	 * Obtener ProductoDao
	 * @return
	 */
	public static ProductoDao getProductoDao(){
		if (productoDao == null){
			ProductoDaoImplPs bean = new ProductoDaoImplPs();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			productoDao = bean;
		}
		
		return productoDao;
	}

}
