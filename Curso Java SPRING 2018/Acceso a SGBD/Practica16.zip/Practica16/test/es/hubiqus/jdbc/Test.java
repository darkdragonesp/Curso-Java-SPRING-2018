package es.hubiqus.jdbc;

import java.util.Date;

import es.hubiqus.inventario.factory.Factory;
import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ProductoDao dao = Factory.getProductoDao();
		
		Producto item = new Producto();
		item.setNombre("nuevo");
		item.setCantidad(1);
		item.setPrecio(10.0);
		item.setFecha(new Date());
		item.setComentario("prueba");
		try {
			//Guardar nuevo
			dao.save(item);
			
			//Listar y recorrer
			Iterable<Producto> lista = dao.findByNombre("");
			for (Producto elem: lista){
				System.out.println(elem);
			}
		} catch (DaoException e) {
			e.printStackTrace();
		}
		
		
	}

}
