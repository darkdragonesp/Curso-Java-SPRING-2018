package es.hubiqus.practica2;

public class Test {

	public static void main(String[] args) {
		int size = 3;
		int[][] matriz = new int[size][size];
		int[] vector = { 3, 2, 1, 1, 2, 3, 2, 3, 1 };

		asignarDatos(vector, matriz);
		
		mostrar(matriz);
	}

	/**
	 * Inicializar la matriz
	 * 
	 * @param vector
	 *            datos iniciales
	 * @param matriz
	 *            matriz destino
	 */
	private static void asignarDatos(int[] vector, int[][] matriz) {
		// Compruebo que la longitud es compatible
		if (vector.length == matriz.length*matriz.length) {
			// �ndice para recorrer el array de entrada
			int indice = 0;
			for (int i = 0; i < matriz.length; i++) {
				for (int j = 0; j < matriz.length; j++) {
					// Asignar a la posici�n de la matriz
					matriz[i][j] = vector[indice++];
				}
			}
		} else {
			System.out.println("No compatible");
		}
	}

	/**
	 * Mostrar la matriz por consola
	 * @param matriz objeto a imprimir
	 */
	private static void mostrar(int[][] matriz) {
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
	}

}
