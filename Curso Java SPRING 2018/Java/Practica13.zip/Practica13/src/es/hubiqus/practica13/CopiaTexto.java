package es.hubiqus.practica13;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopiaTexto implements Copion{

	@Override
	public void copiar(String in, String out) throws IOException {
		BufferedReader entrada = null;
        BufferedWriter salida = null;
        
        try {
        		//abrimos fichero para lectura
        		FileReader ficheroOrigen = new FileReader(in);
            entrada = new BufferedReader(ficheroOrigen);
            //abrimos fichero para escritura
            FileWriter ficheroDestino = new FileWriter(out);
            salida = new BufferedWriter(ficheroDestino);

            String s = entrada.readLine();
            while (s != null) {
                salida.write(s);
                salida.newLine();
                //Cargamos otra vez
                s = entrada.readLine();
            }
        }finally{
	        	if (entrada != null){
	    			entrada.close(); 
	    		}
	    		if (salida != null){
	    			salida.close();
	    		}
        }
		
	}

}
