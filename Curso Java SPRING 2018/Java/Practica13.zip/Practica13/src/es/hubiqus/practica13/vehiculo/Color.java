package es.hubiqus.practica13.vehiculo;

/**
 * Colores permitidos
 * @author ajurado
 *
 */
public enum Color {
	ROJO, VERDE, AZUL
}
