package es.hubiqus.practica13;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import es.hubiqus.practica13.vehiculo.Color;
import es.hubiqus.practica13.vehiculo.Vehiculo;

public class CopiaCoche implements Copion{

	@Override
	public void copiar(String in, String out) throws IOException {
		DataInputStream entrada = null;
		DataOutputStream salida = null;
        
        try {
        		//abrimos fichero para lectura
            entrada = new DataInputStream(new BufferedInputStream(new FileInputStream(in)));
            //abrimos fichero para escritura
            salida = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(out)));

            Vehiculo v = leer(entrada);
            guardar(v, salida);
            
            //Datos del coche: 5 plazas y extras
            salida.writeInt(5);
            salida.writeBoolean(true);
        }finally{        		
        		if (entrada != null){
        			entrada.close(); 
        		}
        		if (salida != null){
        			salida.close();
        		}
        }		
	}
	
	/**
	 * Leer los datos de un vehículo
	 * @param entrada
	 * @return
	 * @throws IOException 
	 */
	private Vehiculo leer(DataInputStream entrada) throws IOException{
		Vehiculo v = new Vehiculo();
		v.setMatricula(entrada.readUTF());
		v.setColor(Color.valueOf(entrada.readUTF()));
		v.setPrecio(entrada.readInt());
		v.setReservado(entrada.readBoolean());
		
		return v;
	}
	
	/**
	 * Guardar los datos de un vehículo
	 * @param v
	 * @param salida
	 * @throws IOException
	 */
	private void guardar(Vehiculo v, DataOutputStream salida) throws IOException{
		salida.writeUTF(v.getMatricula());
        salida.writeUTF(v.getColor().toString());
        salida.writeInt(v.getPrecio());
        salida.writeBoolean(v.isReservado());
	}
	
	/**
	 * Guardar un coche en archivo
	 * @param v
	 * @throws IOException 
	 */
	public void guardar(Vehiculo v, String out) throws IOException{
		DataOutputStream salida = null;
        
        try {
        		//abrimos fichero para escritura
            salida = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(out)));

            //Escribir vehículo
            guardar(v, salida);
        }finally{
        		if (salida != null){
        			salida.close();
        		}
        }
	}

}
