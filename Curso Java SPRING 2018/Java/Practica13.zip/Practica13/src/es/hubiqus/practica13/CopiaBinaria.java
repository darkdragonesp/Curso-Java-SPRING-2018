package es.hubiqus.practica13;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopiaBinaria implements Copion{

	@Override
	public void copiar(String in, String out) throws IOException {
		FileInputStream ficheroOrigen = null;
		FileOutputStream ficheroDestino = null;
		BufferedInputStream entrada = null;
		BufferedOutputStream salida = null;
        
        try {
        		//abrimos fichero para lectura
            ficheroOrigen = new FileInputStream(in);
            entrada = new BufferedInputStream(ficheroOrigen);
            //abrimos fichero para escritura
            ficheroDestino = new FileOutputStream(out);
            salida = new BufferedOutputStream(ficheroDestino);

            int c;
            while ((c = ficheroOrigen.read())  != -1) {
                salida.write(c);
            }
        }finally{        		
        		if (entrada != null){
        			entrada.close(); 
        		}
        		if (ficheroOrigen != null){
        			ficheroOrigen.close(); 
        		}        		
        		if (salida != null){
        			salida.close();
        		}
        		if (ficheroDestino != null){
        			ficheroDestino.close();
        		}
        }
		
	}

}
