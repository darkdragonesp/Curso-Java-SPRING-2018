package es.hubiqus.practica13;

import java.io.IOException;

/**
 * Implementar por las clases que quieran realizar copia de archivos
 * @author ajurado
 *
 */
public interface Copion {

	/**
	 * Copiar un archivo de entrada a un archivo de salida
	 * @param in
	 * @param out
	 */
	public void copiar(String in, String out) throws IOException;
	
}
