package es.hubiqus.practica13;

import java.io.IOException;

import es.hubiqus.practica13.vehiculo.Color;
import es.hubiqus.practica13.vehiculo.Vehiculo;

public class Test {

	public static void main(String[] args) {		
		try {
			//Copia de archivo binario
			Copion copiaBin = new CopiaBinaria();
			copiaBin.copiar("in.png", "out.png");
			
			//Copia de archivo binario
			Copion copiaTexto = new CopiaTexto();
			copiaTexto.copiar("in.txt", "out.txt");
			
			//Copia de archivo binario con texto
			copiaTexto.copiar("in.png", "outbin.png");
			
			Copion copiaCoche = new CopiaCoche();
			Vehiculo v = new Vehiculo("123ABC",Color.ROJO,false,10000);
			((CopiaCoche) copiaCoche).guardar(v, "inv.txt");
			copiaCoche.copiar("inv.txt", "outc.txt");
			
			copiaBin.copiar("inv.txt", "outcb.txt");
			copiaTexto.copiar("inv.txt", "outct.txt");
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
