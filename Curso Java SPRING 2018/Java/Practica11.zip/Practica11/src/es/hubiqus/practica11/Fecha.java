package es.hubiqus.practica11;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Fecha según calendario Gregoriano
 * @author ajurado
 *
 */
public class Fecha implements Comparable<Fecha>{

    protected Calendar cal;

    /**
     * Constructor
     * @param d
     * @param m
     * @param a
     * @throws RuntimeException
     */
    public Fecha(int d, int m, int a) {
    		//Crear calendario local
        this.cal = Calendar.getInstance(Locale.getDefault());
        //Cambiar datos
        cal.set(Calendar.DAY_OF_MONTH, d);
        cal.set(Calendar.MONTH, m-1);
        cal.set(Calendar.YEAR, a);
        //Limpiar la hora
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
    }

     /**
     * Número de días de un mes y un año
     * @param m
     * @param a
     * @return
     */
    public static int numeroDeDias(int m, int a) {
    		Calendar cal = Calendar.getInstance();
    		cal.set(Calendar.MONTH, m-1);
        cal.set(Calendar.YEAR, a);
        
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    /**
     * Número de días de un año
     * @param a
     * @return
     */
    public static int numeroDeDias(int a) {
    		Calendar cal = Calendar.getInstance();
    		cal.set(Calendar.YEAR, a);
        
        return cal.getActualMaximum(Calendar.DAY_OF_YEAR);
    }

    /**
     * Comprobar si un año es bisiesto
     * @param anyo
     * @return
     */
    public static boolean esBisiesto(int anyo) {
        return numeroDeDias(anyo) == 366;
    }

    public int getDia() {
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    public int getMes() {
        return cal.get(Calendar.MONTH)+1;
    }

    public int getAnyo() {
        return cal.get(Calendar.YEAR);
    }

    /**
     * Días que han pasado desde el 01/01
     * @return
     */
    public int diasTranscurridosDelAnyo() {
        return cal.get(Calendar.DAY_OF_YEAR);
    }

    /**
     * Días que quedan hasta el 31/12
     * @return
     */
    public int diasRestantesDelAnyo() {
        return numeroDeDias(getAnyo()) - diasTranscurridosDelAnyo();
    }

    /**
     * Diferencia de días con una fecha
     * @param f
     * @return
     */
    public int diferenciaDeDiasCon(Fecha f) {    	
	    	//Cifra por la que se va a dividir para transformar en días
	    	long milis = 1000*60*60*24;
	    	//Fechas en milisegundos
	    	long mCal = cal.getTimeInMillis();
	    	long fCal = f.cal.getTimeInMillis();
	    	int diasDiferencia;
	    	
	    	//La fecha actual es inferior a la base
	    	if (mCal < 0){    		
	    		if (fCal < 0){
	    			//Ambos son menores
	    			diasDiferencia = (int) ((fCal - mCal)/milis);
	    		}else{
	    			//Días hasta la base
	    			int diasAntes = -(int) (mCal / milis);
	    			diasDiferencia = (int) (fCal / milis) + diasAntes + 1; //Se suma el día base
	    		}
	    	}else{
	    		if (fCal < 0){
	    			//Días hasta la base
	    			int diasAntes = -(int) (fCal / milis);
	    			diasDiferencia = (int) (mCal / milis) + diasAntes + 1; //Se suma el día base
	    		}else{
	    			//Ambos son mayores
	    			diasDiferencia = (int) ((fCal - mCal)/milis);
	    		}
	    	}
	    	
	    	return diasDiferencia;
    }

    /**
     * Incrementar la fecha en un día
     */
    public void diaSiguiente() {
        cal.add(Calendar.DAY_OF_YEAR, 1);
    }

    /**
     * Decrementar la fecha en un día
     */
    public void diaAnterior() {
    		cal.add(Calendar.DAY_OF_YEAR, -1);
    }

    /**
     * Trasladar la fecha n días (positivo o negativo)
     * @param ndias
     */
    public void trasladar(int ndias) {
    		cal.add(Calendar.DAY_OF_YEAR, ndias);
    }

    @Override
    public String toString() {
    		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(cal.getTime());
    }

    @Override
    public int compareTo(Fecha f) {
        return cal.compareTo(f.cal);
    }
}
