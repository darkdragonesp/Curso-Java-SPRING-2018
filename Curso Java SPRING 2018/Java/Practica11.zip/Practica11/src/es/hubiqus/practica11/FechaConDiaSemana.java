package es.hubiqus.practica11;

import java.util.Calendar;
import java.util.Locale;

/**
 * Fecha con día de la semana
 * @author ajurado
 */
public class FechaConDiaSemana extends Fecha {

    /**
     * Constructor
     * @param d
     * @param m
     * @param a
     */
    public FechaConDiaSemana(int d, int m, int a) {
        super(d, m, a);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
    }

    /**
     * Obtener el día de la semana (1 = DOMINGO)
     * @return
     */
    public int diaSemana() {
        return cal.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * Obtener el nombre del día de la semana
     * @return
     */
    public String nombreDiaSemana() {
        return cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()).toUpperCase();
    }

    @Override
    public String toString() {
        return this.nombreDiaSemana() + ": " + super.toString();
    }
}