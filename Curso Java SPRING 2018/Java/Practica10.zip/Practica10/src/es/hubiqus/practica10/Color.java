package es.hubiqus.practica10;

/**
 * Colores permitidos
 * @author ajurado
 *
 */
public enum Color {
	ROJO, VERDE, AZUL
}
