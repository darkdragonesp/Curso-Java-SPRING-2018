package es.hubiqus.practica5;

public class Test {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		Matriz m = new Matriz(3);
		Matriz n = new Matriz(3);
		
		int[] vector = {3, 2, 1, 1, 2, 3, 2, 3, 1};
		m.asignarDatos(vector);
		
		m.asignarDatos(new int[] {3, 2, 1, 1, 2, 3, 2, 3, 1});
		
		int[] v = new int[9];
		v[0] = 3;
		v[1] = 2;
		//...
		
		int[] vector2 = {1, 1, 2, 2, 1, 1, 1, 2, 1};
		n.asignarDatos(vector2);
		
//		m.mostrar();
//		n.mostrar();
		System.out.println(m);
		System.out.println(n);
		
		m.producto(n);
//		Matriz z = Matriz.producto(m, n);
//		m.mostrar();
		System.out.println(n);
		
		m.suma(n);
//		m.mostrar();
		System.out.println(n);
	}

}
