package es.hubiqus.practica3;

public class Test {

	public static void main(String[] args) {
		Punto p = new Punto();

		System.out.println(p.getX() + "," + p.getY());
		
		p.trasladar(7, 4);
		System.out.println(p);
	}

}
