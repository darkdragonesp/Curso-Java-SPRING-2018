package es.hubiqus.practica7.test;

import es.hubiqus.practica7.FechaConDiaSemana;

/**
 * Práctica 2: Gregorian Calendar
 * @author Clases más usadas
 */
public class FechasDePrueba {

    public static void main(String[] args) {
    		int anyo = 2017;

        FechaConDiaSemana hoy = new FechaConDiaSemana(26, 5, anyo); // cambiar por fecha actual

        int diasT = hoy.diasTranscurridosDelAnyo();
        int diasR = hoy.diasRestantesDelAnyo();

        System.out.println("Fecha de hoy " + hoy);
        System.out.println("Dias transcurridos " + diasT);
        System.out.println("Dias que restan    " + diasR);

        // Día del padre: 19 de Marzo -------------------------
        FechaConDiaSemana sj = new FechaConDiaSemana(19, 3, anyo);
        System.out.println("El día del padre de " + anyo + ": " + sj);


        // Día de la madre: primer domingo de Mayo
        sj = new FechaConDiaSemana(1, 5, anyo);
        while (sj.diaSemana() != 6) { //hasta que no sea domingo
            sj.diaSiguiente();
        }
        System.out.println("El día de la madre de " + anyo + ": " + sj);

        // días que faltan:
        int diferencia = hoy.diferenciaDeDiasCon(sj);
        System.out.println("Para este día faltan " + diferencia + " días");

        // 19 de Marzo de 1625 -------------------------------------------------
        // (no era día del padre, el Corte Inglés se funda años más tarde)
        sj = new FechaConDiaSemana(19, 3, 1625);
        System.out.println("El 19 de Marzo de 1625 cayó en " + sj.nombreDiaSemana());
        System.out.println("Días transcurridos: " + sj.diferenciaDeDiasCon(hoy));

        // Dentro de 10000 días -------------------------------------------------
        hoy.trasladar(10000);
        System.out.println("Dentro de 10000 días será el " + hoy);

    }
}
