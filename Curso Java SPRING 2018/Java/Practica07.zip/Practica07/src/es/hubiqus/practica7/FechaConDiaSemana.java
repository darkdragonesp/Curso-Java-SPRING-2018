package es.hubiqus.practica7;

/**
 * Fecha con día de la semana
 * @author ajurado
 */
public class FechaConDiaSemana extends Fecha {

    private final static String[] DIA_SEMANA = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    private final static Fecha LUNES_DE_REFERENCIA = new Fecha(24, 3, 2003);

    private int diaSemana;

    /**
     * Constructor
     * @param d
     * @param m
     * @param a
     */
    public FechaConDiaSemana(int d, int m, int a) {
        super(d, m, a);
        if (this.getDia() > 0) {
            int dif = LUNES_DE_REFERENCIA.diferenciaDeDiasCon(this) % 7;
            if (dif >= 0) {
                diaSemana = dif;
            } else {
                diaSemana = dif + 7;
            }
        }
    }

    /**
     * Obtener el día de la semana (0 = LUNES)
     * @return
     */
    public int diaSemana() {
        return diaSemana;
    }

    /**
     * Obtener el nombre del día de la semana
     * @return
     */
    public String nombreDiaSemana() {
        return DIA_SEMANA[diaSemana];
    }

    @Override
    public void diaSiguiente() {
        super.diaSiguiente();
        ++diaSemana;
        if (diaSemana == 7) {
            diaSemana = 0;
        }
    }

    @Override
    public void diaAnterior() {
        super.diaAnterior();
        --diaSemana;
        if (diaSemana == -1) {
            diaSemana = 6;
        }
    }

//    @Override
//    public void trasladar(int ndias) {
//        if (ndias >= 0) {
//            for (int i = 1; i <= ndias; i++) {
//                diaSiguiente();
//            }
//        } else {
//            for (int i = 1; i <= -ndias; i++) {
//                diaAnterior();
//            }
//        }
//    }

    @Override
    public String toString() {
        return DIA_SEMANA[diaSemana] + ": " + super.toString();
    }
}