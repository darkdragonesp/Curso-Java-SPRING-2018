package es.hubiqus.practica7;

/**
 * Fecha según calendario Gregoriano
 * @author ajurado
 *
 */
public class Fecha implements Comparable<Fecha>{

    private int dia;
    private int mes;
    private int anyo;

    /**
     * Constructor
     * @param d
     * @param m
     * @param a
     * @throws RuntimeException
     */
    public Fecha(int d, int m, int a) {//throws Exception {
        if (fechaCorrecta(d, m, a)) {
            dia = d;
            mes = m;
            anyo = a;
        } 
//        else {	// Fecha incorrecta
//            throw new Exception("Datos erróneos: (" + d + "/" + m + "/" + a + ")");
//        }
    }

    /**
     * Comprobar que una fecha sea correcta
     * @param d
     * @param m
     * @param a
     * @return
     */
    private boolean fechaCorrecta(int d, int m, int a) {
        boolean test = false;
        if (a > 1582 || 
        		(a == 1582 && m > 10) || 
        		(a == 1582 && m == 10 && d > 14)) {
            test = (0 < d) && (d <= numeroDeDias(m, a));
        }
        return test;
    }

    /**
     * Número de días de un mes y un año
     * @param m
     * @param a
     * @return
     */
    public static int numeroDeDias(int m, int a) {
        int numD;
        switch (m) {
            case 2:
                numD = 28;
                if (esBisiesto(a)) {
                    ++numD;
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                numD = 30;
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                numD = 31;
                break;
            default:
                numD = 0;
                break; // entrada errónea

        }
        return numD;
    }

    /**
     * Número de días de un año
     * @param a
     * @return
     */
    public static int numeroDeDias(int a) {
        int numD = 365;
        if (esBisiesto(a)) {
            numD = 366;
        }
        return numD;
    }

    /**
     * Comprobar si un año es bisiesto
     * @param anyo
     * @return
     */
    public static boolean esBisiesto(int anyo) {
        return (anyo % 400 == 0) || (anyo % 4 == 0 && anyo % 100 != 0);
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAnyo() {
        return anyo;
    }

    /**
     * Días que han pasado desde el 01/01
     * @return
     */
    public int diasTranscurridosDelAnyo() {
        int total = 0;
        for (int i = 1; i < mes; i++) {
            total += numeroDeDias(i, anyo);
        }
        return (total + dia);
    }

    /**
     * Días que quedan hasta el 31/12
     * @return
     */
    public int diasRestantesDelAnyo() {
        int total = 0;
        for (int i = mes; i <= 12; i++) {
            total += numeroDeDias(i, anyo);
        }
        return (total - dia);
    }

    /**
     * Diferencia de días con una fecha
     * @param f
     * @return
     */
    public int diferenciaDeDiasCon(Fecha f) {
        int c, diferencia;
        c = this.compareTo(f);
        if (c == 0) {		// las fechas son iguales
            diferencia = 0;
        } else if (c < 0) { // la fecha actual es anterior
            if (anyo < f.anyo) {
                diferencia = this.diasRestantesDelAnyo();
                for (int a = anyo + 1; a < f.anyo; ++a) {
                    diferencia += numeroDeDias(a);
                }
                diferencia += f.diasTranscurridosDelAnyo();
            } else { // anyo == f.anyo

                diferencia = f.diasTranscurridosDelAnyo() -
                        this.diasTranscurridosDelAnyo();
            }
        } else {			// la fecha actual es posterior
            if (f.anyo < anyo) {
                diferencia = f.diasRestantesDelAnyo();
                for (int a = f.anyo + 1; a < anyo; ++a) {
                    diferencia += numeroDeDias(a);
                }
                diferencia += this.diasTranscurridosDelAnyo();
            } else { // f.anyo == anyo

                diferencia = this.diasTranscurridosDelAnyo() -
                        f.diasTranscurridosDelAnyo();
            }
            diferencia = -diferencia;
        }
        return diferencia;
    }

    /**
     * Incrementar la fecha en un día
     */
    public void diaSiguiente() {
        ++dia;
        if (dia > numeroDeDias(mes, anyo)) {
            dia = 1;
            ++mes;
            if (mes > 12) {
                mes = 1;
                ++anyo;
            }
        }
    }

    /**
     * Decrementar la fecha en un día
     */
    public void diaAnterior() {
        --dia;
        if (dia == 0) {
            --mes;
            if (mes == 0) {
                mes = 12;
                --anyo;
            }
            dia = numeroDeDias(mes, anyo);
        }
    }

    /**
     * Trasladar la fecha n días (positivo o negativo)
     * @param ndias
     */
    public void trasladar(int ndias) {
        if (ndias >= 0) {
            for (int i = 1; i <= ndias; i++) {
                diaSiguiente();
            }
        } else {
            for (int i = 1; i <= -ndias; i++) {
                diaAnterior();
            }
        }
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + anyo;
    }

    @Override
    public int compareTo(Fecha f) {
        int test = 0;
        if (anyo < f.anyo ||
                (anyo == f.anyo && mes < ((Fecha) f).mes) ||
                (anyo == f.anyo && mes == ((Fecha) f).mes && dia < ((Fecha) f).dia)) {
            test = -1;
        } else if (anyo == ((Fecha) f).anyo &&
                mes == f.mes &&
                dia == f.dia) {
            test = 0;
        } else {
            test = 1;
        }
        return test;
    }
}
