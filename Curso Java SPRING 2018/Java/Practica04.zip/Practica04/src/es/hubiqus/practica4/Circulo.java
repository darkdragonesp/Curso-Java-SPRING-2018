package es.hubiqus.practica4;

/**
 * Representación de un círculo en el plano
 * @author ajurado
 *
 */
public class Circulo {
	
	private int radio;
	private Punto centro;
	
	public int getRadio() {
		return radio;
	}
	public void setRadio(int radio) {
		this.radio = radio;
	}
	public Punto getCentro() {
		return centro;
	}
	public void setCentro(Punto centro) {
		this.centro = centro;
	}
	
	/**
	 * Constructor principal
	 * @param c centro del círculo
	 * @param r radio actual
	 */
	public Circulo(Punto c, int r){
		centro = c;
		radio = r;
	}
	
	public Circulo(){
		this(new Punto(), 1);
	}
	
	/**
	 * Trasladar un círculo dadas coordenadas
	 * @param vx valor para el eje x
	 * @param vy valor para el eje y
	 */
	public void trasladar(int vx, int vy){
		//Traslado el centro para trasladar el círculo
		centro.trasladar(vx, vy);
	}
	
	@Override
	public String toString() {
		return "[" + centro + ", " + radio + "]";
	}

	
}
