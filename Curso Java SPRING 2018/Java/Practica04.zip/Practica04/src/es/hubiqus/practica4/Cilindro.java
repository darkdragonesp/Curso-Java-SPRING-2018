package es.hubiqus.practica4;

/**
 * Representación de un cilindro en el plano
 * @author ajurado
 *
 */
public class Cilindro {
	
	private int altura;
	private Circulo base;
	
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	public Circulo getBase() {
		return base;
	}
	public void setBase(Circulo base) {
		this.base = base;
	}

	/**
	 * Constructor principal
	 * @param c base del cilindro
	 * @param a altura actual
	 */
	public Cilindro(Circulo c, int a){
		base = c;
		altura = a;
	}
	
	public Cilindro(){
		this(new Circulo(), 1);
	}
	
	/**
	 * Trasladar un cilindro dadas coordenadas
	 * @param vx valor para el eje x
	 * @param vy valor para el eje y
	 */
	public void trasladar(int vx, int vy){
		//Traslado la base para trasladar el cilindro
		base.trasladar(vx, vy);
	}
	
	@Override
	public String toString() {
		return "[" + base + ", " + altura + "]";
	}

	
}
