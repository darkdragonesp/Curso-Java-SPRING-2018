package es.hubiqus.practica4;

/**
 * Clase que representa un punto del plano
 * @author ajurado
 *
 */
public class Punto {
	private int x;
	private int y;
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	/**
	 * Constructor principal de la clase
	 * @param x valor de la x
	 * @param y valor de la y
	 */
	public Punto(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Constructor sin argumentos, crea el punto 0,0
	 */
	public Punto(){
		this(0, 0);
	}
	
	/**
	 * Trasladar el punto en el plano
	 * @param x 
	 * @param y
	 */
	public void trasladar(int x, int y){
		this.x += x;
		this.y += y;
	}

	@Override
	public String toString() {
		return "(" + x + "," + y + ")";
	}	
	
}
