package es.hubiqus.practica12;

public class Simulacion {

    // Máx de alertas
    private static final int ALERTAS_CALOR = 15;
    private static final int ALERTAS_FRIO = 5;
    //Parada
    private static final int SLEEP = 1000;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Variable controladora del bucle
        boolean fin = false;
        // Contadores de alertas
        int numAlertasCalor = 0;
        int numAlertasFrio = 0;
        
        ControladorMemoria control = new ControladorMemoria(new Sala());
        
        while (!fin) {
            try {
                control.controlar();
            } catch (DemasiadoCalor lim) {
                    System.out.println("Capturado excesivo calor.");
                    // Aumentar el nº de alertas
                    numAlertasCalor++;
            } catch (DemasiadoFrio lim) {        
            			System.out.println("Capturado excesivo frío.");
                    // Aumentar el nº de alertas
                    numAlertasFrio++;
            } finally {
                // Espera un poco antes de obtener Tº
                try {
                    Thread.sleep(SLEEP);
                } catch (InterruptedException e) {
                    ;
                }
                // Finalizar el bucle
                fin = (numAlertasCalor == ALERTAS_CALOR || 
                			numAlertasFrio == ALERTAS_FRIO);
            }
        }
        if (numAlertasCalor == ALERTAS_CALOR) {
            System.out.println("Fin por CALOR.");
        }else if (numAlertasFrio == ALERTAS_FRIO) {
            System.out.println("Fin por FRIO.");
        }
    }
}
