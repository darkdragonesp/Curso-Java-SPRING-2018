package es.hubiqus.practica12;

public class DemasiadoFrio extends Exception {

    /**
     * Constructor sin argumentos
     */
    public DemasiadoFrio() {
    }


    /**
     * Constructor con mensaje
     * @param msg
     */
    public DemasiadoFrio(String msg) {
        super(msg);
    }
}
