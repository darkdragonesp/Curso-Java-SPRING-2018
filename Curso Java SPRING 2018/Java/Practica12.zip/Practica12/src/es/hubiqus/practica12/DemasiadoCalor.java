package es.hubiqus.practica12;

public class DemasiadoCalor extends Exception {

    /**
     * Constructor sin argumentos
     */
    public DemasiadoCalor() {
    }


    /**
     * Constructor con mensaje
     * @param msg
     */
    public DemasiadoCalor(String msg) {
        super(msg);
    }
}
