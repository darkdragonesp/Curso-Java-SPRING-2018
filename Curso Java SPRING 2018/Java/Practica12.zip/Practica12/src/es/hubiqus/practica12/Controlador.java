package es.hubiqus.practica12;

public class Controlador {
	
	// Límite superior de Tª
    public static final int LIMITE_SUPERIOR = 50;
    // Límite inferior de Tª
    public static final int LIMITE_INFERIOR = 20;
	
	private Sala sala;
	
	/**
	 * Constructor de controlador a partir de una sala
	 * @param sala
	 */
	public Controlador(Sala sala){
		this.sala = sala;
	}
	
	/**
	 * Controlar la temperatura de la sala
	 * @throws DemasiadoCalor 
	 * @throws DemasiadoFrio 
	 */
	public void controlar() throws DemasiadoCalor, DemasiadoFrio{
		int temp = sala.getTemperatura();
		if (temp > LIMITE_SUPERIOR) {
            throw new DemasiadoCalor();
        }
        if (temp < LIMITE_INFERIOR) {
            throw new DemasiadoFrio();
        }
	}

}
