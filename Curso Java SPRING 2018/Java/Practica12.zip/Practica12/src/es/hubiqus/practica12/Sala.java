package es.hubiqus.practica12;

import java.util.Random;

public class Sala {
	
	// Límite superior de Tª
    public static final int LIMITE_SUPERIOR = 90;
    // Límite inferior de Tª
    public static final int LIMITE_INFERIOR = 0;
	
	private Random rnd;
	
	public Sala(){
		rnd = new Random();
	}
	
	/**
	 * Obtener la temperatura de la sala
	 * @return valor aleatorio entre 0 y 90
	 */
	public int getTemperatura(){
		return rnd.nextInt(LIMITE_SUPERIOR + 1);
	}

}
