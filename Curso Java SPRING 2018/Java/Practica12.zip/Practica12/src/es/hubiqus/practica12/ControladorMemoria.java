package es.hubiqus.practica12;

public class ControladorMemoria extends Controlador{

	private Exception memoria;
	
	/**
	 * Constructor de controlador a partir de una sala
	 * @param sala
	 */
	public ControladorMemoria(Sala sala){
		super(sala);
	}
	
	@Override
	public void controlar() throws DemasiadoCalor, DemasiadoFrio {
		try{			
			super.controlar();
			//Si no hay error la memoria se resetea
			memoria = null;
		}catch (DemasiadoCalor|DemasiadoFrio ex){
			//Java 1.7 - capturar más de un tipo de excepción con catch
			memoria = ex;
			throw ex;
		}
	}
	
	/**
	 * Obtener el valor de la última excepción producida
	 * @return
	 */
	public Exception getMemoria(){
		return memoria;
	}
}
