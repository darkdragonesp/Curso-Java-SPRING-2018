package es.hubiqus.practica15;

public class TorneoException extends RuntimeException {

    public TorneoException() {
        super();
    }

    public TorneoException(String msg) {
        super(msg);
    }
}
