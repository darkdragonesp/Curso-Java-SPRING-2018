package es.hubiqus.practica15;

import java.util.*;

/**
 * Partido entre dos equipos.
 * El método ganador/perdedor provoca que se juegue el partido
 * @author ajurado
 *
 */
public class Partido {

    private Equipo j1, j2;
    private Equipo ganador;

    /**
     * Constructor con equipos distintos
     * @param jugador1
     * @param jugador2
     */
    public Partido(Equipo jugador1, Equipo jugador2) {
        if (jugador1.equals(jugador2)) {
        	throw new TorneoException("Equipo repetido");
        } else {
        	j1 = jugador1;
            j2 = jugador2;            
        }
    }

    /**
     * Jugar un partido
     */
    public void jugar() {
        int p1 = j1.getTitulos();
        int p2 = j2.getTitulos();
        Random simulador = new Random();
        int resultado = 1 + simulador.nextInt(p1 + p2);
        if (resultado <= p1) {
            ganador = j1;
        } else {
            ganador = j2;
        }
    }

    /**
     * Ganador del partido. Si no se ha jugado lo juega.
     * @return equipo ganador.
     */
    public Equipo ganador() {
        if (ganador == null) {
            jugar();
        }
        return ganador;
    }

    /**
     * Perdedor del partido. Si no se ha jugado lo juega.
     * @return equipo perdedor.
     */
    public Equipo perdedor() {
        Equipo perdedor;
        if (ganador == null) {
            jugar();
        }
        if (ganador.equals(j1)) {
            perdedor = j2;
        } else {
            perdedor = j1;
        }
        return perdedor;
    }

    @Override
    public String toString() {
        String salida = null;
        if (ganador == null) {
            salida = j1 + " v.s. " + j2;
        } else if (ganador.equals(j1)) {
            salida = j1.toString().toUpperCase() + " v.s. " + j2;
        } else {
            salida = j1 + " v.s. " + j2.toString().toUpperCase();
        }
        return salida;
    }
}
