package es.hubiqus.practica15;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Torneo entre equipos.
 * Para jugarlo el número de participantes tiene que ser potencia de 2
 * @author ajurado
 *
 */
public class Torneo {

    private SortedSet<Equipo> participantes;
    private List<Partido> tablero;

    /**
     * Inicializar el torneo
     */
    public Torneo() {        
        this.participantes = new TreeSet<Equipo>();
    }
    
    /**
     * Inscribir un equipo en el torneo
     * @param equipo
     */
    public void inscribir(Equipo equipo){
    	participantes.add(equipo);
    }
    
    /**
     * Jugar una ronda del torneo
     */
    public void jugar(){
    	if (esPotenciaDe2(participantes.size())) {
    		//Limpiar el tablero
	    	this.tablero = new ArrayList<Partido>();
	    	
	    	//Si hay participantes
	    	while (!participantes.isEmpty()){
	    		//Los partidos se juegan por cabezas de serie (1 vs 8, 2 vs 7, ...)
	    		Equipo e1 = participantes.first();
	    		Equipo e2 = participantes.last();
	    		//Eliminar de la tabla
	    		participantes.remove(e1);
	    		participantes.remove(e2);
	    		
	    		//Agregar al tablero
	    		tablero.add(new Partido(e1, e2));
	    	}    		
	    	
	    	//Jugar todos los partidos del tablero
	    	for (Partido p: tablero){
	    		p.jugar();
	    		//Guardar los equipos que aún quedan
	    		participantes.add(p.ganador());
	    	}
        }else{
        	throw new TorneoException("Número de equipos no válido");
        }	    	
    }
    
    /**
     * Jugar el torneo completo
     * @param out salida del torneo
     */
    public void torneo(PrintStream out){
    	int ronda = 0;
		
    	//Mientras que no haya ganador
		while (ganador() == null){
			out.println("Round " + ronda++);
			//Jugar la ronda
			jugar();
			out.println(this);
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				;
			}
		}
		
		out.println("CHAMPION");
		out.println(ganador());
    }
    
    /**
     * Obtener el ganador del torneo
     * @return Equipo ganador o null si aún no ha acabado el torneo.
     */
    public Equipo ganador(){
	    	Equipo res = null;
	    	if ((tablero != null) && (tablero.size() == 1)){
	    		res = tablero.get(0).ganador();
	    	}
	    	return res;
    }
    
    @Override
    public String toString(){
	    	String res = "";
	    	for (Partido p: tablero){
	    		res += p + "\n";
	    	}
	    	
	    	return res;
    }
    
    /**
     * Comprobar si el número de participantes es potencia de 2
     * @param n
     * @return
     */
    private boolean esPotenciaDe2(int n) {
        int p = 2;
        while (p < n) {
            p = 2 * p;
        }
        return (p == n);
   }

}		
