package es.hubiqus.practica15;

/**
 * Práctica 1: Practicar con clases, excepciones, colecciones, entrada y salida de datos,...
 * @author Colecciones
 */
public class Test {
	public static void main(String[] args){
		Torneo t = new Torneo();
		t.inscribir(new Equipo("Cadi", "Cádiz", 1735, 8));
		t.inscribir(new Equipo("Málaga", "Málaga", 1973, 5));
		t.inscribir(new Equipo("Betis", "Sevilla", 1556, 5));
		t.inscribir(new Equipo("Sevilla", "Sevilla", 2008, 6));
		t.inscribir(new Equipo("Madrid", "Madrid", 1325, 10));
		t.inscribir(new Equipo("Barza", "Barcelona", 1993, 52));
		t.inscribir(new Equipo("Atleti", "Madrid", 1756, 51));
		t.inscribir(new Equipo("Rayo", "Madrid", 1908, 6));
		
		
		t.torneo(System.out);
		
//		File f = new File("torneo.txt");
//		PrintStream st = new PrintStream(f);
//		t.torneo(st);
//		st.close();
	}

}
