package es.hubiqus.practica15;

/**
 * Representa un equipo
 * @author ajurado
 *
 */
public class Equipo implements Comparable<Equipo> {

    private String nombre;
    private String ciudad;
    private int anyo;
    private int titulos;

    /**
     * Constructor con los datos del equipo
     * @param nombre
     * @param ciudad
     * @param anyo
     * @param titulos
     */
    public Equipo(String nombre, String ciudad, int anyo, int titulos) {
		super();
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.anyo = anyo;
		this.titulos = titulos;
	}
    
    public int getTitulos() {
		return titulos;
	}

	@Override
    public boolean equals(Object obj) {
        return nombre.equals(((Equipo) obj).nombre);
    }

    @Override
    public int compareTo(Equipo ob) {
    	//Comparar títulos
        int res = titulos - ob.titulos;
        if (res == 0) {
        	//En caso de empate se compara año de fundación
            res = Integer.valueOf(anyo).compareTo(Integer.valueOf(ob.anyo));
        }
        return res;
    }

    @Override
    public int hashCode() {
        return nombre.hashCode();
    }

    @Override
    public String toString() {
        return nombre + "-" + ciudad;
    }
}
