package es.hubiqus.practica14.vehiculo;

import java.io.File;
import java.io.IOException;

import es.hubiqus.practica14.file.VehiculoFile;
import es.hubiqus.practica14.file.VehiculoFileException;

/**
 * Concesionario de vehículos
 * @author Lenguaje Java Básico
 */
public class Concesionario {
	
	private static final String DIR = "/Users/ajurado/Documents/workspace201804/Practica14";

     private String nombre;
     private String direccion;
     private int telefono;
     private VehiculoFile vFile;

     /**
      * Constructor básico
      */
     public Concesionario() {
    	 	vFile = new VehiculoFile(new File(DIR));
     }

     /**
      * Constructor completo
      * @param nom
      * @param dir
      * @param telf
      */
     public Concesionario(String nom, String dir, int telf) {
    	 	this();
        this.nombre = nom;
        this.direccion = dir;
        this.telefono = telf;          
     }

     public void setNombre(String nombre) {
          this.nombre = nombre;
     }

     public void setDireccion(String direccion) {
          this.direccion = direccion;
     }

     public void setTelefono(int telefono) {
          this.telefono = telefono;
     }

     public String getDireccion() {
          return direccion;
     }

     public String getNombre() {
          return nombre;
     }

     public int getTelefono() {
          return telefono;
     }

     @Override
     public String toString() {
          String cad;
          cad = "Concesionario: " + "\n" +
                  "Nombre: " + getNombre() + "\n" +
                  "Direccion: " + getDireccion() + "\n" +
                  "Telefono: " + getTelefono() + "\n";
          try{
	          Vehiculo[] vehiculos = this.buscar();
	          for (int i = 0; i < vehiculos.length; i++) {
	              if (vehiculos[i] != null) {
	                   cad = cad + "Vehiculo =>" + vehiculos[i] + "\n";
	              }
	          }
          }catch (Exception ex){
        	  	cad += "No hay vehículos";
          }
         return cad;
     }
     
     /**
      * Guardar un vehículo
      * @param v
     * @throws VehiculoFileException 
     * @throws IOException 
      */
     public void guardar(Vehiculo v) throws VehiculoFileException, IOException{
	    	 if (vFile.existe(v)){
	    		 throw new VehiculoFileException("Ya existe");
	    	 }
	    	 vFile.guardar(v);
     }

     /**
      * Busca un vehículo a través de su matrícula
      * @param matricula
      * @return vehículo buscado si lo encuentra, null en otro caso
     * @throws VehiculoFileException 
     * @throws IOException 
     * @throws ClassNotFoundException 
      */
     public Vehiculo buscar(String matricula) throws VehiculoFileException, ClassNotFoundException, IOException {
    	 	Vehiculo v = new Vehiculo();
    	 	v.setMatricula(matricula);
    	 	
	    	 if (!vFile.existe(v)){
	    		 throw new VehiculoFileException("No existe");
	    	 }
	    	 
	    	 return vFile.leer(matricula);
     }
     
     /**
      * Listar los vehículos
      * @return
     * @throws IOException 
     * @throws ClassNotFoundException 
      */
     public Vehiculo[] buscar() throws ClassNotFoundException, IOException {
    	 	return vFile.listar();
     }
     
     /**
      * Reservar un vehículo
      * @param matricula
      * @return vehículo reservado si lo encuentra, null en otro caso
     * @throws VehiculoFileException 
     * @throws IOException 
     * @throws ClassNotFoundException 
      */
     public Vehiculo reservar(String matricula) throws VehiculoFileException, IOException, ClassNotFoundException{
    	 	Vehiculo veh = this.buscar(matricula);
    	 	veh.setReservado(true);
    	 	
    	 	vFile.guardar(veh);
    	 	
    	 	return veh;
     }
}

