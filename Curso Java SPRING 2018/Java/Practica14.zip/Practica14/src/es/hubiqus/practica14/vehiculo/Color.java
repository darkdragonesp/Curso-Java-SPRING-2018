package es.hubiqus.practica14.vehiculo;

/**
 * Colores permitidos
 * @author ajurado
 *
 */
public enum Color {
	ROJO, VERDE, AZUL
}
