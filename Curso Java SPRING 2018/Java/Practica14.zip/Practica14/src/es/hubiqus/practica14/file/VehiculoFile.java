package es.hubiqus.practica14.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

import es.hubiqus.practica14.vehiculo.Vehiculo;

/**
 * Operaciones de vehículos en sistema de ficheros
 * @author ajurado
 *
 */
public class VehiculoFile {
	public static final String EXT = ".txt";
	
	private File dir;
	
	/**
	 * Constructor, recibe un directorio
	 * @param file
	 */
	public VehiculoFile(File dir){
		this.dir = dir;
	}
	
	/**
	 * Comprobar si un vehículo existe en el directorio
	 * @param vehiculo
	 * @return
	 */
	public boolean existe(Vehiculo vehiculo){
		File file = new File(dir, vehiculo.getMatricula() + EXT);
		return file.exists();
	}

	/**
	 * Guardar un vehículo en fichero
	 * @param coche
	 * @throws IOException
	 */
	public void guardar(Vehiculo vehiculo) throws IOException {
		ObjectOutputStream salida = null;
        try {
        		File file = new File(dir, vehiculo.getMatricula() + EXT);
        	
        		//abrimos fichero para escritura
            salida = new ObjectOutputStream(new FileOutputStream(file));
            salida.writeObject(vehiculo);
        }finally{        		
        		if (salida != null){
        			salida.close();
        		}
        }
	}
	
	/**
	 * Leer un vehículo desde fichero
	 * @param matricula
	 * @return
	 * @throws IOException
	 * @throws ClassNotFoundException 
	 */
	public Vehiculo leer(String matricula) throws IOException, ClassNotFoundException {
		Vehiculo vehiculo = null;
		ObjectInputStream entrada = null;
        
        try {
        		File file = new File(dir, matricula + EXT);
        		//abrimos fichero para lectura
        		entrada = new ObjectInputStream(
        					new FileInputStream(file));
        		vehiculo = (Vehiculo) entrada.readObject();
        }finally{        		
        		if (entrada != null){
        			entrada.close();
        		}
        }
        return vehiculo;
	}
	
	/**
	 * Lista de vehículos
	 * @return
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public Vehiculo[] listar() throws ClassNotFoundException, IOException{
		//Obtener el listado de ficheros
		File[] files = dir.listFiles();
		Vehiculo[] vehiculos = new Vehiculo[files.length];
		int indice = 0;
		String matricula;
		for (File f: files){
			//Se trata de un coche
			if (f.getName().endsWith(EXT)){
				//Quitar extensión
				matricula = f.getName().substring(0, f.getName().indexOf(EXT));
				vehiculos[indice++] = this.leer(matricula);
			}
		}
		
		vehiculos = Arrays.copyOf(vehiculos, indice);
		return vehiculos;
	}

}
