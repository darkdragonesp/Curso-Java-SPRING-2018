package es.hubiqus.practica14.file;

public class VehiculoFileException extends Exception {

    /**
	 * UID
	 */
	private static final long serialVersionUID = -2077373186587931952L;


	/**
     * Constructor sin argumentos
     */
    public VehiculoFileException() {
    }


    /**
     * Constructor con mensaje
     * @param msg
     */
    public VehiculoFileException(String msg) {
        super(msg);
    }
}
