package es.hubiqus.practica14;

import es.hubiqus.practica14.vehiculo.Concesionario;


public class Test {

	public static void main(String[] args) {		
//		try {
//			File dir = new File("/Users/ajurado/Documents/workspaceJava201705/Practica14");
//			VehiculoFile cf = new VehiculoFile(dir);
//			
//			Vehiculo coche = new Coche("123ABC",Color.ROJO,false,10000,5,true);
//			cf.guardar(coche);
//			
//			coche = cf.leer(coche.getMatricula());
//			System.out.println(coche);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		Concesionario concesionario = new Concesionario("BIZNAUTO", "Avd. Ortega", 5551234);
		//Lanzar menú
		new Menu(concesionario).run();
	}
}
