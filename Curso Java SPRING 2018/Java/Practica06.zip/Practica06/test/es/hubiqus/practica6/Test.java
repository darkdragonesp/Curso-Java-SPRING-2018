/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.hubiqus.practica6;

/**
 *
 * @author Lenguaje Java Básico
 */
public class Test {
	
	public static void main(String[] args){
		//CREAR UN CONCESIONARIO
        System.out.println("Creamos un concesionario...");       
        Concesionario concesionario = new Concesionario("BIZNAUTO","Avd. Ortega", 5551234);
        System.out.println("Concesionario creado...");
        System.out.println(concesionario +"\n \n ");        
        
        //INTRODUCIR 3 COCHES
        Coche c1=new Coche("123ABC","negro",false,10000,3,true);
        Coche c2=new Coche("456JKL","rojo",false,15000,5,false);
        Coche c3=new Coche("789ASD","azul",false,12000,5,true);
        
        //INTRODUCIR 2 MOTOS
        Moto m1=new Moto("012QWE","negro",false,18000,500);
        Moto m2=new Moto("133RTY","gris",false,15000,250);
        
        concesionario.guardar(c1);
        concesionario.guardar(c2);
        concesionario.guardar(c3);
        concesionario.guardar(m1);
        concesionario.guardar(m2);
        
        //MOSTRAR COCHES INDICANDO SI ESTAN RESERVADOS O NO
        System.out.println("Mostrar coches indicando si están reservados o no...");
        System.out.println(concesionario);
        System.out.println("=========");
        
        //RESERVAR DOS VEHICULOS
        concesionario.buscar("123ABC").setReservado(true);
        concesionario.reservar("133RTY");
        System.out.println();
        System.out.println("\n \nVehiculos reservados...");
        System.out.println();
        
        //MOSTRAR TODOS LOS VEHICULOS
        System.out.println("Mostrar Concesionario...");
        System.out.println(concesionario);
		
        //BUSCAR VEHICULO A PARTIR DE UNA MATRICULA DADA        
        String matricula="789ASD";
        System.out.println("\n \nBuscando matrícula... " + matricula);
        System.out.println(concesionario.buscar(matricula));
	}


}
