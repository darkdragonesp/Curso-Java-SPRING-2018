package es.hubiqus.practica6;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Concesionario de vehículos
 * @author Lenguaje Java Básico
 */
public class Concesionario {

     private String nombre;
     private String direccion;
     private int telefono;
     private Vehiculo[] vehiculos;
     public final static int TAM = 5;

     /**
      * Constructor básico
      */
     public Concesionario() {
          vehiculos = new Vehiculo[TAM];
     }

     /**
      * Constructor completo
      * @param nom
      * @param dir
      * @param telf
      */
     public Concesionario(String nom, String dir, int telf) {
    	 	this();
        this.nombre = nom;
        this.direccion = dir;
        this.telefono = telf;          
     }

     public void setNombre(String nombre) {
          this.nombre = nombre;
     }

     public void setDireccion(String direccion) {
          this.direccion = direccion;
     }

     public void setTelefono(int telefono) {
          this.telefono = telefono;
     }

     public String getDireccion() {
          return direccion;
     }

     public String getNombre() {
          return nombre;
     }

     public int getTelefono() {
          return telefono;
     }

     @Override
     public String toString() {
          String cad;
          cad = "Concesionario: " + "\n" +
                  "Nombre: " + getNombre() + "\n" +
                  "Direccion: " + getDireccion() + "\n" +
                  "Telefono: " + getTelefono() + "\n";
          for (int i = 0; i < TAM; i++) {
               if (this.vehiculos[i] != null) {
                    cad = cad + "Vehiculo =>" + vehiculos[i] + "\n";
               }
          }
          return cad;
     }
     
     /**
      * Guardar un vehículo
      * @param v
      */
     public void guardar(Vehiculo v){
	    	 int indice = 0;
	    	 boolean enc = false;
	    	 while (indice < vehiculos.length && !enc){
	    		 enc = vehiculos[indice++] == null;
	    	 }
	    	 
	    	 //Si hay hueco
	    	 if (enc){
	    		 vehiculos[--indice] = v;
	    	 }
     }

     /**
      * Busca un vehículo a través de su matrícula
      * @param matricula
      * @return vehículo buscado si lo encuentra, null en otro caso
      */
     public Vehiculo buscar(String matricula) {
          boolean encontrado = false;
          Vehiculo veh = null;
          int cont = 0;
          while ((!encontrado) && (cont < TAM)) {
        	  if (vehiculos[cont] != null && 
           		   vehiculos[cont].getMatricula().equalsIgnoreCase(matricula)) {
                    encontrado = true;
                    veh = vehiculos[cont];
               }
               cont++;
          }
          return veh;
     }
     
     /**
      * Reservar un vehículo
      * @param matricula
      * @return vehículo reservado si lo encuentra, null en otro caso
      */
     public Vehiculo reservar(String matricula){
    	 	Vehiculo veh = this.buscar(matricula);
    	 	
    	 	if (veh != null){
    	 		veh.setReservado(true);
    	 	}
    	 	return veh;
     }
}

