package es.hubiqus.boot.service;

public class SvcException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2557074702986758093L;
	
	public SvcException() {
		super();
	}

	public SvcException(Exception ex){
		super(ex);
	}

}
