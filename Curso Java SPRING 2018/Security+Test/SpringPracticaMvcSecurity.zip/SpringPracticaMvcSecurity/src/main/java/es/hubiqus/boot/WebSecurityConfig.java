package es.hubiqus.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import es.hubiqus.boot.service.impl.UsuarioSvcImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private UsuarioSvcImpl userDetailsService;
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
	    DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
	    authProvider.setUserDetailsService(userDetailsService);
	    authProvider.setPasswordEncoder(passwordEncoder());
	    return authProvider;
	}
	
	@Override
    protected void configure(HttpSecurity http) throws Exception {
        http
        	.authenticationProvider(authenticationProvider())	//Autenticación personalizada
	        .authorizeRequests()
	        	.antMatchers("/", "/inicio/home", "/usuario/*").permitAll() //Rutas permitidas
	        	.antMatchers("/css/*", "/fotos/*", "/images/*", "/js/*").permitAll() //Permitir estáticos
	        	.antMatchers("/venta/*").hasRole("Admin") //Solamente accesible por el admin
	        	.anyRequest().authenticated()	//El resto no permitido sin autentificar
	            .and()
	        .formLogin() //Si no se especifica muestra formulario de inicio por defecto
	            .loginPage("/login") //Página de login personalizada, tiene que aparecer en viewControllers
	            .successForwardUrl("/inicio/home") //Página donde dirige el login correcto
	            .permitAll() //Acceso a todo el mundo
	            .and()
	        .logout() //Acción de salida
	        	.invalidateHttpSession(true) //Cerrar la sesión
	        	.permitAll(); //Acceso a todo el mundo
    }

//    @Bean
//    @Override
//    public UserDetailsService userDetailsService() {
//    	UserDetails user =
//                User.withDefaultPasswordEncoder() //deprecated, a sustituir por autenticación JPA
//                   .username("a")
//                   .password("a")
//                   .roles("Admin")
//                   .build();
//
//        return new InMemoryUserDetailsManager(user);
//    }
	
}
