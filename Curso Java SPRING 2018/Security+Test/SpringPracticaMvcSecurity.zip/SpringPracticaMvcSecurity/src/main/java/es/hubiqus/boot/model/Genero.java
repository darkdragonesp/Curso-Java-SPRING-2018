package es.hubiqus.boot.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Clase que representa el género musical de los discos
 * @author ajurado
 *
 */
@Entity
@Table(name="genero")
public class Genero {

	private Integer id;
	private String descripcion;
	
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
}
