package es.hubiqus.boot.controller.venta;

import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.boot.service.VentaSvc;

@Controller
@RequestMapping(value = "/venta")
public class Venta {
	
	private static final Log log = LogFactory.getLog(Venta.class);
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_MSG = "msg";

	private static final String MSG_ERROR = "error.general";
	
	private static final String SUCCESS = "ventas";
	private static final String ERROR = "ventas";
	
	@Autowired
	private VentaSvc svc;
	
	@Autowired  
    private MessageSource messageSource;

	@RequestMapping(value="/listar", method=RequestMethod.GET)
    public String execute(Model model, Locale locale){
    	try {
			//Listado
			model.addAttribute(ATT_LISTA, svc.listar());
			
			return SUCCESS;
		} catch (Exception ex) {
			log.error(ex);
			model.addAttribute(ATT_MSG,
					messageSource.getMessage(MSG_ERROR, null, locale));
			return ERROR;
		}
    }
	
}
