package es.hubiqus.boot.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.boot.model.Venta;

/**
 * Crud básico: no necesita operaciones adicionales
 * En caso de implementación marcar con @Repository
 * @author ajurado
 *
 */
public interface VentaDao extends CrudRepository<Venta, Integer> {
	
}
