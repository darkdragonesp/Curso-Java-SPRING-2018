package es.hubiqus.boot.service;

import es.hubiqus.boot.model.Venta;

/**
 * Funcionalidad de ventas
 * @author ajurado
 *
 */
public interface VentaSvc {
	
	/**
	 * Guardar un registro
	 * @param item elemento a guardar
	 * @throws SvcException error al guardar
	 */
	public void guardar(Venta item) throws SvcException;

	/**
	 * Listado completo
	 * @return lista de ventas
	 * @throws SvcException error al buscar
	 */
	public Iterable<Venta> listar() throws SvcException;
}
