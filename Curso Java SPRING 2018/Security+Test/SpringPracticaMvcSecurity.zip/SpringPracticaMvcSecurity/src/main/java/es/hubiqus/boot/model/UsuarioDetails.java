package es.hubiqus.boot.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Clase que implementa los detalles del usuario para cuestiones de seguridad
 * @author ajurado
 *
 */
public class UsuarioDetails extends User implements UserDetails{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -919194784965435291L;
	
	private Usuario usuario;
	private Carrito carrito;
	
	public UsuarioDetails(Usuario usuario, Carrito carrito) {
		super(usuario.getUser(), usuario.getClave(), getAuthorities(usuario));
		this.usuario = usuario;
		this.carrito = carrito;
	}
	
	/**
	 * Devolver el usuario autenticado
	 * @return
	 */
	public Usuario getUsuario() {
		return usuario;
	}
	
	/**
	 * Devolver el carrito del usuario actual
	 * @return
	 */
	public Carrito getCarrito() {
		return carrito;
	}
	
	public void reset() {
		carrito = new Carrito();
	}
	
	@Override
	public String getPassword() {
		return usuario.getClave();
	}

	@Override
	public String getUsername() {
		return usuario.getUser();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
	
	/**
	 * Obtener los roles del usuario
	 * @param usuario
	 * @return
	 */
	private static Collection<? extends GrantedAuthority> getAuthorities(Usuario usuario) {
		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
		//Incluir el prefijo ROLE_ para tener en cuenta en etiquetas sec:
		authorities.add(new SimpleGrantedAuthority("ROLE_" + usuario.getTipo().getDescripcion()));
		return authorities;
	}

}
