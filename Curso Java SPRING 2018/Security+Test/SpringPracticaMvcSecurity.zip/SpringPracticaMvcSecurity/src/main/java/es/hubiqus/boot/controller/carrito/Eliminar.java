package es.hubiqus.boot.controller.carrito;

import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import es.hubiqus.boot.model.Disco;
import es.hubiqus.boot.model.UsuarioDetails;
import es.hubiqus.boot.service.CarritoSvc;

/**
 * Controlador para agregar productos al carrito
 * @author Hubiqus
 *
 */
@Controller
@RequestMapping(value="/carrito")
public class Eliminar {
	
	private static final Log log = LogFactory.getLog(Eliminar.class);

	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "forward:/carrito/listar"; 
	private static final String ERROR = "forward:/carrito/listar";
	
	@Autowired
	private CarritoSvc svc;
	
	@RequestMapping(value="/borrar", method=RequestMethod.GET)	
    public String eliminar(@RequestParam int id, Authentication auth, Model model, Locale locale) {
		try{
			Disco disco = new Disco();
			disco.setId(id);
			
			//Agregar producto
			UsuarioDetails usuario = (UsuarioDetails) auth.getPrincipal();
			svc.eliminar(usuario.getCarrito(), disco);
			
			return SUCCESS;			
		}catch (Exception ex){	
			log.error(ex);
			model.addAttribute(ATT_ERROR, ex);
			return ERROR;
		}
	}

}
