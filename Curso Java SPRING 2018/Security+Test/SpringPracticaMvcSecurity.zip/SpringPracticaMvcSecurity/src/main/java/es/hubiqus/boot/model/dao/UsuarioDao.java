package es.hubiqus.boot.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.boot.model.Usuario;

/**
 * Crud básico: no necesita operaciones adicionales
 * En caso de implementación marcar con @Repository
 * @author ajurado
 *
 */
public interface UsuarioDao extends CrudRepository<Usuario, Integer> {

//	/**
//	 * Buscar por usuario/clave, autoimplementado
//	 * @param usuario
//	 * @param clave
//	 * @return usuario buscado, null si no es correcto
//	 */
//	public Usuario findByUserAndClave(String user, String clave);
	
	/**
	 * Buscar por nombre de usuario único
	 * @param user
	 * @return
	 */
	public Usuario findByUser(String user);
	
}
