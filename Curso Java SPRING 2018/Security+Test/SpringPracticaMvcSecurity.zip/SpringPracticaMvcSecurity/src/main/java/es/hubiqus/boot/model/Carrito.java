package es.hubiqus.boot.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Carrito que contendrá los productos seleccionados
 * @author ajurado
 *
 */
public class Carrito {

	private List<Disco> lista;
	
	public Carrito(){
		this.lista = new ArrayList<Disco>();
	}

	/**
	 * Obtener los productos que contiene el carrito
	 * @return lista de productos del carrito
	 */
	public List<Disco> getProductos() {
		return lista;
	}
	
}
