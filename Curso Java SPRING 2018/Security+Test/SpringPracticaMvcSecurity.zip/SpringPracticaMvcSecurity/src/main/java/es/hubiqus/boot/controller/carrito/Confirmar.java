package es.hubiqus.boot.controller.carrito;

import java.util.Locale;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.boot.model.UsuarioDetails;
import es.hubiqus.boot.service.CarritoSvc;

@Controller
@RequestMapping(value="/carrito")
public class Confirmar {
	
private static final Log log = LogFactory.getLog(Confirmar.class);
	
	private static final String ATT_MSG = "msg";
	private static final String ATT_RESULTADO = "resultado"; 
	
	private static final String SUCCESS = "resultado"; 
	private static final String ERROR = "forward:/carrito/listar";
		
	private static final String MSG_ERROR = "disco.comprar.error";
	
	@Autowired
	private CarritoSvc cSvc;
	
	@Autowired  
    private MessageSource messageSource;
	
	@RequestMapping(value="/confirmar", method=RequestMethod.GET)	
    public String view(Authentication auth, Model model, Locale locale) {
		try{
			UsuarioDetails usuario = (UsuarioDetails) auth.getPrincipal();
			model.addAttribute(ATT_RESULTADO, cSvc.total(usuario.getCarrito()));
			
			//Anotar la compra
			cSvc.comprar(usuario.getCarrito(), usuario.getUsuario());
			
			//Resetear el carrito
			usuario.reset();
			
			return SUCCESS;
		}catch (Exception ex){		
			log.error(ex);
			model.addAttribute(ATT_MSG,
					messageSource.getMessage(MSG_ERROR, null, locale));
			return ERROR;
		}
	}

}
