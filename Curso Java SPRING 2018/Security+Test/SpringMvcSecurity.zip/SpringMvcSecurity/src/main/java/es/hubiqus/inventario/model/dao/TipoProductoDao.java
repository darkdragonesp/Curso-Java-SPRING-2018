package es.hubiqus.inventario.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.inventario.model.TipoProducto;

public interface TipoProductoDao extends CrudRepository<TipoProducto, Integer>{

}
