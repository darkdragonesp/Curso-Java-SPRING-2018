package es.hubiqus.inventario.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.inventario.model.Producto;

public interface ProductoDao extends CrudRepository<Producto, Integer>{

}
