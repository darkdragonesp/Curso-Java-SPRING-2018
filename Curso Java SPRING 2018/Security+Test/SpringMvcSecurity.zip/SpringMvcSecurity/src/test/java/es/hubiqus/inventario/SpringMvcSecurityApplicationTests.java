package es.hubiqus.inventario;

import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;
import java.util.Optional;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.FormLoginRequestBuilder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.ProductoDao;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc//(secure=false) //Evitamos la seguridad
public class SpringMvcSecurityApplicationTests {

	@Autowired
    private MockMvc mockMvc;
	
	@MockBean
	private ProductoDao dao;
	
	@Before
	public void setUp() {
		Producto producto = new Producto();
		producto.setId(1);
		producto.setCantidad(1);
		producto.setComentario("Producto de Test");
		producto.setFecha(new Date());
		producto.setNombre("Zapato");
		producto.setPrecio(15.0);
		TipoProducto tipo = new TipoProducto();
		tipo.setId(1);
		producto.setTipo(tipo);
		
		//Mockito given: define un resultado fijo para un repositorio
		//Se puede leer, dado que llamo al método findById(1) obtendré el objeto item
		given(dao.findById(1)).willReturn(Optional.of(producto));
	}

	/**
	 * Rutas permitidas / y /inicio
	 */
	@Test
	public void index() throws Exception {
		mockMvc.perform(get("/"))
        	.andExpect(status().isOk());
	}

	@Test
	public void inicio() throws Exception {
		mockMvc.perform(get("/inicio"))
        	.andExpect(status().isOk());
	}
	
	/**
	 * Test ruta no permitida, error no autorizado
	 */
	@Test
    public void accesoSeguro() throws Exception {
        mockMvc.perform(get("/listar"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrlPattern("**/login"));
    }
	
	@Test
    public void accesoAutenticado() throws Exception {
		//Simulación de login
		FormLoginRequestBuilder login = formLogin()
	            .user("a")
	            .password("a");
		
		//Chequear que el usuario queda autenticado
		mockMvc.perform(login)
        .andExpect(authenticated().withUsername("a"));
    }
	
	/**
	 * Facilita un usuario ya autenticado
	 * @throws Exception
	 */
	@WithMockUser(value = "a")
	@Test
    public void accesoAutorizado() throws Exception {
		mockMvc.perform(get("/listar"))
    	.andExpect(status().isOk());
    }
	
	@WithMockUser(value = "a")
	@Test
    public void buscar() throws Exception {
		mockMvc.perform(get("/buscar?id=1"))
    	.andExpect(status().isOk())
    	.andExpect(view().name("form"))
		.andExpect(model().attributeExists("producto"));
    }

}
