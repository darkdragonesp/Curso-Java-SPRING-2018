package es.hubiqus.inventario;

import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.ProductoDao;
import es.hubiqus.inventario.service.ProductoSvc;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductoSvcTest {
	
	@MockBean
	private ProductoDao dao;
	
	@Autowired
	private ProductoSvc svc;

	private Producto producto;
	
	@Before
	public void setUp() {
		producto = new Producto();
		producto.setId(1);
		producto.setCantidad(1);
		producto.setComentario("Producto de Test");
		producto.setFecha(new Date());
		producto.setNombre("Zapato");
		producto.setPrecio(15.0);
		TipoProducto tipo = new TipoProducto();
		tipo.setId(1);
		producto.setTipo(tipo);
		
		//Mockito given: define un resultado fijo para un repositorio
		//Se puede leer, dado que llamo al método findById(1) obtendré el objeto item
		given(dao.findById(1)).willReturn(Optional.of(producto));
	}
	
	@Test
	public void getPartyTest() throws Exception {
		Producto saved = svc.buscar(1);
		
		assertTrue(saved.getNombre().equals(producto.getNombre()));
	}

}
