package es.hubiqus.carrito.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.carrito.model.TipoProducto;
import es.hubiqus.carrito.model.dao.TipoProductoDao;
import es.hubiqus.carrito.service.SvcException;
import es.hubiqus.carrito.service.TipoProductoSvc;

@Transactional
@Service
public class TipoProductoSvcImpl implements TipoProductoSvc{
	
	@Autowired
	private TipoProductoDao dao;
	
	@Override
	public Iterable<TipoProducto> listar() throws SvcException {
		Iterable<TipoProducto> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
