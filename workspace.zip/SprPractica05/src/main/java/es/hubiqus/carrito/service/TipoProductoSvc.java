package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.TipoProducto;

public interface TipoProductoSvc {
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<TipoProducto> listar() throws SvcException;

}
