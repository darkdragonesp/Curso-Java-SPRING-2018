package es.hubiqus.carrito.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.hubiqus.carrito.model.Usuario;
import es.hubiqus.carrito.model.dao.UsuarioDao;
import es.hubiqus.carrito.service.SvcException;
import es.hubiqus.carrito.service.UsuarioSvc;

@Service
public class UsuarioSvcImpl implements UsuarioSvc{
	
	@Autowired
	private UsuarioDao dao;	

	@Override
	public Usuario identificar(Usuario usuario) throws SvcException {
		Usuario res = null;
		
		try{
			res = dao.findByUsernameAndPassword(usuario.getUsername(), usuario.getPassword());
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
