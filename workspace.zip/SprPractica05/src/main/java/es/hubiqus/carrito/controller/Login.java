package es.hubiqus.carrito.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import es.hubiqus.carrito.interceptor.LoginInterceptor;
import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.model.Usuario;
import es.hubiqus.carrito.service.UsuarioSvc;

@Controller
@SessionAttributes({"carrito","sessionUser"})
@RequestMapping(value = "/login")
public class Login {
	
	private static final String MSG_ERROR = "usuario.login.error";
	
	private static final String ATT_CARRITO = "carrito";
	
	private static final String FORM = "form";	
	private static final String ERROR = "form";
	private static final String SUCCESS = "inicio";
	
	@Autowired
	private UsuarioSvc svc;
	
//	@Autowired
//	private HttpSession session;
	
	@RequestMapping(method=RequestMethod.GET)
    public String view(@ModelAttribute Usuario usuario, Model model) {
		return FORM;
	}
	
	@RequestMapping(method=RequestMethod.POST)
    public String execute(@Valid Usuario usuario, BindingResult result, Model model){
		try {
			if (result.hasErrors()){
				return FORM;
			}else{
				usuario = svc.identificar(usuario);
				if (usuario == null){
					result.reject(MSG_ERROR);
					return ERROR;
				}else{
					//Crear nuevo carrito para el cliente
//					session.setAttribute(ATT_CARRITO, new Carrito());					
					model.addAttribute(ATT_CARRITO, new Carrito());
					
					//Agregar el usuario a la sesión para el interceptor
//					session.setAttribute(LoginInterceptor.ATT_USER, usuario);
					model.addAttribute(LoginInterceptor.ATT_USER, usuario);
					return SUCCESS;
				}
			}
		} catch (Exception e) {
			result.reject(MSG_ERROR);
			return ERROR;
		}
    }
    

}
