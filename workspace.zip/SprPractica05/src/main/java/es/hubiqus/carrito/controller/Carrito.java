package es.hubiqus.carrito.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Carrito {

	private static final String SUCCESS = "carrito";
	
	@RequestMapping(value="/carrito", method=RequestMethod.GET)
    public String ver(Model model) {
		return SUCCESS;
	}

}
