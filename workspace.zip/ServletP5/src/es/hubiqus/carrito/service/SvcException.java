package es.hubiqus.carrito.service;

public class SvcException extends Exception{

	private static final long serialVersionUID = -57372163251370398L;

	public SvcException(Exception ex){
		super(ex);
	}

}
