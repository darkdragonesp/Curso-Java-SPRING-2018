package es.hubiqus.carrito.service.impl;

import java.util.List;

import es.hubiqus.carrito.model.Tipo;
import es.hubiqus.carrito.model.dao.DaoException;
import es.hubiqus.carrito.model.dao.TipoDao;
import es.hubiqus.carrito.service.SvcException;
import es.hubiqus.carrito.service.TipoSvc;

public class TipoSvcImpl implements TipoSvc {
	private TipoDao dao;
	
	public TipoDao getDao() {
		return dao;
	}
	public void setDao(TipoDao dao) {
		this.dao = dao;
	}
	@Override
	public Tipo buscar(Integer id) throws SvcException {
		
		Tipo res=null;
		
		try{
			res = dao.findById(id);
		}catch (DaoException ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Override
	public Iterable<Tipo> listar() throws SvcException {
		List<Tipo> res=null;
		
		try{
			res = dao.findAll();
		}catch (DaoException ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
