package es.hubiqus.carrito.service.impl;

import es.hubiqus.carrito.model.Carrito;
import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.service.CarritoSvc;
import es.hubiqus.carrito.service.SvcException;

public class CarritoSvcImpl implements CarritoSvc{

	@Override
	public void agregar(Carrito c, Producto p) throws SvcException {
		c.getProductos().add(p);		
	}

	@Override
	public double total(Carrito c) {
		double res = 0.0;
		
		for (Producto p: c.getProductos()){
			res += p.getPrecio();
		}
		
		return res;
	}

}
