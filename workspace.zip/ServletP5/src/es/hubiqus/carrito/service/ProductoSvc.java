package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.Producto;

public interface ProductoSvc {
	
	/**
	 * Buscar por id
	 * @param id criterio de búsqueda
	 * @return elemento buscado, null si no lo encuentra
	 * @throws SvcException error al buscar
	 */
	public Producto buscar(Integer id) throws SvcException;

	/**
	 * Buscar todos 
	 * @return lista de coincidencias
	 * @throws SvcException error al buscar
	 */
	public Iterable<Producto> listar() throws SvcException;
	public void anadir(Producto producto) throws SvcException;
	public void eliminar(Integer id) throws SvcException;
	public void modificar(Producto producto) throws SvcException;
}
