package es.hubiqus.carrito.service;

import es.hubiqus.carrito.model.Tipo;

public interface TipoSvc {
	public Tipo buscar(Integer id) throws SvcException;
	public Iterable<Tipo> listar() throws SvcException;
}
