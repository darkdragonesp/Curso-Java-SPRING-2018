package es.hubiqus.carrito.factory;

import es.hubiqus.carrito.model.dao.ProductoDao;
import es.hubiqus.carrito.model.dao.TipoDao;
import es.hubiqus.carrito.model.dao.impl.JdbcDataSource;
import es.hubiqus.carrito.model.dao.impl.ProductoDaoImplPs;
import es.hubiqus.carrito.model.dao.impl.TipoDaoImplPs;
import es.hubiqus.carrito.service.CarritoSvc;
import es.hubiqus.carrito.service.ProductoSvc;
import es.hubiqus.carrito.service.TipoSvc;
import es.hubiqus.carrito.service.impl.CarritoSvcImpl;
import es.hubiqus.carrito.service.impl.ProductoSvcImpl;
import es.hubiqus.carrito.service.impl.TipoSvcImpl;

/**
 * Generación de beans con patrón Singleton
 * @author ajurado
 *
 */
public class Factory {

	private static JdbcDataSource dataSource;
	private static ProductoDao productoDao;
	private static ProductoSvc productoSvc;
	private static CarritoSvc carritoSvc;
	private static TipoSvc tipoSvc;
	private static TipoDao tipoDao;
	/**
	 * Obtener dataSource
	 * @return
	 */
	public static JdbcDataSource getDataSource() {
		if (dataSource == null) {
			try {
				JdbcDataSource bean = new JdbcDataSource();
				//Asignar valores de conexión
				bean.setUrl("jdbc:mysql://localhost:3306/inventario");
				bean.setUsername("root");
				bean.setPassword("root");
				
				dataSource = bean;
			} catch (Exception ex) {
				dataSource = null;
			}
		}
		
		return dataSource;
	}
	
	/**
	 * Obtener ProductoDao
	 * @return
	 */
	public static ProductoDao getProductoDao(){
		if (productoDao == null){
			ProductoDaoImplPs bean = new ProductoDaoImplPs();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			productoDao = bean;
		}
		
		return productoDao;
	}
	
	/**
	 * Obtener ProductoSvc
	 * @return
	 */
	public static ProductoSvc getProductoSvc(){
		if (productoSvc == null){
			ProductoSvcImpl bean = new ProductoSvcImpl();
			//Inyección de dependencias
			bean.setDao(getProductoDao());
			
			productoSvc = bean;
		}
		
		return productoSvc;
	}
	public static TipoSvc getTipoSvc(){
		if (tipoSvc == null){
			TipoSvcImpl bean = new TipoSvcImpl();
			//Inyección de dependencias
			bean.setDao(getTipoDao());
			
			tipoSvc = bean;
		}
		
		return tipoSvc;
	}
	public static TipoDao getTipoDao(){
		if (tipoDao == null){
			TipoDaoImplPs bean = new TipoDaoImplPs();
			//Inyección de dependencias
			bean.setDataSource(getDataSource());
			
			tipoDao = bean;
		}
		
		return tipoDao;
	}
	/**
	 * Obtener CarritoSvc
	 * @return
	 */
	public static CarritoSvc getCarritoSvc(){
		if (carritoSvc == null){
			CarritoSvcImpl bean = new CarritoSvcImpl();
			
			carritoSvc = bean;
		}
		
		return carritoSvc;
	}

}
