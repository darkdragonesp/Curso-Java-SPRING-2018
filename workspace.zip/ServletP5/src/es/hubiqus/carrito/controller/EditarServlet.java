package es.hubiqus.carrito.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.service.ProductoSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/EditarServlet")
public class EditarServlet extends HttpServlet {
	
	private static final String SUCCESS = "/ListarServlet";
	private static final String ERROR = "/error.jsp";
	private static final long serialVersionUID = 1L;
	
	private ProductoSvc svc;
	
    public ProductoSvc getSvc() {
		return svc;
	}
	public void setSvc(ProductoSvc svc) {
		this.svc = svc;
	}
	
	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getProductoSvc());
	}
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditarServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			Producto item = new Producto();
			item.setId(Integer.parseInt(request.getParameter("id")));
			item.setNombre(request.getParameter("nombre"));
			item.setCantidad(Integer.parseInt(request.getParameter("cantidad")));
			item.setPrecio(Double.parseDouble(request.getParameter("precio")));
			item.setFecha(new Date());
			item.setComentario(" ");
			svc.modificar(item);
			request.setAttribute("msg", "Producto modificado con �xito.");
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){		
			ex.printStackTrace();
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
