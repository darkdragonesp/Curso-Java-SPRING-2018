package es.hubiqus.carrito.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.service.ProductoSvc;

/**
 * Servlet implementation class BorrarServlet
 */
@WebServlet("/BorrarServlet")
public class BorrarServlet extends HttpServlet {
	
	private static final String SUCCESS = "/ListarServlet";
	private static final String ERROR = "/error.jsp";
	private static final long serialVersionUID = 1L;
	
	private ProductoSvc svc;
	
    public ProductoSvc getSvc() {
		return svc;
	}
	public void setSvc(ProductoSvc svc) {
		this.svc = svc;
	}
	
	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getProductoSvc());
	}
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BorrarServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			Integer id=Integer.parseInt(request.getParameter("id"));
			svc.eliminar(id);
			request.setAttribute("msg", "Producto eliminado con �xito.");
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){		
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
