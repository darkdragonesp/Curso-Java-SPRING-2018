package es.hubiqus.carrito.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.service.ProductoSvc;
import es.hubiqus.carrito.service.TipoSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/GuardarServlet")
public class GuardarServlet extends HttpServlet {
	
	private static final String SUCCESS = "/ListarServlet";
	private static final String ERROR = "/error.jsp";
	private static final long serialVersionUID = 1L;
	
	private ProductoSvc svc;
	private TipoSvc svcTipo;
	
    public TipoSvc getSvcTipo() {
		return svcTipo;
	}
	public void setSvcTipo(TipoSvc svcTipo) {
		this.svcTipo = svcTipo;
	}
	public ProductoSvc getSvc() {
		return svc;
	}
	public void setSvc(ProductoSvc svc) {
		this.svc = svc;
	}
	
	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getProductoSvc());
		this.setSvcTipo(Factory.getTipoSvc());
	}
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GuardarServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			// A�adir un producto a la bbdd
			Producto item = new Producto();
			item.setNombre(request.getParameter("nombre"));
			item.setCantidad(Integer.parseInt(request.getParameter("cantidad")));
			item.setPrecio(Double.parseDouble(request.getParameter("precio")));
			item.setFecha(new Date());
			Integer idTipo = Integer.parseInt(request.getParameter("tipo"));
			item.setTipo(svcTipo.buscar(idTipo));
			
			String id =request.getParameter("id");
			if(id == "") {
				svc.anadir(item);
				request.setAttribute("msg", "Producto a�adido con �xito.");
			}else {
				item.setId(Integer.parseInt(id));
				svc.modificar(item);
				request.setAttribute("msg", "Producto modificado con �xito.");
			}
			
			
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){		
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
