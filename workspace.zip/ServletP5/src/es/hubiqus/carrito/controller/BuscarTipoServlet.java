package es.hubiqus.carrito.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.carrito.factory.Factory;
import es.hubiqus.carrito.model.Tipo;
import es.hubiqus.carrito.service.TipoSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/BuscarTipoServlet")
public class BuscarTipoServlet extends HttpServlet {
	
	private static final String SUCCESS = "/guardar.jsp";
	private static final String ERROR = "/error.jsp";
	private static final long serialVersionUID = 1L;
	
	private TipoSvc svc;
	
    public TipoSvc getSvc() {
		return svc;
	}
	public void setSvc(TipoSvc svc) {
		this.svc = svc;
	}
	
	@Override
	public void init() throws ServletException {
		this.setSvc(Factory.getTipoSvc());
	}
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BuscarTipoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			Iterable<Tipo> listaTipos=svc.listar();
			request.setAttribute("tipos",listaTipos);
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){		
			ex.printStackTrace();
			request.setAttribute("error", ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
