package es.hubiqus.carrito.model;

public class Tipo {
	private Integer idTipo;
	private String nombreTipo;
	
	public Integer getIdTipo() {
		return idTipo;
	}
	public void setIdTipo(Integer id) {
		this.idTipo = id;
	}
	public String getNombreTipo() {
		return nombreTipo;
	}
	public void setNombreTipo(String nombre) {
		this.nombreTipo = nombre;
	}
	
}
