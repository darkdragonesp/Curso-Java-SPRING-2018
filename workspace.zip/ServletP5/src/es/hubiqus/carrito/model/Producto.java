package es.hubiqus.carrito.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Producto {
	
	private static final String FORMAT_ES = "dd/MM/yyyy";

	private Integer id;
	private String nombre;
	private Integer cantidad;
	private Double precio;
	private String comentario;
	private Date fecha;
	private Tipo tipo;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}	
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Tipo getTipo() {
		return tipo;
	}
	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	public String toString(){
		return id + ": " 
				+ nombre + "-" 
				+ comentario 
				+ " (" + cantidad + " unidades - " + precio + " €) " 
				+ new SimpleDateFormat(FORMAT_ES).format(fecha);
	}
	
}
