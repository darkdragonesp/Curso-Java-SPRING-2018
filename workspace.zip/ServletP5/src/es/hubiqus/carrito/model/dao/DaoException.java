package es.hubiqus.carrito.model.dao;

public class DaoException extends Exception{

	private static final long serialVersionUID = 6803792221083176343L;

	public DaoException(Exception ex){
		super(ex);
	}

}
