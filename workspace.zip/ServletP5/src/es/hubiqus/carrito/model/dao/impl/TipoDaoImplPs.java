package es.hubiqus.carrito.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import es.hubiqus.carrito.model.Tipo;
import es.hubiqus.carrito.model.dao.DaoException;
import es.hubiqus.carrito.model.dao.TipoDao;

public class TipoDaoImplPs implements TipoDao {
	private JdbcDataSource dataSource;

	public JdbcDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(JdbcDataSource dataSource) {
		this.dataSource = dataSource;
	}
	@Override
	public List<Tipo> findAll() throws DaoException {
		List<Tipo> res = new LinkedList<Tipo>();

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			String sql = "SELECT * FROM tipo";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

		
			rs = statement.executeQuery();

			while (rs.next()) {
				res.add(mapear(rs));
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}
	@Override
	public Tipo findById(int id) throws DaoException {
		Tipo res = null;

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			String sql = "SELECT * FROM tipo " + "WHERE idTipo = ?";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setInt(1, id);
			rs = statement.executeQuery();

			if (rs.next()) {
				res = mapear(rs);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}
	/**
	 * Obtener un tipo desde el ResultSet
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Tipo mapear(ResultSet rs) throws SQLException {
		Tipo item = new Tipo();
		item.setIdTipo(rs.getInt("idTipo"));
		item.setNombreTipo(rs.getString("nombreTipo"));


		return item;
	}
}
