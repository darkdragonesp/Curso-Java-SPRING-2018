package es.hubiqus.carrito.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.hubiqus.carrito.model.Producto;
import es.hubiqus.carrito.model.Tipo;
import es.hubiqus.carrito.model.dao.DaoException;
import es.hubiqus.carrito.model.dao.ProductoDao;

public class ProductoDaoImplPs implements ProductoDao {

	private JdbcDataSource dataSource;

	public JdbcDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(JdbcDataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void save(Producto producto) throws DaoException {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			String sql = "INSERT INTO producto (nombre, cantidad, precio, comentario, fecha, idTipo) VALUES (?,?,?,?,?,?)";

			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setString(1, producto.getNombre());
			statement.setInt(2, producto.getCantidad());
			statement.setDouble(3, producto.getPrecio());
			statement.setString(4, producto.getComentario());
			statement.setDate(5,
					new java.sql.Date(producto.getFecha().getTime()));
			statement.setInt(6, producto.getTipo().getIdTipo());
			statement.executeUpdate();

		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
	}

	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException {
		List<Producto> res = new ArrayList<Producto>();

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			String sql = "SELECT p.id, p.nombre, cantidad, precio, comentario, fecha , t.idTipo, t.nombreTipo"
					+" FROM producto p "
					+" LEFT JOIN tipo t ON p.idTipo = t.idTipo"
					+" WHERE p.nombre LIKE ?"; 
				
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setString(1, "%" + nombre + "%");
			rs = statement.executeQuery();

			while (rs.next()) {
				res.add(mapear(rs));
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}

	@Override
	public Producto findById(int id) throws DaoException {
		Producto res = null;

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			String sql = "SELECT p.id, p.nombre, cantidad, precio, comentario, fecha , t.idTipo, t.nombreTipo"
					+" FROM producto p "
					+" LEFT JOIN tipo t ON p.idTipo = t.idTipo"
					+" WHERE p.id = ?";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setInt(1, id);
			rs = statement.executeQuery();

			if (rs.next()) {
				res = mapear(rs);
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}

	/**
	 * Obtener un producto desde el ResultSet
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Producto mapear(ResultSet rs) throws SQLException {
		Producto item = new Producto();
		item.setId(rs.getInt("id"));
		item.setNombre(rs.getString("nombre"));
		item.setCantidad(rs.getInt("cantidad"));
		item.setPrecio(rs.getDouble("precio"));
		item.setComentario(rs.getString("comentario"));
		item.setFecha(rs.getDate("fecha"));
		Integer idTipo=rs.getInt("idTipo");
		String nombreTipo=rs.getString("nombreTipo");
		Tipo tipo= new Tipo();
		tipo.setIdTipo(idTipo);
		tipo.setNombreTipo(nombreTipo);
		item.setTipo(tipo);
		return item;
	}

	@Override
	public void delete(Integer id) throws DaoException {
		// DELETE from tablename where id=2;
		Connection connection = null;
		PreparedStatement statement = null;

		try {
			String sql = "DELETE FROM producto "
					+ "WHERE id = ?";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setInt(1,id);
			statement.executeUpdate();

			
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
	}

	@Override
	public void edit(Producto producto) throws DaoException {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			String sql = "UPDATE producto"
					+ " SET nombre = ?"
					+", cantidad = ?"
					+", precio = ?"
					+", comentario = ?"
					+", fecha = ?"
					+", idTipo = ?"
					+ " WHERE id = ?";

			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setString(1, producto.getNombre());
			statement.setInt(2, producto.getCantidad());
			statement.setDouble(3, producto.getPrecio());
			statement.setString(4, producto.getComentario());
			statement.setDate(5,
					new java.sql.Date(producto.getFecha().getTime()));
			statement.setInt(6, producto.getTipo().getIdTipo());
			statement.setInt(7, producto.getId());
			statement.executeUpdate();
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

	}
}
