package es.hubiqus.carrito.model.dao;

import java.util.List;

import es.hubiqus.carrito.model.Tipo;

public interface TipoDao {
	Tipo findById(int id) throws DaoException;

	List<Tipo> findAll() throws DaoException;
}
