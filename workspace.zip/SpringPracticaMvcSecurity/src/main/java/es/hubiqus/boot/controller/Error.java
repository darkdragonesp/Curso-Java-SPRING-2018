package es.hubiqus.boot.controller;

import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Error implements ErrorController{
	
	public static final String ATT_MSG = "msg";
	
	private static final String MSG_NOT_FOUND = "error.noencontrado";
	private static final String MSG_FORBIDDEN = "error.prohibido";
	private static final String MSG_ERROR = "error.general";
	
	@Autowired  
    private MessageSource messageSource;

	@Override
	public String getErrorPath() {
		return "/error";
	}
	
	@RequestMapping("/error")
	public String error(Model model, HttpServletRequest request, Locale locale) {
	    Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
	     
	    if (status != null) {
	        Integer statusCode = Integer.valueOf(status.toString());
	     
	        if (statusCode == HttpStatus.NOT_FOUND.value()) {
	        	model.addAttribute(ATT_MSG,
						messageSource.getMessage(MSG_NOT_FOUND, null, locale));
	        } else if(statusCode == HttpStatus.FORBIDDEN.value()) {
	        	model.addAttribute(ATT_MSG,
						messageSource.getMessage(MSG_FORBIDDEN, null, locale));
	        } else if(statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
	        	model.addAttribute(ATT_MSG,
						messageSource.getMessage(MSG_ERROR, null, locale));
	        }
	    }
	    return "error";
	}

}
