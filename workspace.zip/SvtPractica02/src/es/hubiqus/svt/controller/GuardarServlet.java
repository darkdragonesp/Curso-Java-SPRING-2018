package es.hubiqus.svt.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.svt.model.Persona;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/GuardarServlet")
public class GuardarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Crear la instancia de la clase Persona
		Persona item = new Persona();
		item.setDni(request.getParameter("dni"));
		item.setNombre(request.getParameter("nombre"));
		item.setEdad(Integer.parseInt(request.getParameter("edad")));
		
		//Guardar en el request
		request.setAttribute("persona", item);
		request.getRequestDispatcher("/resultado.jsp").forward(request, response);
	}

}
