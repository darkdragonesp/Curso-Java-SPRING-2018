package es.arelance.carrito.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.hubiqus.inventario.model.Producto;

/**
 * Servlet implementation class ComprarSvl
 */
@WebServlet("/ComprarSvl")
public class ComprarSvl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ComprarSvl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int res = 0;
			List<Producto> lista = (List<Producto>) request.getSession().getAttribute("carrito");
			for (Producto producto : lista) {
				res += producto.getPrecio();
			}
			request.setAttribute("total", res);
			// Eliminar el atributo solamente
			request.getSession().removeAttribute("carrito");
			// Invalidar sesi�n completa
//			session.invalidate();
			request.getRequestDispatcher("fin.jsp").forward(request, response);
		} catch (Exception e) {
			request.setAttribute("error", e);
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
