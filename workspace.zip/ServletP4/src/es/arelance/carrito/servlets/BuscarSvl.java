package es.arelance.carrito.servlets;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.hubiqus.inventario.factory.Factory;
import es.hubiqus.inventario.model.Producto;

/**
 * Servlet implementation class BuscarSvl
 */
@WebServlet("/BuscarSvl")
public class BuscarSvl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BuscarSvl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		try {
			//Obtengo el producto a�adido
			Integer idProducto = Integer
					.parseInt(request.getParameter("idProducto"));
			Producto producto = Factory.getProductoDao()
					.findById(idProducto);
			
			// Obtiene la sesi�n actual, si no existe la crea
			HttpSession session = request.getSession();
			List<Producto> carrito;
			if(request.getSession().getAttribute("carrito")==null) {
				carrito=new LinkedList<Producto>();
			}else {
				carrito=(List<Producto>) request.getSession().getAttribute("carrito");
			}
			carrito.add(producto);
			
			session.setAttribute("carrito", carrito);
			request.getRequestDispatcher("ListarSvl").forward(request,
					response);
		} catch (Exception e) {
			request.setAttribute("error", e);
			request.getRequestDispatcher("error.jsp").forward(request,
					response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
