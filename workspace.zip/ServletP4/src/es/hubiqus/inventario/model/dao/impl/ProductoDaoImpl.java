package es.hubiqus.inventario.model.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

public class ProductoDaoImpl implements ProductoDao{
	
	private static final String FORMAT_EN = "yyyy-MM-dd";
	
	private JdbcDataSource dataSource;
	
	public JdbcDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(JdbcDataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void save(Producto producto) throws DaoException{
		Connection connection = null;
		Statement statement = null;
		try{
			String sql = "INSERT INTO producto (nombre, cantidad, precio, comentario, fecha) VALUES('"
				 + producto.getNombre() + "',"
				 + producto.getCantidad() + ","
				 + producto.getPrecio() + ",'"
				 + producto.getComentario() + "','"
				 + new SimpleDateFormat(FORMAT_EN).format(producto.getFecha()) + "')";
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			statement.executeUpdate(sql);
			
		}catch (Exception ex){
			throw new DaoException(ex);
		}finally{
			try {
				if (statement != null){				
					statement.close();				
				}
				if (connection != null){				
					connection.close();				
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
	}
	
	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException{
		List<Producto> res = new ArrayList<Producto>();
		
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		
		try{					
			String sql = "SELECT id, nombre, cantidad, precio, comentario, fecha FROM producto " +
						"WHERE nombre LIKE '%" + nombre + "%'";
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			rs = statement.executeQuery(sql);
		
			while (rs.next()){
				//Guardar en la lista
				res.add(mapear(rs));
			}
		}catch (Exception ex){
			throw new DaoException(ex);
		}finally{
			try {
				if (rs != null){				
					rs.close();				
				}
				if (statement != null){				
					statement.close();				
				}
				if (connection != null){				
					connection.close();				
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
		
		return res;
	}
	
	/**
	 * Obtener un producto desde el ResultSet
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Producto mapear(ResultSet rs) throws SQLException {
		Producto item = new Producto();
		item.setId(rs.getInt("id"));
		item.setNombre(rs.getString("nombre"));
		item.setCantidad(rs.getInt("cantidad"));
		item.setPrecio(rs.getDouble("precio"));
		item.setComentario(rs.getString("comentario"));
		item.setFecha(rs.getDate("fecha"));
		
		return item;
	}

	@Override
	public Producto findById(Integer idProducto) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}
}
