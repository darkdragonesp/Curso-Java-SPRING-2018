package es.hubiqus.inventario.model.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcDataSource {
	private String url;
    private String username;
    private String password;
    
    public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public JdbcDataSource() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");        
    }
    
    public Connection getConnection() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
    	return DriverManager.getConnection(url, username, password);
    }
    
}