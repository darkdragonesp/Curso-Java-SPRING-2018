package es.hubiqus.inventario.model.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

public class ProductoDaoImplPs implements ProductoDao {

	private JdbcDataSource dataSource;

	public JdbcDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(JdbcDataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void save(Producto producto) throws DaoException {
		Connection connection = null;
		PreparedStatement statement = null;
		try {
			String sql = "INSERT INTO producto (nombre, cantidad, precio, comentario, fecha) VALUES (?,?,?,?,?)";

			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);
			statement.setString(1, producto.getNombre());
			statement.setInt(2, producto.getCantidad());
			statement.setDouble(3, producto.getPrecio());
			statement.setString(4, producto.getComentario());
			statement.setDate(5,
					new java.sql.Date(producto.getFecha().getTime()));
			statement.executeUpdate();

		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}
	}

	@Override
	public List<Producto> findByNombre(String nombre)
			throws DaoException {
		List<Producto> res = new ArrayList<Producto>();

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		try {
			String sql = "SELECT id, nombre, cantidad, precio, comentario, fecha FROM producto "
					+ "WHERE nombre LIKE ?";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setString(1, "%" + nombre + "%");
			rs = statement.executeQuery();

			while (rs.next()) {
				res.add(mapear(rs));
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}

	/**
	 * Obtener un producto desde el ResultSet
	 * 
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Producto mapear(ResultSet rs) throws SQLException {
		Producto item = new Producto();
		item.setId(rs.getInt("id"));
		item.setNombre(rs.getString("nombre"));
		item.setCantidad(rs.getInt("cantidad"));
		item.setPrecio(rs.getDouble("precio"));
		item.setComentario(rs.getString("comentario"));
		item.setFecha(rs.getDate("fecha"));

		return item;
	}

	@Override
	public Producto findById(Integer idProducto) throws DaoException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		Producto res=null;
		
		try {
			String sql = "SELECT id, nombre, cantidad, precio, comentario, fecha FROM producto "
					+ "WHERE id = ?";
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(sql);

			statement.setInt(1, idProducto);
			rs = statement.executeQuery();

			while (rs.next()) {
				res=mapear(rs);
			}
		} catch (Exception ex) {
			throw new DaoException(ex);
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException ex) {
				throw new DaoException(ex);
			}
		}

		return res;
	}
}
