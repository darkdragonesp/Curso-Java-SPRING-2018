package es.hubiqus.spr.controller.empleado;

import java.io.IOException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.hubiqus.spr.model.Departamento;
import es.hubiqus.spr.model.Empleado;
import es.hubiqus.spr.service.DepartamentoSvc;
import es.hubiqus.spr.service.EmpleadoSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/guardar")
public class GuardarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String MSG_EXITO = "Empleado almacenado";
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_EXITO = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "form.jsp";
	private static final String ERROR = "error.jsp";
	
	private EmpleadoSvc svc;
	private DepartamentoSvc dSvc;
	
    public EmpleadoSvc getSvc() {
		return svc;
	}
	public void setSvc(EmpleadoSvc svc) {
		this.svc = svc;
	}
	public DepartamentoSvc getdSvc() {
		return dSvc;
	}
	public void setdSvc(DepartamentoSvc dSvc) {
		this.dSvc = dSvc;
	}
	
	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
        
        //Spring no permite la IoD en Servlets, se obtiene desde el contexto
        this.setSvc(context.getBean(EmpleadoSvc.class));
        this.setdSvc(context.getBean(DepartamentoSvc.class));
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		try {
			request.setAttribute(ATT_LISTA, dSvc.listar());
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		} catch (Exception ex) {
			request.setAttribute(ATT_ERROR, ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			Empleado item = new Empleado();
			item.setNumero(Integer.parseInt(request.getParameter("numero")));
			item.setNombre(request.getParameter("nombre"));
			item.setSalario(Integer.parseInt(request.getParameter("salario")));
			item.setComision(Integer.parseInt(request.getParameter("comision")));
			item.setPuesto(request.getParameter("puesto"));
			item.setFechaAlta(new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("fecha")));
			Empleado jefe = new Empleado();
			jefe.setNumero(Integer.parseInt(request.getParameter("jefe")));
			item.setJefe(jefe);
			Departamento dpto = new Departamento();
			dpto.setNumero(Integer.parseInt(request.getParameter("dnumero")));
			item.setDepartamento(dpto);
				
			if (request.getParameter("editar") == null || request.getParameter("editar").isEmpty()){
				svc.guardar(item);
			}else{
				svc.modificar(item);
			}
			
			request.setAttribute(ATT_EXITO, MSG_EXITO);
			
			//Incluir la lista de departamentos
			request.setAttribute(ATT_LISTA, dSvc.listar());
			
			//Success
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){
			request.setAttribute(ATT_ERROR, ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
