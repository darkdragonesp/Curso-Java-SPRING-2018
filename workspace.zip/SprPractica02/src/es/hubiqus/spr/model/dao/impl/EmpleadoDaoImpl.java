package es.hubiqus.spr.model.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import es.hubiqus.spr.model.Empleado;
import es.hubiqus.spr.model.dao.DaoException;
import es.hubiqus.spr.model.dao.EmpleadoDao;

public class EmpleadoDaoImpl implements EmpleadoDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void save(Empleado empleado) throws DaoException {
		try{
			sessionFactory.getCurrentSession().save(empleado);	
		}catch (Exception ex){
			throw new DaoException(ex);
		}		
	}

	@Override
	public void update(Empleado empleado) throws DaoException {
		try{
			sessionFactory.getCurrentSession().update(empleado);		
		}catch (Exception ex){
			throw new DaoException(ex);
		}		
	}
	
	@Override
	public void delete(Empleado empleado) throws DaoException {
		try{
			sessionFactory.getCurrentSession().delete(empleado);		
		}catch (Exception ex){
			throw new DaoException(ex);
		}	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Empleado> findAll() throws DaoException {
		List<Empleado> res = null;

		try{					
			String hql = "FROM Empleado";
			res = sessionFactory.getCurrentSession().createQuery(hql).list();
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}

	@Override
	public Empleado findById(int id) throws DaoException {
		Empleado res = null;
		
		try{					
			res = (Empleado) sessionFactory.getCurrentSession().get(Empleado.class, id);
		}catch (Exception ex){
			throw new DaoException(ex);
		}
		
		return res;
	}
	
	

}
