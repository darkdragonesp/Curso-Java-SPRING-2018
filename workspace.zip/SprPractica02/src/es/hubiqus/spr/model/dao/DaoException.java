package es.hubiqus.spr.model.dao;

public class DaoException extends Exception{

	private static final long serialVersionUID = 2597764383573255467L;

	public DaoException(Exception ex){
		super(ex);
	}

}
