package es.hubiqus.spr.model.dao;

import es.hubiqus.spr.model.Empleado;

public interface EmpleadoDao {

	/**
	 * Guardar un registro
	 * @param empleado elemento a guardar
	 * @throws DaoException error de bdd
	 */
	public void save(Empleado empleado) throws DaoException;
	
	/**
	 * Actualizar un registro
	 * @param empleado elemento a actualizar
	 * @throws DaoException error de bdd
	 */
	public void update(Empleado empleado) throws DaoException;
	
	/**
	 * Eliminar un registro
	 * @param empleado elemento a eliminar
	 * @throws DaoException error de bdd
	 */
	public void delete(Empleado empleado) throws DaoException;
	
	/**
	 * Listado completo
	 * @return lista de empleados
	 * @throws DaoException error al buscar
	 */
	public Iterable<Empleado> findAll() throws DaoException;
	
	/**
	 * Filtrar por id
	 * @param id clave a buscar
	 * @return empleado encontrado, null si no lo encuentra
	 * @throws DaoException error de bdd
	 */
	public Empleado findById(int id) throws DaoException;
	
}
