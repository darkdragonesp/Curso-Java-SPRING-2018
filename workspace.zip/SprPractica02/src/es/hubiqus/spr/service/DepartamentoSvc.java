package es.hubiqus.spr.service;

import es.hubiqus.spr.model.Departamento;

public interface DepartamentoSvc {
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<Departamento> listar() throws SvcException;

	/**
	 * Filtrar por id
	 * @param id clave a buscar
	 * @return departamento encontrado, null si no lo encuentra
	 * @throws SvcException
	 */
	public Departamento buscar(int id) throws SvcException;
}
