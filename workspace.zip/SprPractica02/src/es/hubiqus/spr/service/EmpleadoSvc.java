package es.hubiqus.spr.service;

import es.hubiqus.spr.model.Empleado;

public interface EmpleadoSvc {

	/**
	 * Guardar un elemento
	 * @param empleado elemento a guardar
	 * @throws SvcException
	 */
	public void guardar(Empleado empleado) throws SvcException;
	
	/**
	 * Actualizar un elemento
	 * @param empleado elemento a actualizar
	 * @throws SvcException
	 */
	public void modificar(Empleado empleado) throws SvcException;
	
	/**
	 * Eliminar un elemento
	 * @param empleado elemento a eliminar
	 * @throws SvcException
	 */
	public void eliminar(Empleado empleado) throws SvcException;
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<Empleado> listar() throws SvcException;
	
	/**
	 * Filtrar por id
	 * @param id clave a buscar
	 * @return empleado encontrado, null si no lo encuentra
	 * @throws SvcException
	 */
	public Empleado buscar(int id) throws SvcException;
}
