package es.hubiqus.spr.service.impl;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.spr.model.Empleado;
import es.hubiqus.spr.model.dao.EmpleadoDao;
import es.hubiqus.spr.service.EmpleadoSvc;
import es.hubiqus.spr.service.SvcException;

@Transactional
public class EmpleadoSvcImpl implements EmpleadoSvc{
	
	private EmpleadoDao dao;
	
	public EmpleadoDao getDao() {
		return dao;
	}

	public void setDao(EmpleadoDao dao) {
		this.dao = dao;
	}

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void guardar(Empleado empleado) throws SvcException {
		try{
			dao.save(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void modificar(Empleado empleado) throws SvcException {
		try{
			dao.update(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void eliminar(Empleado empleado) throws SvcException {
		try{
			empleado = buscar(empleado.getNumero());
			dao.delete(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Override
	public Iterable<Empleado> listar() throws SvcException {
		Iterable<Empleado> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}
	
	@Override
	public Empleado buscar(int id) throws SvcException {
		Empleado res = null;
		
		try{
			res = dao.findById(id);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
