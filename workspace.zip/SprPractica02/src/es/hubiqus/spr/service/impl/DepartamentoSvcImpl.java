package es.hubiqus.spr.service.impl;

import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.spr.model.Departamento;
import es.hubiqus.spr.model.dao.DepartamentoDao;
import es.hubiqus.spr.service.DepartamentoSvc;
import es.hubiqus.spr.service.SvcException;

@Transactional
public class DepartamentoSvcImpl implements DepartamentoSvc{
	
	private DepartamentoDao dao;
	
	public DepartamentoDao getDao() {
		return dao;
	}

	public void setDao(DepartamentoDao dao) {
		this.dao = dao;
	}

	@Override
	public Iterable<Departamento> listar() throws SvcException {
		Iterable<Departamento> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Override
	public Departamento buscar(int id) throws SvcException {
		Departamento res = null;
		
		try{
			res = dao.findById(id);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}
	
}
