package es.hubiqus.inventario.model.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.dao.DaoException;
import es.hubiqus.inventario.model.dao.ProductoDao;

/**
 * Dao Hibernate clásico, necesario inyectar sessionFactory y gestionar la apertura y cierre de sesiones y transacciones
 * Acceso a operaciones Hibernate
 *
 */
public class ProductoDaoImplHibRaw implements ProductoDao{
	
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void save(Producto producto) throws DaoException{
		Session session = null;
		Transaction tx = null;
		
		try{
			session = this.getSessionFactory().openSession();
	        tx = session.beginTransaction();
	        session.save(producto);
	        tx.commit();
		}catch (Exception ex){
			if (tx != null){
				tx.rollback();
			}
			throw new DaoException(ex);
		}finally{
			if (session != null){
				session.close();
			}
		}
	}
	
	@Override
	public List<Producto> findByNombre(String nombre) throws DaoException{
		List<Producto> res = null;
		Session session = null;
		Transaction tx = null;
		
		try{
			session = this.getSessionFactory().openSession();
	        tx = session.beginTransaction();
			String hql = "FROM Producto p WHERE p.nombre LIKE '%" + nombre + "%'";
			res = session.createQuery(hql).list();		
			tx.commit();
		}catch (Exception ex){
			if (tx != null){
				tx.rollback();
			}
			throw new DaoException(ex);
		}finally{
			if (session != null){
				session.close();
			}
		}
		
		return res;
	}
}
