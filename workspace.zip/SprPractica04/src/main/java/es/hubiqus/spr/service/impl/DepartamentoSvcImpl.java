package es.hubiqus.spr.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.spr.model.Departamento;
import es.hubiqus.spr.model.dao.DepartamentoDao;
import es.hubiqus.spr.service.DepartamentoSvc;
import es.hubiqus.spr.service.SvcException;

@Transactional
@Service
public class DepartamentoSvcImpl implements DepartamentoSvc{
	
	@Autowired
	private DepartamentoDao dao;

	@Override
	public Iterable<Departamento> listar() throws SvcException {
		Iterable<Departamento> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Override
	public Departamento buscar(int id) throws SvcException {
		Departamento res = null;
		
		try{
			Optional<Departamento> item = dao.findById(id); 
			res = item.isPresent() ? item.get() : null;
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}
	
}
