package es.hubiqus.spr.controller.empleado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.spr.service.DepartamentoSvc;
import es.hubiqus.spr.service.EmpleadoSvc;

@Controller
public class BuscarController {
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_ERROR = "error";
	
	private static final String LISTA = "resultado";
	private static final String ERROR = "error";
	
	@Autowired
	private EmpleadoSvc svc;
	
	@Autowired
	private DepartamentoSvc dSvc;
	
	@RequestMapping(value="{id}/equipo", method=RequestMethod.GET)
    public String equipo(@PathVariable int id, Model model){
    	try {
			model.addAttribute(ATT_LISTA, svc.buscar(id).getEmpleados());
			
			return LISTA;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }
	
	@RequestMapping(value="{id}/empleados", method=RequestMethod.GET)
    public String empleados(@PathVariable int id, Model model){
    	try {
			model.addAttribute(ATT_LISTA, dSvc.buscar(id).getEmpleados());
			
			return LISTA;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
    }

}
