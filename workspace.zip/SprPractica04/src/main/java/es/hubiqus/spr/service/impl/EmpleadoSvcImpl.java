package es.hubiqus.spr.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.spr.model.Empleado;
import es.hubiqus.spr.model.dao.EmpleadoDao;
import es.hubiqus.spr.service.EmpleadoSvc;
import es.hubiqus.spr.service.SvcException;

@Transactional
@Service
public class EmpleadoSvcImpl implements EmpleadoSvc{
	
	@Autowired
	private EmpleadoDao dao;

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void guardar(Empleado empleado) throws SvcException {
		try{
			dao.save(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void modificar(Empleado empleado) throws SvcException {
		try{
			dao.save(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void eliminar(Empleado empleado) throws SvcException {
		try{
			dao.delete(empleado);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Override
	public Iterable<Empleado> listar() throws SvcException {
		Iterable<Empleado> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}
	
	@Override
	public Empleado buscar(int id) throws SvcException {
		Empleado res = null;
		
		try{
			Optional<Empleado> item = dao.findById(id); 
			res = item.isPresent() ? item.get() : null;
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
