package es.hubiqus.spr.model.dao;

import org.springframework.data.repository.CrudRepository;

import es.hubiqus.spr.model.Empleado;

public interface EmpleadoDao extends CrudRepository<Empleado, Integer>{
	
}
