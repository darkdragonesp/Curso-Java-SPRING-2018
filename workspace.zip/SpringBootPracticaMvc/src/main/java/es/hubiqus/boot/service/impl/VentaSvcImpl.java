package es.hubiqus.boot.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.boot.model.Venta;
import es.hubiqus.boot.model.dao.VentaDao;
import es.hubiqus.boot.service.SvcException;
import es.hubiqus.boot.service.VentaSvc;

/**
 * Implementación del servicio de ventas
 * @author ajurado
 *
 */
@Service
@Transactional
public class VentaSvcImpl implements VentaSvc{
	
	@Autowired
	private VentaDao dao;	

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	@Override
	public void guardar(Venta item) throws SvcException {
		try{
			dao.save(item);
		}catch (Exception ex){
			throw new SvcException(ex);
		}		
	}

	@Override
	public Iterable<Venta> listar() throws SvcException {
		Iterable<Venta> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
