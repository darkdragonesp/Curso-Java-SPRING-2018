package es.hubiqus.boot.controller.carrito;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value="/carrito")
public class Carrito {

	private static final String SUCCESS = "carrito";
	
	@RequestMapping(value="/listar", method=RequestMethod.GET)
    public String ver(Model model) {
		return SUCCESS;
	}

}
