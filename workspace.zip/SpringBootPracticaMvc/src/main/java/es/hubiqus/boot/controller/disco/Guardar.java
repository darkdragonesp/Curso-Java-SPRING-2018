package es.hubiqus.boot.controller.disco;

import java.util.Locale;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.boot.model.Disco;
import es.hubiqus.boot.service.DiscoSvc;
import es.hubiqus.boot.service.GeneroSvc;

@Controller
@RequestMapping(value = "/disco")
public class Guardar {
	
	private static final Log log = LogFactory.getLog(Guardar.class);
	
	private static final String ATT_ITEM = "disco";
	private static final String ATT_LISTA = "lista";
	private static final String ATT_MSG = "msg";
	
	private static final String MSG_EXITO = "disco.guardar.exito";
	private static final String MSG_ERROR = "error.general";
	
	private static final String FORM = "disco";
	private static final String ERROR = "disco";
	
	@Autowired
	private DiscoSvc svc;
	
	@Autowired
	private GeneroSvc gSvc;
	
	@Autowired  
    private MessageSource messageSource;
	
	@RequestMapping(value="/guardar", method=RequestMethod.GET)
    public String view(@ModelAttribute Disco disco, Model model, Locale locale) {
		try {
			//Incluir elementos para la selección
			model.addAttribute(ATT_LISTA, gSvc.listar());
			
			//Agregar como atributo el elemento recibido por parámetro
			model.addAttribute(ATT_ITEM, disco);
			
			return FORM;
		} catch (Exception ex) {
			log.error(ex);
			model.addAttribute(ATT_MSG,
					messageSource.getMessage(MSG_ERROR, null, locale));
			return ERROR;
		}
	}
	
	@RequestMapping(value = "/guardar", method=RequestMethod.POST)
    public String execute(@Valid Disco disco, BindingResult result, Model model, Locale locale) {
		try {
			//Comprobar si hay errores de entrada
			if (result.hasErrors()){
				//Mostrar sobre el propio formulario relleno
				return view(disco, model, locale);
			}else{
				//Guardar
				if (disco.getId() == null){
					svc.guardar(disco);
				}else{
					svc.modificar(disco);
				}
				
				//Mensaje de éxito
				model.addAttribute(ATT_MSG, messageSource.getMessage(MSG_EXITO, null, locale));
				
				
				return view(new Disco(), model, locale);
			}
		} catch (Exception ex) {
			log.error(ex);
			result.rejectValue("id", MSG_ERROR);
			return ERROR;
		}
    }

}
