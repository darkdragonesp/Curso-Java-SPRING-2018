package es.hubiqus.boot.service.impl;

import java.util.Date;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.boot.model.Carrito;
import es.hubiqus.boot.model.Disco;
import es.hubiqus.boot.model.Usuario;
import es.hubiqus.boot.model.Venta;
import es.hubiqus.boot.model.dao.DiscoDao;
import es.hubiqus.boot.model.dao.VentaDao;
import es.hubiqus.boot.service.CarritoSvc;
import es.hubiqus.boot.service.SvcException;

/**
 * Implementación del servicio de carrito
 * @author ajurado
 *
 */
@Service
@Transactional
public class CarritoSvcImpl implements CarritoSvc{
	
	@Autowired
	private VentaDao vDao;
	
	@Autowired
	private DiscoDao dDao;
	
	@Autowired
    private EntityManager em;

	@Override
	public void agregar(Carrito carrito, Disco disco) throws SvcException {
		int index;
		if ((index = buscar(carrito, disco)) > -1){
			Disco old = carrito.getProductos().get(index);
			old.setUnidades(old.getUnidades() + 1);
		}else{
			//Desconectar de la sesión, necesario
			em.detach(disco);
			//No lo ha encontrado, se agrega una unidad
			disco.setUnidades(1);
			carrito.getProductos().add(disco);
		}		
	}
	
	@Override
	public void eliminar(Carrito carrito, Disco disco) throws SvcException {
		int index;
		if ((index = buscar(carrito, disco)) > -1){
			carrito.getProductos().remove(index);
		}
	}
	
	/**
	 * Buscar el disco en el carrito
	 * @param c carrito
	 * @param p disco a buscar
	 * @return Índice disco encontrado, -1 en otro caso
	 */
	private int buscar(Carrito carrito, Disco disco){
		int res = -1;
		int i = 0;
		while (res < 0 && i < carrito.getProductos().size()){
			if (carrito.getProductos().get(i).getId().equals(disco.getId())){
				res = i;
			}
			i++;
		}
		return res;
	}

	@Override
	public double total(Carrito carrito) {
		double res = 0.0;
		
		for (Disco p: carrito.getProductos()){
			res += p.getPrecio();
		}
		
		return res;
	}
	
	@Override
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	public void comprar(Carrito carrito, Usuario usuario) throws SvcException{		
		try{
			//Almacenar la venta
			Venta v = new Venta();
			v.setFecha(new Date());
			v.setTotal(this.total(carrito));
			v.setUsuario(usuario);
			vDao.save(v);
			
			//Restar las unidades de discos
			Disco old;
			for (Disco d: carrito.getProductos()){
				old = dDao.findById(d.getId()).get();
				if (old.getUnidades() < d.getUnidades()){
					//Si no hay suficiente se detiene el proceso
					throw new SvcException();
				}else{
					old.setUnidades(old.getUnidades() - d.getUnidades());
					dDao.save(old);
				}
			}
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}

}
