package es.hubiqus.boot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.boot.model.Usuario;
import es.hubiqus.boot.model.dao.UsuarioDao;
import es.hubiqus.boot.service.SvcException;
import es.hubiqus.boot.service.UsuarioSvc;

/**
 * Implementación del servicio de usuarios
 * @author ajurado
 *
 */
@Service
@Transactional
public class UsuarioSvcImpl implements UsuarioSvc{
	
	private static final String URI_INICIO = "inicio";
	private static final String URI_USUARIO = "usuario";
	private static final String URI_CARRITO = "carrito";
	private static final String URI_DISCOS = "disco/listar";
	
	@Autowired
	private UsuarioDao dao;	
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	@Override
	public void guardar(Usuario item) throws SvcException {
		try{
			dao.save(item);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}

	@Override
	public Usuario identificar(Usuario usuario) throws SvcException {
		Usuario res = null;
		
		try{
			List<Usuario> lista = dao.findByUserAndClave(usuario.getUser(), usuario.getClave());
			if (!lista.isEmpty()) {
				res = lista.get(0);
			}
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Override
	public boolean comprobar(Usuario usuario, String uri) throws SvcException {
		switch (usuario.getTipo().getId()){
		case 1:
			return true;
		case 2:
			return (uri.contains(URI_INICIO) || 
					uri.contains(URI_USUARIO) || 
					uri.contains(URI_DISCOS) ||
					uri.contains(URI_CARRITO));
		default:
			return false;
		}
	}

}
