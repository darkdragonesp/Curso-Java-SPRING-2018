package es.hubiqus.boot.service;

import es.hubiqus.boot.model.Genero;

/**
 * Funcionalidad de géneros
 * @author ajurado
 *
 */
public interface GeneroSvc {
	
	/**
	 * Listar todos los elementos
	 * @return lista completa de elementos
	 * @throws SvcException
	 */
	public Iterable<Genero> listar() throws SvcException;

}
