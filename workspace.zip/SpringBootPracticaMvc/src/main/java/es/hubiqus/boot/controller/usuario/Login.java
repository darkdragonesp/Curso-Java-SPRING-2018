package es.hubiqus.boot.controller.usuario;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

import es.hubiqus.boot.interceptor.LoginInterceptor;
import es.hubiqus.boot.model.Carrito;
import es.hubiqus.boot.model.TipoUsuario;
import es.hubiqus.boot.model.Usuario;
import es.hubiqus.boot.service.ImagenSvc;
import es.hubiqus.boot.service.SvcException;
import es.hubiqus.boot.service.UsuarioSvc;

@Controller
@SessionAttributes({"carrito", "sessionUser"})
@RequestMapping(value = "/usuario")
public class Login {
	
	private static final Log log = LogFactory.getLog(Login.class);
	
	private static final String IMAGE_PATH = "/fotos/";
	
	private static final String ATT_CARRITO = "carrito";
	
	private static final String MSG_ERROR = "usuario.login.error";
	private static final String MSG_ERROR_USER = "usuario.registro.error";
	private static final String MSG_ERROR_GRAL = "error.general";
	
	private static final String FORM = "form";	
	private static final String LOGIN = "login";	
	private static final String SUCCESS = "inicio";
	private static final String INICIO = "redirect:/usuario/login";
	
	@Autowired
	private UsuarioSvc svc;
	
	@Autowired
	private ImagenSvc iSvc;
	
	@Autowired
	private ServletContext context;
	
	@RequestMapping(value = "/login", method=RequestMethod.GET)
    public String login(@ModelAttribute Usuario usuario, Model model) {
		return LOGIN;
	}
	
	@RequestMapping(value = "/logout", method=RequestMethod.GET)
	public String logout(Model model, SessionStatus sessionStatus){
		//Destrucción de la sesión
		sessionStatus.setComplete();
		//Hace un redirect, para completar el cierre de sesión
		return INICIO;
	}
	
	@RequestMapping(value = "/login", method=RequestMethod.POST)
    public String login(@Valid Usuario usuario, BindingResult result, Model model){
		try {
			//No tiene en cuenta validación del resto de campos (registro)
			if (result.getFieldError("usuario") != null || 
					result.getFieldError("clave") != null){
				return LOGIN;
			}else{
				usuario = svc.identificar(usuario);
				if (usuario == null){
					//Asignamos el error al id para filtrado en formulario 
					result.rejectValue("id", MSG_ERROR);
					return LOGIN;
				}else{
					inicializar(usuario, model);
					return SUCCESS;
				}
			}
		} catch (Exception ex) {
			log.error(ex);
			//Asignamos el error al id para filtrado en formulario
			result.rejectValue("id", MSG_ERROR);
			return LOGIN;
		}
    }
	
	/**
	 * Inicializar la sesión
	 * @param usuario
	 * @param model
	 */
	private void inicializar(Usuario usuario, Model model){
		//Crear nuevo carrito para el cliente
		model.addAttribute(ATT_CARRITO, new Carrito());
		
		//Agregar el usuario a la sesión para el interceptor
		model.addAttribute(LoginInterceptor.ATT_USER, usuario);
	}
	
	@RequestMapping(value = "/registrar", method=RequestMethod.GET)
    public String view(@ModelAttribute Usuario usuario, Model model) {
		return FORM;
	}
	
	@RequestMapping(value = "/registrar", method=RequestMethod.POST)
    public String registro(@Valid Usuario usuario, BindingResult result, @RequestParam("file") MultipartFile file, Model model){
		try{
			if (result.hasErrors()){
				return FORM;
			}else{
				//Establecer el tipo
				TipoUsuario tipo = new TipoUsuario();
				tipo.setId(2);
				usuario.setTipo(tipo);
				//Guardar foto
				usuario.setFoto(guardar(file));
				svc.guardar(usuario);
				inicializar(usuario, model);
				return SUCCESS;
			}			
		}catch (SvcException ex){
			log.error(ex);
			//Comprobar si la causa es por usuario duplicado
			if (ex.getCause() instanceof DataIntegrityViolationException){
				result.rejectValue("id", MSG_ERROR_USER);
			}else{
				result.rejectValue("id", MSG_ERROR_GRAL);
			}
			return FORM;
		}catch (Exception ex){
			log.error(ex);
			result.rejectValue("id", MSG_ERROR_GRAL);
			return FORM;
		}
	}

	/**
	 * Guardar la foto
	 * @param file
	 * @return ruta relativa de almacenamiento
	 * @throws IOException
	 */
	private String guardar(MultipartFile file) throws IOException{
		String ruta = null;
		if (file != null && file.getOriginalFilename() != null && !file.getOriginalFilename().isEmpty()){
			ruta = IMAGE_PATH + file.getOriginalFilename();
	        String path = context.getRealPath(ruta);
	            
	        //Almacenar en disco
	        iSvc.guardar(file, path);
		}
        
        return ruta;
	}
    

}
