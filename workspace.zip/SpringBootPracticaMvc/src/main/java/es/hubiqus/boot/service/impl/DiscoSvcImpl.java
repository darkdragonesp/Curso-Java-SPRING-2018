package es.hubiqus.boot.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.hubiqus.boot.model.Disco;
import es.hubiqus.boot.model.dao.DiscoDao;
import es.hubiqus.boot.service.DiscoSvc;
import es.hubiqus.boot.service.SvcException;

/**
 * Implementación del servicio de discos
 * @author ajurado
 *
 */
@Service
@Transactional
public class DiscoSvcImpl implements DiscoSvc{
	
	@Autowired
	private DiscoDao dao;
	
	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	@Override
	public void guardar(Disco disco) throws SvcException {
		try{
			dao.save(disco);
		}catch (Exception ex){
			throw new SvcException(ex);
		}
	}
	
	@Override
	public Iterable<Disco> listar() throws SvcException {
		Iterable<Disco> res = null;
		
		try{
			res = dao.findAll();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	@Override
	public void modificar(Disco disco) throws SvcException {
		try{
			dao.save(disco);
		}catch (Exception ex){
			throw new SvcException(ex);
		}		
	}

	@Transactional (propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	@Override
	public void eliminar(Disco disco) throws SvcException {
		try{
			dao.delete(disco);
		}catch (Exception ex){
			throw new SvcException(ex);
		}		
	}

	@Override
	public Disco buscar(int id) throws SvcException {
		Disco res = null;
		
		try{
			res = dao.findById(id).get();
		}catch (Exception ex){
			throw new SvcException(ex);
		}
		
		return res;
	}

}
