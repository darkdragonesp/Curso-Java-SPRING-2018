package es.hubiqus.inventario.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.service.ProductoSvc;

@RestController
@RequestMapping(value = "/api/producto")
public class ProductoRestController {
	
	@Autowired
	private ProductoSvc svc;
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public ResponseEntity<Producto> get(@PathVariable(value="id") Integer id) {
		Producto res = null;
		
		try{
			res = svc.buscar(id);
			
			if (res == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Producto>(res, HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<Iterable<Producto>> get() {
		Iterable<Producto> res = null;
		
		try{
			res = svc.listar();
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Iterable<Producto>>(res, HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<Producto> post(@RequestBody Producto item) {
		try{
			svc.guardar(item);
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.PUT)
	public ResponseEntity<Producto> put(@PathVariable(value="id") Integer id, @RequestBody Producto item) {
		try{
			svc.modificar(item);
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.NOT_MODIFIED);
		}
		
		return new ResponseEntity<Producto>(item, HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Producto> delete(@PathVariable(value="id") Integer id) {
		try{
			Producto p = new Producto();
			p.setId(id);
			
			svc.eliminar(p);
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
