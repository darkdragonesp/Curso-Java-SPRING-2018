package es.hubiqus.inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * Aplicación Spring Boot integrada con MVC (JSP)
 * @author ajurado
 *
 */
@SpringBootApplication
public class SpringMvcRestApplication extends SpringBootServletInitializer {
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SpringMvcRestApplication.class);
    }

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcRestApplication.class, args);
	}
	
}
