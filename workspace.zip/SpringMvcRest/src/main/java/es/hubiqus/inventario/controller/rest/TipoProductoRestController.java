package es.hubiqus.inventario.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.service.TipoProductoSvc;

@RestController
@RequestMapping(value = "/api/tipoproducto")
public class TipoProductoRestController {
	
	@Autowired
	private TipoProductoSvc svc;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<Iterable<TipoProducto>> get() {
		Iterable<TipoProducto> res = null;
		
		try{
			res = svc.listar();
		}catch (Exception ex){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Iterable<TipoProducto>>(res, HttpStatus.OK);
	}

}
