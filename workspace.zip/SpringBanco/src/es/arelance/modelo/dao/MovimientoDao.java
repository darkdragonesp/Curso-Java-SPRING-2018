package es.arelance.modelo.dao;

import java.util.Date;

import es.arelance.banco.modelo.Movimiento;
import es.arelance.banco.modelo.Usuario;

public interface MovimientoDao {

	void crear(Movimiento mov) throws DaoException;

	Iterable<Movimiento> filtrarMovimientos(Usuario usuario, Boolean ultimoMes,
			Integer tipo, Date fechaMinima, Double cantidadMinima) throws DaoException;

}
