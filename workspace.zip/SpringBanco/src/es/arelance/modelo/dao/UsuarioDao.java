package es.arelance.modelo.dao;

import es.arelance.banco.modelo.Usuario;

public interface UsuarioDao {

	Usuario findUser(String dni, Integer pin) throws DaoException;

	Usuario buscarUsuario(Integer id) throws DaoException;

	void update(Usuario usuario) throws DaoException;

	Usuario buscarUsuarioPorDni(String dni) throws DaoException;

}
