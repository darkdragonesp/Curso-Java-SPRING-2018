package es.arelance.modelo.dao;

import es.arelance.banco.modelo.Tipo;

public interface TipoDao {

	

	Iterable<Tipo> buscarTodos() throws DaoException;

	

}
