package es.arelance.banco.controlador;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.arelance.banco.modelo.Usuario;
import es.arelance.banco.servicios.MovimientoSvc;
import es.arelance.banco.servicios.UsuarioSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/movimientosMes")
public class MovimientosMes extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String MSG_EXITO = "Empleado almacenado";
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_EXITO = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "movimientos.jsp";
	private static final String ERROR = "error.jsp";
	
	private UsuarioSvc svc;
	private MovimientoSvc svcMov;
	

	
	public UsuarioSvc getSvc() {
		return svc;
	}

	public void setSvc(UsuarioSvc svc) {
		this.svc = svc;
	}

	public MovimientoSvc getSvcMov() {
		return svcMov;
	}

	public void setSvcMov(MovimientoSvc svcMov) {
		this.svcMov = svcMov;
	}

	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
        
        //Spring no permite la IoD en Servlets, se obtiene desde el contexto
        this.setSvc(context.getBean(UsuarioSvc.class));
        this.setSvcMov(context.getBean(MovimientoSvc.class));

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doPost(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			HttpSession sesion = request.getSession();
			if(!sesion.getAttribute("user").equals("")) {
				Usuario usuario = (Usuario) sesion.getAttribute("user");
				sesion.setAttribute("movimientos",svcMov.filtrarMovimientos(usuario,true,null,null,null));
				sesion.removeAttribute("msg");
				request.getRequestDispatcher("movimientosMes.jsp").forward(request, response);
			}else {
				request.setAttribute("mensaje","Error. Inicie sesi�n.");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			//Success
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){
			request.setAttribute(ATT_ERROR, ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
