package es.arelance.banco.controlador;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import es.arelance.banco.modelo.Usuario;
import es.arelance.banco.servicios.UsuarioSvc;

/**
 * Servlet implementation class GuardarServlet
 */
@WebServlet("/transferirSaldo")
public class TransferirSaldo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String MSG_EXITO = "Empleado almacenado";
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_EXITO = "msg";
	private static final String ATT_ERROR = "error";
	
	private static final String SUCCESS = "menu.jsp";
	private static final String ERROR = "error.jsp";
	
	private UsuarioSvc svc;

	

	
	public UsuarioSvc getSvc() {
		return svc;
	}

	public void setSvc(UsuarioSvc svc) {
		this.svc = svc;
	}

	@Override
    public void init() throws ServletException {
        WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
        
        //Spring no permite la IoD en Servlets, se obtiene desde el contexto
        this.setSvc(context.getBean(UsuarioSvc.class));

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doPost(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			HttpSession sesion = request.getSession();
			if(!sesion.getAttribute("user").equals("")) {
				Usuario usuario = (Usuario) sesion.getAttribute("user");
				Boolean exito = svc.transferir(usuario,Double.parseDouble(request.getParameter("cantidad")),
						request.getParameter("dni"));
				if(exito) {
					sesion.setAttribute("user",svc.findUser(usuario.getId()));
					sesion.setAttribute("msg","Cantidad transferida con �xito");
				}else {
					sesion.setAttribute("msg","No se pudo transferir, compruebe el dni y su saldo");
					request.getRequestDispatcher("transferir.jsp").forward(request, response);
				}
				
			}else {
				request.setAttribute("mensaje","Error. Inicie sesi�n.");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			//Success
			request.getRequestDispatcher(SUCCESS).forward(request, response);
		}catch (Exception ex){
			request.setAttribute(ATT_ERROR, ex);
			request.getRequestDispatcher(ERROR).forward(request, response);
		}
	}

}
