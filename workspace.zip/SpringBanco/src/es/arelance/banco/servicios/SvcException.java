package es.arelance.banco.servicios;

public class SvcException extends Exception{

	private static final long serialVersionUID = 216686261537340657L;

	public SvcException(Exception ex){
		super(ex);
	}

}
