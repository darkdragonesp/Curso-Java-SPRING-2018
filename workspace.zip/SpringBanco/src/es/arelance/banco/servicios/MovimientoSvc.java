package es.arelance.banco.servicios;

import java.util.Date;

import es.arelance.banco.modelo.Movimiento;
import es.arelance.banco.modelo.Usuario;

public interface MovimientoSvc {
	void crear(Movimiento movimiento) throws SvcException;
	Iterable<Movimiento> listar(Usuario usuario) throws SvcException;

	Iterable<Movimiento> filtrarMovimientos(Usuario usuario, Boolean ultimoMes,
			Integer tipoId, Date fechaMinima, Double cantidadD) throws SvcException;
}
