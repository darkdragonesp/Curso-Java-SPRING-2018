package es.arelance.banco.servicios.impl;

import org.springframework.transaction.annotation.Transactional;

import es.arelance.banco.modelo.Tipo;
import es.arelance.banco.servicios.SvcException;
import es.arelance.banco.servicios.TipoSvc;
import es.arelance.modelo.dao.TipoDao;

@Transactional
public class TipoSvcImpl implements TipoSvc {

	private TipoDao dao;
	
	public TipoDao getDao() {
		return dao;
	}

	public void setDao(TipoDao dao) {
		this.dao = dao;
	}

	@Override
	public Iterable<Tipo> findAll() throws SvcException {
		try {
			return dao.buscarTodos();
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}

}
