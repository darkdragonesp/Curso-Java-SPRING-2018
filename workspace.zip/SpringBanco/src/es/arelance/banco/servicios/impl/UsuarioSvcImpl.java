package es.arelance.banco.servicios.impl;

import java.util.Date;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.arelance.banco.modelo.Movimiento;
import es.arelance.banco.modelo.Tipo;
import es.arelance.banco.modelo.Usuario;
import es.arelance.banco.servicios.SvcException;
import es.arelance.banco.servicios.UsuarioSvc;
import es.arelance.modelo.dao.MovimientoDao;
import es.arelance.modelo.dao.UsuarioDao;

@Transactional
public class UsuarioSvcImpl implements UsuarioSvc {
	private UsuarioDao dao;
	private MovimientoDao daoMov;

	public UsuarioDao getDao() {
		return dao;
	}

	public void setDao(UsuarioDao dao) {
		this.dao = dao;
	}

	public MovimientoDao getDaoMov() {
		return daoMov;
	}

	public void setDaoMov(MovimientoDao daoMov) {
		this.daoMov = daoMov;
	}

	@Override
	public Usuario comprobarUsuarioYPass(String dni, Integer pin)
			throws SvcException {
		try {
			return dao.findUser(dni, pin);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}

	@Override
	public Usuario findUser(Integer id) throws SvcException {
		try {
			return dao.buscarUsuario(id);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void ingresar(Usuario usuario, Double ingreso, Integer tip)
			throws SvcException {
		try {
			usuario.setSaldo(usuario.getSaldo() + ingreso);
			dao.update(usuario);
			daoMov.crear(nuevoMovimiento(ingreso, usuario, tip,"Ingreso "));
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Boolean cambiarPin(Usuario usuario, Integer pin, Integer pinNuevo)
			throws SvcException {
		Boolean res = false;
		try {
			if (pin.equals(usuario.getPin())) {
				usuario.setPin(pinNuevo);
				dao.update(usuario);
				res = true;
			}
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		return res;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Boolean transferir(Usuario usuario, Double cantidad, String dni)
			throws SvcException {
		Boolean res = false;
		try {
			if (usuario.getSaldo()>=cantidad ) {
				usuario.setSaldo(usuario.getSaldo()-cantidad);
				dao.update(usuario);
				
				Usuario usuarioTransferir=dao.buscarUsuarioPorDni(dni);
				usuarioTransferir.setSaldo(usuarioTransferir.getSaldo()+cantidad);
				
				daoMov.crear(nuevoMovimiento(-cantidad, usuario, 2,"Transferido a "));
				daoMov.crear(nuevoMovimiento(cantidad, usuarioTransferir, 2,"Transferido de "));
				
				dao.update(usuario);
				dao.update(usuarioTransferir);
				
				
				
				res = true;
			}
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
		return res;
	}
	private Tipo nuevoTipo(Integer t) {
		Tipo tipo = new Tipo();
		tipo.setId(t);
		return tipo;
	}
	private Movimiento nuevoMovimiento(Double ingreso,Usuario usuario,Integer tip,String mensaje) {
		Movimiento movimiento = new Movimiento();
		movimiento.setCantidad(ingreso);
		movimiento.setConcepto(
				mensaje + ingreso + " � " + usuario.getDni());

		movimiento.setFecha(new Date());

		movimiento.setUsuario(usuario);
		
		movimiento.setTipo(nuevoTipo(tip));
		
		return movimiento;
	}
}
