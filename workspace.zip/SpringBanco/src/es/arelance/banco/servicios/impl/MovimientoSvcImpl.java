package es.arelance.banco.servicios.impl;

import java.util.Date;

import javax.transaction.Transactional;

import es.arelance.banco.modelo.Movimiento;
import es.arelance.banco.modelo.Usuario;
import es.arelance.banco.servicios.MovimientoSvc;
import es.arelance.banco.servicios.SvcException;
import es.arelance.modelo.dao.MovimientoDao;

@Transactional
public class MovimientoSvcImpl implements MovimientoSvc {
	private MovimientoDao dao;

	public MovimientoDao getDao() {
		return dao;
	}

	public void setDao(MovimientoDao dao) {
		this.dao = dao;
	}

	@Override
	public void crear(Movimiento movimiento) throws SvcException {
		// TODO Auto-generated method stub

	}

	@Override
	public Iterable<Movimiento> listar(Usuario usuario) throws SvcException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Movimiento> filtrarMovimientos(Usuario usuario, Boolean ultimoMes,
			Integer tipo, Date fechaMinima, Double cantidadMinima)
			throws SvcException {
		try {
			return dao.filtrarMovimientos(usuario, ultimoMes, tipo, fechaMinima,
					cantidadMinima);
		} catch (Exception ex) {
			throw new SvcException(ex);
		}
	}




}
