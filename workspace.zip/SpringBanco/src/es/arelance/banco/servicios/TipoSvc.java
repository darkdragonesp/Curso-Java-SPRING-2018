package es.arelance.banco.servicios;

import es.arelance.banco.modelo.Tipo;


public interface TipoSvc {
	Iterable<Tipo> findAll() throws SvcException;
}
