package es.arelance.banco.servicios;

import es.arelance.banco.modelo.Usuario;

public interface UsuarioSvc {
	Usuario comprobarUsuarioYPass(String dni,Integer pin) throws SvcException;

	Usuario findUser(Integer id) throws SvcException;
	void ingresar(Usuario usuario, Double ingreso,Integer tipo) throws SvcException;
	Boolean cambiarPin(Usuario usuario, Integer pin, Integer pinNuevo) throws SvcException;

	Boolean transferir(Usuario usuario, Double cantidad, String dni) throws SvcException;
	
}
