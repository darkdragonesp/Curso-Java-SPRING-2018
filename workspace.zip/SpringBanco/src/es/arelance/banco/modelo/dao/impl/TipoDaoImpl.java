package es.arelance.banco.modelo.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import es.arelance.banco.modelo.Tipo;
import es.arelance.modelo.dao.DaoException;
import es.arelance.modelo.dao.TipoDao;

public class TipoDaoImpl implements TipoDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Iterable<Tipo> buscarTodos() throws DaoException {
		Iterable<Tipo> res = null;

		try {
			res= sessionFactory.getCurrentSession()
					.createCriteria(Tipo.class).list();
		} catch (Exception ex) {
			throw new DaoException(ex);
		}

		return res;
	}

	

}
