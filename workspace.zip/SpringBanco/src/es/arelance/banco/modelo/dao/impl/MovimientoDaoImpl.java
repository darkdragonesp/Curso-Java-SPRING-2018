package es.arelance.banco.modelo.dao.impl;

import java.util.Date;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import es.arelance.banco.modelo.Movimiento;
import es.arelance.banco.modelo.Usuario;
import es.arelance.modelo.dao.DaoException;
import es.arelance.modelo.dao.MovimientoDao;

public class MovimientoDaoImpl implements MovimientoDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void crear(Movimiento mov) throws DaoException {
		try {
			sessionFactory.getCurrentSession().save(mov);
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public Iterable<Movimiento> filtrarMovimientos(Usuario usuario,
			Boolean ultimoMes, Integer tipo, Date fechaMinima,
			Double cantidadMinima) throws DaoException {
		try {
			String hql = "FROM Movimiento u WHERE u.usuario.id = :idUsuario ";
			if (ultimoMes) {
				hql += "AND month(u.fecha)=month(CURRENT_TIMESTAMP) "
						+ "AND year(u.fecha)=year(CURRENT_TIMESTAMP) ";
			}
			if (tipo != null) {
				hql += "AND u.tipo.id ="+tipo;
			}

			Iterable<Movimiento> res = sessionFactory.getCurrentSession()
					.createQuery(hql).setParameter("idUsuario", usuario.getId())
					.list();

			return res;
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

}
