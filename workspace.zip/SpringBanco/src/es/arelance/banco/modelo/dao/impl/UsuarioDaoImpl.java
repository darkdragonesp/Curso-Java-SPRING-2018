package es.arelance.banco.modelo.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import es.arelance.banco.modelo.Usuario;
import es.arelance.modelo.dao.DaoException;
import es.arelance.modelo.dao.UsuarioDao;

public class UsuarioDaoImpl implements UsuarioDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Usuario findUser(String dni, Integer pin) throws DaoException {
		Usuario res = null;

		try {
			String hql = "FROM Usuario u WHERE u.dni = :dni AND u.pin =:pin";

			res = (Usuario) sessionFactory.getCurrentSession().createQuery(hql)
					.setParameter("dni", dni)
					.setParameter("pin", pin)
					.uniqueResult();

		} catch (Exception ex) {
			throw new DaoException(ex);
		}

		return res;
	}

	@Override
	public Usuario buscarUsuario(Integer id) throws DaoException {
		Usuario res = null;

		try {
			res= (Usuario) sessionFactory.getCurrentSession().get(Usuario.class, id);
		} catch (Exception ex) {
			throw new DaoException(ex);
		}

		return res;
	}

	@Override
	public void update(Usuario usuario) throws DaoException {
		

		try {
			sessionFactory.getCurrentSession().update(usuario);
		} catch (Exception ex) {
			throw new DaoException(ex);
		}

		
	}

	@Override
	public Usuario buscarUsuarioPorDni(String dni) throws DaoException {
		Usuario res = null;

		try {
			String hql = "FROM Usuario u WHERE u.dni = :dni";

			res = (Usuario) sessionFactory.getCurrentSession().createQuery(hql)
					.setParameter("dni", dni)
					.uniqueResult();

		} catch (Exception ex) {
			throw new DaoException(ex);
		}

		return res;
	}

}
