package es.hubiqus.inventario.model.dao;

public class DaoException extends Exception{

	private static final long serialVersionUID = -9128710675661571854L;

	public DaoException(Exception ex){
		super(ex);
	}

}
