package es.hubiqus.inventario.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.service.ProductoSvc;
import es.hubiqus.inventario.service.TipoProductoSvc;

@Controller
public class Guardar {
	
	public static final String ATT_ITEM = "producto";
	public static final String ATT_LISTA = "lista";
	public static final String ATT_EXITO = "msg";
	
	public static final String SUCCESS = "form";
	public static final String ERROR = "form";
	
	@Autowired
	private ProductoSvc svc;
	
	@Autowired
	private TipoProductoSvc pSvc;
	
	@Autowired  
    private MessageSource messageSource;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		//Se encarga de parsear las fechas correctamente cuando vienen de formulario
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
	
	@RequestMapping(value = "/guardar", method=RequestMethod.POST)
    public String execute(@Valid Producto producto, BindingResult result, Model model, Locale locale) {
		try {
			//Incluir elementos para la selección
			model.addAttribute(ATT_LISTA, pSvc.listar());
			//Comprobar si hay errores de entrada
			if (result.hasErrors()){
				return ERROR;
			}else{
				//Guardar
				if (producto.getId() == null){
					svc.guardar(producto);
//					throw new Exception();
				}else{
					svc.modificar(producto);
				}
				
				//Mensaje de éxito
				model.addAttribute(ATT_EXITO, messageSource.getMessage("mensaje.exito", null, locale));
				
				//Limpiar formulario
				model.addAttribute(ATT_ITEM, new Producto());
				
				return SUCCESS;
			}
		} catch (Exception ex) {
//			model.addAttribute(ATT_ERROR, ex);
			//Error
			result.reject("mensaje.error");
			return ERROR;
		}
    }

}
