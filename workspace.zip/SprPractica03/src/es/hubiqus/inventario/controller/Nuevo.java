package es.hubiqus.inventario.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.service.TipoProductoSvc;

@Controller
public class Nuevo {
	
	private static final String ATT_LISTA = "lista";
	private static final String ATT_ERROR = "exception";
	
	private static final String SUCCESS = "form";
	private static final String ERROR = "form";
	
	@Autowired
	private TipoProductoSvc pSvc;
	
	@RequestMapping(value = "/nuevo", method=RequestMethod.GET)
    public String view(@ModelAttribute Producto producto, Model model) {
		try {
			//Incluir elementos para la selección
			model.addAttribute(ATT_LISTA, pSvc.listar());
			
			return SUCCESS;
		} catch (Exception e) {
			model.addAttribute(ATT_ERROR, e);
			return ERROR;
		}
	}

}
