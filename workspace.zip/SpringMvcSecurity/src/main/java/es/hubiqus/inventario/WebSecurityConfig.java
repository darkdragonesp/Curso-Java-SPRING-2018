package es.hubiqus.inventario;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
            	.antMatchers("/", "/inicio").permitAll() //Rutas permitidas
            	.antMatchers("/css/*", "/fotos/*", "/images/*", "/js/*").permitAll() //Permitir estáticos	        	
            	.anyRequest().authenticated()	//El resto no permitido sin autentificar
                .and()
            .formLogin() //Si no se especifica muestra formulario de inicio por defecto
                .loginPage("/login") //Página de login personalizada, tiene que aparecer en viewControllers
                .permitAll() //Acceso a todo el mundo
                .and()
            .logout() //Acción de salida
                .permitAll(); //Acceso a todo el mundo
    }

    @SuppressWarnings("deprecation")
	@Bean
    @Override
    public UserDetailsService userDetailsService() {
    	UserDetails user =
                User.withDefaultPasswordEncoder() //deprecated, a sustituir por autenticación JPA
                   .username("a")
                   .password("a")
                   .roles("USER")
                   .build();

        return new InMemoryUserDetailsManager(user);
    }
}
