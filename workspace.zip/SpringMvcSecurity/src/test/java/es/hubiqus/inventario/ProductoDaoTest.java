package es.hubiqus.inventario;

import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import es.hubiqus.inventario.model.Producto;
import es.hubiqus.inventario.model.TipoProducto;
import es.hubiqus.inventario.model.dao.ProductoDao;
import es.hubiqus.inventario.model.dao.TipoProductoDao;

@RunWith(SpringRunner.class)
@DataJpaTest //Testeo con bdd en memoria
public class ProductoDaoTest {
	
	@Autowired
	private TipoProductoDao tDao;
	
	@Autowired
	private ProductoDao dao;
	
	@Before
	public void setUp() {
		TipoProducto tipo = new TipoProducto();
		tipo.setId(1);
		
		tDao.save(tipo);
	}
	
	@Test
	public void save() {
		Producto producto = new Producto();
		producto.setId(1);
		producto.setCantidad(1);
		producto.setComentario("Producto de Test");
		producto.setFecha(new Date());
		producto.setNombre("Zapato");
		producto.setPrecio(15.0);
		TipoProducto tipo = new TipoProducto();
		tipo.setId(1);
		producto.setTipo(tipo);
		
		dao.save(producto);
		
		Optional<Producto> saved = dao.findById(1);
		
		assertTrue(saved.isPresent() && saved.get().getNombre().equals(producto.getNombre()));
	}

}
